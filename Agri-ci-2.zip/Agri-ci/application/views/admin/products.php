<?php
  $title['page'] = 'products';
  $this->load->view('includes/admin-header.php', $title);
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper p-2">
    <div class="pl-3">
        <p class="h4 font-weight-bold text-info"><u>Products</u></p>
    </div>
    <div class="card card-outline card-info">
        <div class="d-flex justify-content-center g-5 p-2">
          <a href="<?php echo base_url(); ?>admin/product"><button class="btn btn-success py-0 px-2 mr-1">ALL</button></a>
          <a href="<?php echo base_url(); ?>admin/product?search=A"><button class="btn btn-success py-0 px-2 mr-1">A</button></a>
          <a href="<?php echo base_url(); ?>admin/product?search=B"><button class="btn btn-success py-0 px-2 mr-1">B</button></a>
          <a href="<?php echo base_url(); ?>admin/product?search=C"><button class="btn btn-success py-0 px-2 mr-1">C</button></a>
          <a href="<?php echo base_url(); ?>admin/product?search=D"><button class="btn btn-success py-0 px-2 mr-1">D</button></a>
          <a href="<?php echo base_url(); ?>admin/product?search=E"><button class="btn btn-success py-0 px-2 mr-1">E</button></a>
          <a href="<?php echo base_url(); ?>admin/product?search=F"><button class="btn btn-success py-0 px-2 mr-1">F</button></a>
          <a href="<?php echo base_url(); ?>admin/product?search=G"><button class="btn btn-success py-0 px-2 mr-1">G</button></a>
          <a href="<?php echo base_url(); ?>admin/product?search=H"><button class="btn btn-success py-0 px-2 mr-1">H</button></a>
          <a href="<?php echo base_url(); ?>admin/product?search=I"><button class="btn btn-success py-0 px-2 mr-1">I</button></a>
          <a href="<?php echo base_url(); ?>admin/product?search=J"><button class="btn btn-success py-0 px-2 mr-1">J</button></a>
          <a href="<?php echo base_url(); ?>admin/product?search=K"><button class="btn btn-success py-0 px-2 mr-1">K</button></a>
          <a href="<?php echo base_url(); ?>admin/product?search=L"><button class="btn btn-success py-0 px-2 mr-1">L</button></a>
          <a href="<?php echo base_url(); ?>admin/product?search=M"><button class="btn btn-success py-0 px-2 mr-1">M</button></a>
          <a href="<?php echo base_url(); ?>admin/product?search=N"><button class="btn btn-success py-0 px-2 mr-1">N</button></a>
          <a href="<?php echo base_url(); ?>admin/product?search=O"><button class="btn btn-success py-0 px-2 mr-1">O</button></a>
          <a href="<?php echo base_url(); ?>admin/product?search=P"><button class="btn btn-success py-0 px-2 mr-1">P</button></a>
          <a href="<?php echo base_url(); ?>admin/product?search=Q"><button class="btn btn-success py-0 px-2 mr-1">Q</button></a>
          <a href="<?php echo base_url(); ?>admin/product?search=R"><button class="btn btn-success py-0 px-2 mr-1">R</button></a>
          <a href="<?php echo base_url(); ?>admin/product?search=S"><button class="btn btn-success py-0 px-2 mr-1">S</button></a>
          <a href="<?php echo base_url(); ?>admin/product?search=T"><button class="btn btn-success py-0 px-2 mr-1">T</button></a>
          <a href="<?php echo base_url(); ?>admin/product?search=U"><button class="btn btn-success py-0 px-2 mr-1">U</button></a>
          <a href="<?php echo base_url(); ?>admin/product?search=V"><button class="btn btn-success py-0 px-2 mr-1">V</button></a>
          <a href="<?php echo base_url(); ?>admin/product?search=W"><button class="btn btn-success py-0 px-2 mr-1">W</button></a>
          <a href="<?php echo base_url(); ?>admin/product?search=X"><button class="btn btn-success py-0 px-2 mr-1">X</button></a>
          <a href="<?php echo base_url(); ?>admin/product?search=Y"><button class="btn btn-success py-0 px-2 mr-1">Y</button></a>
          <a href="<?php echo base_url(); ?>admin/product?search=Z"><button class="btn btn-success py-0 px-2 mr-1">Z</button></a>
        </div>
        <hr>
        <div class="px-5">
          <form method="GET" action="<?php echo base_url(); ?>/admin/product">
            <div class="form-group px-5 d-flex">
              <input type="search" class="form-control" name="search" id=""  placeholder="Search...">
              <button type="submit" class="btn btn-success ml-3">Submit</button>
            </div>
          </form>
        </div>
    </div>
    <div class="alert alert-primary w-50 mx-auto d-none text-center py-2 px-4 " role="alert" id="alertBox">
    </div>
    <div class="px-5 my-3 text-right">
        <a href="add_product.php"><button class="btn btn-success">ADD NEW</button></a>
    </div>
    <!-- Content Header (Page header) -->
    <div class="card-body p-0">
                <table class="table table-striped">
                  <thead>
                    <tr>
                      <th class="text-center">No.</th>
                      <th class="text-center">Product Name</th>
                      <th class="text-center">Category Name</th>
                      <th class="text-center">Sub Category Name</th>
                      <th class="text-center">Price($)</th>
                      <th class="text-center">Availability</th>
                      <th class="text-center">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                      if($product){
                        $i = 1;
                        foreach($product as $row){
                    ?>
                    <tr>
                      <td class="text-center"><?php echo $i++; ?></td>
                      <td class="text-center"><?php echo $row['name'] ?></td>
                      <td class="text-center"><?php echo $row['category'] ?></td>
                      <td class="text-center"><?php echo $row['sub_category'] ?></td>
                      <td class="text-center"><?php echo $row['price'] ?></td>
                      <td class="text-center"><?php echo $row['stock'] ?></td>
                      <td class="text-center">
                        <a href="edit_product.php?id=<?php echo $row['id']; ?> "><button class="btn btn-info py-1">EDIT</button></a> 
                        <a href="action/delete_product_Act.php?id=<?php echo $row['id']; ?> "><button class="btn btn-danger py-1">DELETE</button></a>
                      </td>
                    </tr>
                    <?php
                        }
                      }else{
                        echo "<tr><td class='text-center ' colspan='5'> No Data Found </td></tr>";
                      }
                    ?>
                  </tbody>
                </table>
              </div>
             
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->


<?php
  $this->load->view('includes/admin-footer.php');
?>