<?php
    $id = $_GET['id'];
    $page = "products"; // Set active page to products.

    include '../includes/admin-header.php';

    $query = getProductById($id);
    $row = mysqli_fetch_assoc($query);

    $category = $row['category'];
    $sub_category = $row['sub_category'];
    $name = $row['name'];
    $description = $row['description'];
    $price = $row['price'];
    $featured_img = $row['featured_img'];
    $stock = $row['stock'];
    $special = $row['special'];
    $featured = $row['featured'];

    if(isset($_SESSION['product'])){
        $category = $_SESSION['product']['category'];
        $sub_category = $_SESSION['product']['sub_category'];
        $name = $_SESSION['product']['name'];
        $description = $_SESSION['product']['description'];
        $price = $_SESSION['product']['price'];
        $stock = $_SESSION['product']['stock'];
        $special = $_SESSION['product']['special'];
        $featured = $_SESSION['product']['featured'];
        $msg = $_SESSION['product']['message'];
    }
    


?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <!-- Horizontal Form -->
            <div class="card card-outline card-info">
              <div class="card-header">
                <h3 class="card-title text-capitalize text-indigo text-lg text-bold" >Edit Products</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form class="form-horizontal" method="POST" action="action/edit_product_Act.php" enctype="multipart/form-data" onsubmit="return checkProduct()">
                <!-- <input type="hidden" value="" name="page"> -->
                <div class="card-body">
                  <?php
                    if(isset($msg)){
                    ?>
                      <div class="alert alert-danger w-50 mx-auto text-center" role="alert" id="alertBox">
                        <?php echo $msg; ?>
                        <div>
                          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close" id="closeBtn">
                            <i class="fa fa-times py-2" aria-hidden="true"></i>
                          </button>
                        </div>
                      </div>
                    <?php
                    }
                  ?>
                  <input type="hidden" name="id" value="<?php echo $id; ?>">
                  <input type="hidden" name="old_img" value="<?php echo $featured_img; ?>">
                  <input type="hidden" name="old_gallery" value="" id="old_gallery">
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label">Category <span class="text-danger">*</span> </label>
                    <div class="col-sm-10">
                        <select class="form-control" name="category" id="category" required>
                          <option value=""> -- Choose -- </option>
                          <?php
                            $query1 = getAllCategory();
                            while($row1 = mysqli_fetch_assoc($query1)){
                             if($row1['id'] == $category){
                                $x = $category;
                             }
                              
                          ?>
                            <option value="<?php echo $row1['id']; ?>" <?php echo $category == $row1['id']? 'selected' : '';?> ><?php echo $row1['name']; ?></option>
                          <?php
                            }
                          ?>
                        </select>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label">Sub Category <span class="text-danger">*</span> </label>
                    <div class="col-sm-10">
                        <select class="form-control" name="sub_category" id="sub_category" required>
                          <option value=""> -- Choose -- </option>
                          <?php
                            $query2 = getSubCategoryByCategory($x); // Get all the sub category related to the category.
                            while($row2 = mysqli_fetch_assoc($query2)){
                          ?>
                            <option value="<?php echo $row2['id']; ?>" <?php echo $sub_category == $row2['id']? 'selected' : '';?>><?php echo $row2['name']; ?></option>
                          <?php
                            }
                          ?>
                        </select>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label"> Name <span class="text-danger">*</span> </label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="name" value="<?php echo $name; ?>" name="name" placeholder="Name" required>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label"> Description </label>
                    <div class="col-sm-10">
                      <textarea class="form-control" rows="4" name="description" placeholder="Description"><?php echo $description; ?></textarea>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label"> Price <span class="text-danger">*</span></label>
                    <div class="col-sm-10">
                      <input type="number" class="form-control" id="Price" value="<?php echo $price; ?>" name="Price" step="0.01" placeholder="Price" onkeypress="return isNumberKey(event)" required>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label">Featured Image <span class="text-danger">*</span></label>
                    <div class="col-sm-10 ">
                      <div class="mb-1">
                        <img src="../uploads/md/<?php echo $row['featured_img']; ?>" alt="" width="100px" height="100px" class="img-thumbnail  d-block">
                      </div>
                      <input type="file" class="form-control-file" name="mainImg" id="featured_img" accept="image/*" >
                      <p class="text-capitalize text-sm text-info my-1">( Image should be > 10MB and Minimum 1000x1000 pixels square width )</p>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label"> Availability </label>
                    <div class="col-sm-10">
                      <select class="form-control" name="availability" id="" >
                          <option value="In Stock" <?php echo $stock == 'In Stock'? 'selected':'';?>> In Stock </option>
                          <option value="Out Of Stock" <?php echo $stock == 'Out Of Stock'? 'selected':'';?>> Out Of Stock </option>
                        </select>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label">Gallery Image </label>
                    <div class="col-sm-10 ">
                      <div class="mb-1">
                        <?php
                            $query3 = getProductGallery($id);                // Get all the sub image related to the product.
                            while($row = mysqli_fetch_assoc($query3)){       // Get all the sub image related to the product.
                        ?>
                            <div class="d-inline-block img-box">
                                <img src="../uploads/md/<?php echo $row['img']; ?>" alt="<?php echo $row['id']; ?>" width="100px" height="100px" class="img-thumbnail">
                                <button type="button" class="img-close-btn" data-bs-dismiss="alert" aria-label="Close" id="closeBtn">
                                    <i class="fa fa-times fs-2" aria-hidden="true"></i>
                                </button>
                            </div>
                        <?php
                            }
                        ?>
                      </div>
                      <input type="file" class="image form-control-file" name="gallery[]" accept="image/*" multiple>
                      <p class="text-capitalize text-sm text-info my-1">***You can select multiple images from here for product gallery***</p>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label"></label>
                    <div class="col-sm-10 ">
                      <div class="row">
                        <div class="col-sm-4">
                            <div class="form-group">
                                <div class="custom-control custom-checkbox">
                                    <input class="custom-control-input" type="checkbox" id="spacial" value="special" name="special" <?php echo $special == 1? 'checked':''; ?>>
                                    <label for="spacial" class="custom-control-label font-weight-normal">Add To Special Product</label>
                                </div>
                            </div>
                        </div> 
                        <div class="col-sm-8">
                          <div class="form-group">
                                <div class="custom-control custom-checkbox">
                                    <input class="custom-control-input" type="checkbox" id="featured" value="featured" name="featured" <?php echo $featured == 1? 'checked':''; ?>>
                                    <label for="featured" class="custom-control-label font-weight-normal">Add To Featured Product</label>
                                </div>
                            </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <?php
                    if(isset($msg)){
                      unset($_SESSION['product']);
                    }
                  ?>
                  <div class="alert alert-danger w-50 mx-auto d-none text-center" role="alert" id="alertBox">
                  </div>
                <!-- /.card-body -->
                <div class="card-footer text-center">
                  <button type="submit" class="btn btn-success">Update</button>
                  <button type="reset" class="btn btn-warning ml-5">Reset</button>
                </div>
                </div>
                 </form>
            </div>
            <!-- /.card -->
             
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->


<?php
  include '../includes/admin-footer.php';
?>