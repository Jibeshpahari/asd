<?php

    $lk = "";
    if(isset($_GET['l'])){
    $lk = $_GET['l'];
    }

    $page = "setting"; // Set active page to category.

    include '../includes/admin-header.php';
    $query = getAdminById($_SESSION['admin']['id']);
    $row = mysqli_fetch_assoc($query);
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper p-2">
    <div class="pl-3">
        <p class="h4 font-weight-bold text-info"><u>Setting</u></p>
    </div>
    <div class="card card-outline card-info">
        <form method="POST" action="action/edit_admin_act.php" >
            <div class="row px-5 mt-4 mb-2">
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="username">Username(Admin Mail)</label>
                        <input type="text" name="username" id="username" value="<?php echo $row['username']; ?>" class="form-control" placeholder="Username(Admin Mail)">
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="password">Password</label>
                        <div class="input-group">
                            <input type="password" name="password" id="password" value="<?php echo $row['password']; ?>" class="form-control" placeholder="Password">
                            <div class="input-group-append">
                                <span class="input-group-text" id="showpass">Show</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="text-right px-5 mb-4">
                <button class="btn btn-success" type="submit" >Save</button>
            </div>
        </form>
    </div>
    <div class="alert w-50 mx-auto text-center d-none py-2 px-4 mt-2" role="alert" id="alertBox">
    </div>
    

<?php
  include '../includes/admin-footer.php';
?>