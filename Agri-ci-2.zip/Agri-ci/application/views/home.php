<?php
    defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Message</title>
    <style>
        body {
            background: #f0f4f8;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            font-size: 1rem;
        }
        .message-box {
            background: #fff;
            padding: 40px 60px;
            border-radius: 12px;
            box-shadow: 0 4px 24px rgba(0,0,0,0.08);
            font-family: Arial, sans-serif;
            font-size: 2rem;
            color: #333;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="message-box">
        LOGIN 
        <?php 
                // echo from_open('homecontroller/myFunction',)  
        ?>
    </div>
</body>
</html>
