-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 23, 2025 at 01:42 PM
-- Server version: 9.1.0
-- PHP Version: 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `agri_ci`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3 ');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
CREATE TABLE IF NOT EXISTS `category` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(155) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ranking` int NOT NULL,
  `image` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`, `ranking`, `image`, `status`) VALUES
(10, 'Electronics', 3, '20250506062017_cat4.png', 'ACTIVE'),
(6, 'Home Appliances', 1, '20250422042459_cat1.png', 'ACTIVE'),
(8, 'Food', 2, '20250422054405_cat3.png', 'ACTIVE'),
(19, 'Anand', 0, '20250505101911_cat5.png', 'ACTIVE'),
(13, 'Hardware', 6, '20250422054903_cat2.png', 'ACTIVE'),
(14, 'Clothing & Footwear', 7, '20250425060444_cat4.png', 'ACTIVE'),
(15, 'Pets', 8, '20250422055009_cat5.png', 'ACTIVE'),
(18, 'Art', 23, '20250425065816_cat1.png', 'ACTIVE');

-- --------------------------------------------------------

--
-- Table structure for table `discount`
--

DROP TABLE IF EXISTS `discount`;
CREATE TABLE IF NOT EXISTS `discount` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `valid_from` date NOT NULL,
  `valid_till` date NOT NULL,
  `type` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `discount`
--

INSERT INTO `discount` (`id`, `name`, `valid_from`, `valid_till`, `type`, `amount`, `status`) VALUES
(4, 'Second', '0001-01-01', '9999-09-09', 'PERCENTAGE', '10', 'ACTIVE'),
(3, 'First123!@#', '2025-05-08', '2025-05-28', 'FLAT', '100', 'DEACTIVE'),
(8, 'xyz', '2025-05-01', '2025-05-16', 'FLAT', '50', 'ACTIVE');

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

DROP TABLE IF EXISTS `gallery`;
CREATE TABLE IF NOT EXISTS `gallery` (
  `id` int NOT NULL AUTO_INCREMENT,
  `pro_id` int NOT NULL,
  `img` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=271 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`id`, `pro_id`, `img`) VALUES
(150, 41, '20250425072651-wall-clock1.jpg'),
(149, 40, '20250425070318-watch5.jpg'),
(148, 40, '20250425070317-watch4.jpg'),
(147, 40, '20250425070317-watch3.jpg'),
(146, 40, '20250425070316-watch1.jpg'),
(145, 39, '20250425070035-painting5.jpg'),
(144, 39, '20250425070034-painting4.jpg'),
(143, 39, '20250425070033-painting2.jpg'),
(142, 39, '20250425070033-painting1.jpg'),
(194, 55, '20250505071444-cat4.jpg'),
(195, 56, '20250505072144-plates2.jpg'),
(193, 55, '20250505071442-cat2.jpg'),
(192, 55, '20250505071441-cat1.jpg'),
(188, 52, '20250428114755-testing.jpg'),
(3, 35, '20250424132356-image6.jpg'),
(2, 35, '20250424132356-image5.jpg'),
(1, 35, '20250424132353-image4.jpg'),
(151, 41, '20250425072652-wall-clock2.jpg'),
(152, 42, '20250425073922-keybord.jpg'),
(153, 42, '20250425073923-keybord2.jpg'),
(154, 42, '20250425073924-keybord3.jpg'),
(155, 42, '20250425073924-keybord4.jpg'),
(156, 43, '20250425074051-mouse1.jpg'),
(157, 43, '20250425074052-mouse2.jpg'),
(158, 44, '20250425074134-fan2.jpg'),
(159, 45, '20250425074227-cup1.jpg'),
(190, 53, '20250430072306-camera3.jpg'),
(161, 45, '20250425074228-cup4.jpg'),
(162, 45, '20250425074229-cup5.jpg'),
(163, 45, '20250425074230-cup6.jpg'),
(164, 45, '20250425074231-cup7.jpg'),
(165, 46, '20250428075719-cake1.jpg'),
(169, 46, '20250428075816-cake3.jpg'),
(167, 46, '20250428075720-cake4.jpg'),
(168, 46, '20250428075721-cake5.jpg'),
(189, 53, '20250430072305-camera1.jpg'),
(171, 47, '20250428083933-c_cake2.jpg'),
(172, 47, '20250428083934-c_cake3.jpg'),
(173, 47, '20250428083935-c_cake4.jpg'),
(174, 48, '20250428084410-Strawberry-cake1.jpg'),
(175, 48, '20250428084411-Strawberry-cake2.jpg'),
(176, 49, '20250428084935-chocolate-ice-cream.jpg'),
(177, 49, '20250428084935-chocolate-ice-cream2.jpg'),
(178, 49, '20250428084936-chocolate-ice-cream3.jpg'),
(179, 50, '20250428085706-headset2.jpg'),
(180, 50, '20250428085706-headset3.jpg'),
(181, 50, '20250428085707-headset4.jpg'),
(182, 51, '20250428090807-laptop1.jpg'),
(183, 51, '20250428090807-laptop3.jpg'),
(184, 51, '20250428090808-laptop4.jpg'),
(185, 51, '20250428090809-laptop5.jpg'),
(186, 52, '20250428092437-ts.jpg'),
(187, 52, '20250428092438-t-shirt2.jpg'),
(196, 56, '20250505072145-plates3.jpg'),
(197, 56, '20250505072146-plates4.jpg'),
(199, 56, '20250505072234-plates1.jpg'),
(200, 57, '20250505074603-console1.jpg'),
(201, 57, '20250505074604-console3.jpg'),
(202, 57, '20250505074604-console4.jpg'),
(203, 58, '20250505075422-ipad2.jpg'),
(204, 58, '20250505075423-ipad3.jpg'),
(205, 58, '20250505075424-ipad4.jpg'),
(207, 61, '20250505090725-5.jpg'),
(208, 61, '20250505090726-6.jpg'),
(212, 61, '20250505090937-Slide6.JPG'),
(211, 61, '20250505090727-4.jpg'),
(213, 61, '20250505090937-slide3.JPG'),
(214, 61, '20250505090938-slide4.JPG'),
(215, 61, '20250505090938-Slide5.JPG'),
(216, 62, '20250509072359-painting4.jpg'),
(217, 62, '20250509072400-painting1.jpg'),
(218, 62, '20250509072400-painting2.jpg'),
(219, 62, '20250509072401-painting3.jpg'),
(220, 63, '20250509072504-image2.jpg'),
(221, 63, '20250509072507-image3.jpg'),
(222, 63, '20250509072508-image4.jpg'),
(223, 63, '20250509072510-image5.jpg'),
(224, 64, '20250509073217-ts.jpg'),
(225, 64, '20250509073217-t-shirt2.jpg'),
(226, 65, '20250509073401-watch1.jpg'),
(227, 65, '20250509073402-watch3.jpg'),
(228, 65, '20250509073403-watch4.jpg'),
(229, 65, '20250509073403-watch5.jpg'),
(230, 66, '20250509073452-wall-clock.jpg'),
(231, 66, '20250509073453-wall-clock1.jpg'),
(232, 67, '20250509073544-camera1.jpg'),
(233, 67, '20250509073544-camera3.jpg'),
(234, 68, '20250509073634-mouse1.jpg'),
(235, 68, '20250509073635-mouse2.jpg'),
(236, 69, '20250509073746-keybord1.jpg'),
(237, 69, '20250509073746-keybord2.jpg'),
(238, 69, '20250509073747-keybord3.jpg'),
(239, 70, '20250509073837-headset1.jpg'),
(240, 70, '20250509073837-headset2.jpg'),
(241, 70, '20250509073838-headset4.jpg'),
(242, 71, '20250509073926-console4.jpg'),
(243, 72, '20250509074012-laptop3.jpg'),
(244, 72, '20250509074013-laptop4.jpg'),
(245, 72, '20250509074013-laptop5.jpg'),
(246, 72, '20250509074014-laptop2.jpg'),
(247, 73, '20250509074059-ipad.jpg'),
(248, 73, '20250509074100-ipad2.jpg'),
(249, 73, '20250509074100-ipad4.jpg'),
(250, 74, '20250509074303-chocolate-ice-cream.jpg'),
(251, 74, '20250509074303-chocolate-ice-cream1.jpg'),
(252, 74, '20250509074304-chocolate-ice-cream3.jpg'),
(253, 75, '20250509074349-cake1.jpg'),
(254, 75, '20250509074350-cake3.jpg'),
(255, 75, '20250509074351-cake4.jpg'),
(256, 75, '20250509074351-cake5.jpg'),
(257, 76, '20250509074538-c_cake2.jpg'),
(258, 76, '20250509074539-c_cake3.jpg'),
(259, 76, '20250509074539-c_cake4.jpg'),
(260, 77, '20250509074740-Strawberry-cake.jpg'),
(261, 77, '20250509074741-Strawberry-cake1.jpg'),
(262, 78, '20250509074942-cup4.jpg'),
(263, 78, '20250509074943-cup5.jpg'),
(264, 78, '20250509074943-cup6.jpg'),
(265, 78, '20250509074944-cup7.jpg'),
(266, 79, '20250509075040-plates2.jpg'),
(267, 79, '20250509075041-plates3.jpg'),
(268, 79, '20250509075042-plates4.jpg'),
(269, 79, '20250509075043-plates5.jpg'),
(270, 80, '20250509075113-fan2.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
CREATE TABLE IF NOT EXISTS `items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `pro_id` int NOT NULL,
  `price` int NOT NULL,
  `qty` int NOT NULL,
  `order_id` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=85 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`id`, `pro_id`, `price`, `qty`, `order_id`) VALUES
(59, 63, 100, 1, 228),
(58, 80, 220, 1, 227),
(57, 78, 90, 1, 226),
(47, 72, 1000, 1, 221),
(56, 74, 50, 1, 225),
(55, 76, 140, 1, 223),
(54, 79, 110, 1, 223),
(53, 64, 250, 2, 222),
(51, 80, 220, 2, 222),
(50, 66, 210, 1, 222),
(49, 65, 300, 2, 222),
(48, 73, 1200, 1, 221),
(52, 67, 570, 1, 222),
(60, 75, 125, 1, 229),
(61, 68, 330, 1, 229),
(73, 65, 300, 1, 239),
(72, 69, 255, 1, 0),
(74, 73, 1200, 1, 240),
(75, 63, 100, 1, 241),
(76, 75, 125, 1, 242),
(77, 80, 220, 1, 243),
(78, 74, 50, 1, 243),
(79, 62, 230, 1, 243),
(80, 72, 1000, 1, 243),
(81, 70, 450, 1, 243),
(82, 69, 255, 6, 243),
(83, 75, 125, 1, 244),
(84, 80, 220, 1, 245);

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

DROP TABLE IF EXISTS `location`;
CREATE TABLE IF NOT EXISTS `location` (
  `id` int NOT NULL AUTO_INCREMENT,
  `u_id` int NOT NULL,
  `fname` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `lname` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` int NOT NULL,
  `fax` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `company` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `address1` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `address2` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `postcode` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `region` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`id`, `u_id`, `fname`, `lname`, `email`, `phone`, `fax`, `company`, `address1`, `address2`, `city`, `postcode`, `country`, `region`) VALUES
(37, 24, 'Jibesh', 'Pahari', 'webgrity131@gmail.com', 987654321, 'fax', 'Webgrity', '1st Floor, 19 Lake Temple Road', 'Besides Menoka Cinema', 'Kolkata', '700029', '216', '3521'),
(41, 28, 'Jibesh', 'Pahari', 'webgrity131@gmail.com', 1234567890, 'fax', 'company', '1st Floor, 19 Lake Temple Road', 'Besides Menoka Cinema', 'Kolkata', '123456', '217', '3525'),
(36, 24, 'Jibesh', 'Pahari', 'webgrity131@gmail.com', 1234567890, 'fax', 'Webgrity', '1st Floor, 19 Lake Temple Road', 'Besides Menoka Cinema', 'Kolkata', '700029', '221', '3521');

-- --------------------------------------------------------

--
-- Table structure for table `orderlist`
--

DROP TABLE IF EXISTS `orderlist`;
CREATE TABLE IF NOT EXISTS `orderlist` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ord_date` timestamp NOT NULL,
  `user_id` int NOT NULL,
  `bill_address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `shpg_address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ord_status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PROCESSING',
  `pay_status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'SUCCESSFULL',
  `pay_method` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sub_total` float NOT NULL,
  `tax` float NOT NULL,
  `discount` float NOT NULL,
  `vat` float NOT NULL,
  `total_price` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=246 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orderlist`
--

INSERT INTO `orderlist` (`id`, `ord_date`, `user_id`, `bill_address`, `shpg_address`, `ord_status`, `pay_status`, `pay_method`, `sub_total`, `tax`, `discount`, `vat`, `total_price`) VALUES
(229, '2025-05-12 12:17:27', 24, '36', '36', 'PROCESSING', 'SUCCESSFULL', 'CASH ON DELIVERY', 455, 4, 0, 91, 550),
(240, '2025-05-12 12:16:50', 24, '36', '36', 'PROCESSING', 'SUCCESSFULL', 'CASH ON DELIVERY', 1200, 2, 0, 240, 1442),
(239, '2025-05-12 05:55:04', 24, '36', '36', 'PROCESSING', 'SUCCESSFULL', 'CASH ON DELIVERY', 300, 2, 0, 60, 362),
(241, '2025-05-12 11:26:15', 24, '37', '37', 'PROCESSING', 'SUCCESSFULL', 'CASH ON DELIVERY', 100, 2, 0, 20, 122),
(242, '2025-05-12 12:16:42', 24, '36', '36', 'PROCESSING', 'SUCCESSFULL', 'CASH ON DELIVERY', 125, 2, 0, 25, 152),
(243, '2025-05-14 10:45:35', 24, '37', '36', 'COMPLETED', 'UNSUCCESSFULL', 'CREDIT CARD', 3480, 22, 348, 626.4, 3780.4),
(244, '2025-05-15 08:46:07', 24, '36', '37', 'PROCESSING', 'SUCCESSFULL', 'CREDIT CARD', 125, 2, 0, 25, 152),
(245, '2025-05-15 08:48:26', 24, '36', '36', 'PROCESSING', 'SUCCESSFULL', 'CASH ON DELIVERY', 220, 2, 0, 44, 266);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
CREATE TABLE IF NOT EXISTS `product` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category` varchar(125) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sub_category` varchar(125) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` float(10,2) NOT NULL,
  `featured_img` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `stock` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `special` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `featured` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `category`, `sub_category`, `name`, `description`, `price`, `featured_img`, `stock`, `special`, `featured`) VALUES
(72, '10', '2', 'Laptop', '', 1000.00, '20250509074011-f-laptop1.jpg', 'In Stock', '1', '1'),
(73, '10', '2', 'I pad', '', 1200.00, '20250509074058-f-ipad3.jpg', 'In Stock', '1', '1'),
(74, '8', '16', 'Chocolate Ice Cream', '', 50.00, '20250509074302-f-chocolate-ice-cream2.jpg', 'In Stock', '1', '1'),
(80, '6', '11', 'Fan', 'Super Energy Efficient Motor: Elegant Design Comprises the energy efficient technology from Longway. Motor comes with ZZ High Carbon Steel Double ball bearing set, Gloss Finish with superb performance.', 220.00, '20250509075112-f-fan1.jpg', 'In Stock', '1', '1'),
(79, '6', '9', 'Plates', '', 110.00, '20250509075040-f-plates1.jpg', 'In Stock', '1', '1'),
(78, '6', '9', 'Cup', '', 90.00, '20250509074941-f-cup3.jpg', 'In Stock', '1', '1'),
(77, '8', '15', 'Strawberry cake ', '', 110.00, '20250509074739-f-c_cake1.jpg', 'In Stock', '1', '1'),
(76, '8', '15', 'Cheese Cake', '', 140.00, '20250509074537-f-c_cake.jpg', 'In Stock', '1', '1'),
(75, '8', '15', 'Chocolate Cake', '', 125.00, '20250509074348-f-cake2.jpg', 'In Stock', '1', '1'),
(71, '10', '8', 'Console', '', 385.00, '20250509073925-f-console2.jpg', 'In Stock', '1', '1'),
(70, '10', '8', 'Headphone', '', 450.00, '20250509073836-f-headset3.jpg', 'In Stock', '1', '1'),
(69, '10', '8', 'Keybord', '', 255.00, '20250509073745-f-keybord1.jpg', 'In Stock', '1', '1'),
(68, '10', '8', 'Mouse', '', 330.00, '20250509073634-f-mouse.jpg', 'In Stock', '1', '1'),
(62, '18', '13', 'Painting - 1', '', 230.00, '20250509072358-f-painting5.jpg', 'In Stock', '1', '1'),
(63, '18', '18', 'Flower', '', 100.00, '20250509072504-f-image6.jpg', 'In Stock', '1', '1'),
(64, '14', '17', 'T - Shirt', '', 250.00, '20250509073216-f-t-shirt1.jpg', 'In Stock', '0', '0'),
(65, '13', '12', 'Wrist Watch ', '', 300.00, '20250509073401-f-watch2.jpg', 'In Stock', '1', '1'),
(66, '13', '12', 'Wall Clock', '', 210.00, '20250509073451-f-wall-clock2.jpg', 'In Stock', '1', '1'),
(67, '13', '19', 'Sony Camera', '', 570.00, '20250509073543-f-camera2.jpg', 'In Stock', '1', '1');

-- --------------------------------------------------------

--
-- Table structure for table `sub_category`
--

DROP TABLE IF EXISTS `sub_category`;
CREATE TABLE IF NOT EXISTS `sub_category` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ranking` int NOT NULL,
  `status` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sub_category`
--

INSERT INTO `sub_category` (`id`, `category`, `name`, `ranking`, `status`) VALUES
(1, '15', 'Cat', 1, 'ACTIVE'),
(2, '10', 'Study / Work', 3, 'ACTIVE'),
(9, '6', 'Dining', 0, 'ACTIVE'),
(8, '10', 'Gaming', 1, 'ACTIVE'),
(20, '19', 'Sub Anand', 0, 'ACTIVE'),
(11, '6', 'Hardware', 2, 'ACTIVE'),
(12, '13', 'Watch', 1, 'ACTIVE'),
(13, '18', 'Painting', 0, 'ACTIVE'),
(19, '13', 'Camera', 0, 'ACTIVE'),
(15, '8', 'Cake', 0, 'ACTIVE'),
(16, '8', 'Ice cream', 0, 'ACTIVE'),
(17, '14', 'Mens', 0, 'ACTIVE'),
(18, '18', 'Photos', 0, 'ACTIVE'),
(21, '19', 'Sub Anand 2', 0, 'ACTIVE'),
(23, '19', 'Jibesh', 2, 'DEACTIVE'),
(24, '15', 'Jibesh 2', 44, 'ACTIVE');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fname` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `lname` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fax` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DEACTIVE',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `fname`, `lname`, `email`, `password`, `phone`, `fax`, `status`) VALUES
(24, 'Jibesh', 'Pahari', 'webgrity131@gmail.com', '202cb962ac59075b964b07152d234b70', '1234567890', 'fax', 'ACTIVE'),
(28, 'Jibesh', 'Pahari', 'webgrity131@gmail.com', 'b0baee9d279d34fa1dfd71aadb908c3f', '1234567890', 'fax', 'DEACTIVE');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
