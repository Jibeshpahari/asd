<?php

    $ord_id = $_GET['id'];

    $page = "orders"; 
    include '../includes/admin-header.php';
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper p-2">
    <div class="pl-3">
        <p class="h3 font-weight-bold text-info"><u>Edit Order</u></p>
    </div>
    <div class="card card-outline card-info">
        <form method="POST" action="action/edit_order_act.php" >
            <div class="row px-3 mt-4 mb-2">
                <div class="col-12">
                    <h3>Product Details</h3>
                    <hr>
                </div>
            <?php 
                $query = getItemsByOrderId($ord_id);
                $i = 1;
                while($row = mysqli_fetch_assoc($query)){
                    $query2 = getProductById($row['pro_id']);
                    $row2 = mysqli_fetch_assoc($query2);
            ?>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="username">Prouct <?php echo $i++; ?></label>
                        <input type="text" value="<?php echo $row2['name']; ?>" class="form-control" disabled>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="form-group">
                        <label for="password">Quantity</label>
                        <input type="text" value="<?php echo $row['qty']; ?>" class="form-control" disabled>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="form-group">
                        <label for="password">Price</label>
                        <input type="text" value="<?php echo $row['price']; ?>" class="form-control" disabled>
                    </div>
                </div>
            <?php
                }
                
                $query = getOrderDetailsById($ord_id);
                $row = mysqli_fetch_assoc($query);
                $date1 = date_create($row['ord_date']);
                $date = date_format($date1,"d-M-Y");
                $ship_address = getAddressById($row['shpg_address']);
                $ship_address = mysqli_fetch_assoc($ship_address);
                $bill_address = getAddressById($row['bill_address']);
                $bill_address = mysqli_fetch_assoc($bill_address);
            ?>
                <div class="col-12 mt-4">
                    <h3>Address Details</h3>
                    <hr>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="username">Delivery Address</label>
                        <input type="text" value="<?php echo $ship_address['address1']; ?>" class="form-control" disabled>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="password">Billing Address</label>
                        <input type="text" value="<?php echo $bill_address['address1']; ?>" class="form-control" disabled>
                    </div>
                </div>

                <div class="col-12 mt-4">
                    <h3>Billing Details</h3>
                    <hr>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="username">SubTotal</label>
                        <input type="text" value="<?php echo $row['sub_total']; ?>" class="form-control" disabled>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="password">Eco Tax(-2.00)</label>
                        <input type="text" value="<?php echo $row['tax']; ?>" class="form-control" disabled>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="password">VAT(20%)</label>
                        <input type="text" value="<?php echo $row['vat']; ?>" class="form-control" disabled>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="password">Discount</label>
                        <input type="text" value="<?php echo $row['discount']; ?>" class="form-control" disabled>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="password">Total</label>
                        <input type="text" value="<?php echo $row['total_price']; ?>" class="form-control" disabled>
                    </div>
                </div>

                <div class="col-12 mt-4">
                    <h3>Payment Details</h3>
                    <hr>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="username">Payment Mode</label>
                        <input type="text" value="<?php echo $row['pay_method']; ?>" class="form-control" disabled>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="password">Order Date</label>
                        <input type="text" value="<?php echo $date; ?>" class="form-control" disabled>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="password">Transanction Id</label>
                        <input type="text" value="" class="form-control" disabled>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="password">Order Status</label>
                        <select class="form-control" name="ord_status" id="" required>
                          <option value="PROCESSING" <?php echo $row['ord_status']=='PROCESSING'? 'selected' : ''; ?>>PROCESSING</option>
                          <option value="SHIPPTED" <?php echo $row['ord_status']=='SHIPPTED'? 'selected' : ''; ?>>SHIPPED</option>
                          <option value="COMPLETED" <?php echo $row['ord_status']=='COMPLETED'? 'selected' : ''; ?>>COMPLETED</option>
                        </select>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="password">Payment Status</label>
                        <select class="form-control" name="pay_status" id="" required>
                            <option value="SUCCESSFULL"   <?php echo $row['pay_status']=='SUCCESSFULL'? 'selected' : ''; ?>>SUCCESSFULL</option>
                            <option value="UNSUCCESSFULL" <?php echo $row['pay_status']=='UNSUCCESSFULL'? 'selected' : ''; ?>>UNSUCCESSFULL</option>
                        </select>
                    </div>
                </div>
                <input type="hidden" name="ord_id" value="<?php echo $ord_id; ?>">
            </div> 

            <div class="text-center mb-4">
                <button class="btn btn-success" type="submit" >Save</button>
                <button class="btn btn-warning ml-4" type="reset" >Reset</button>
            </div>
        </form>
    </div>
    <div class="alert w-50 mx-auto text-center d-none py-2 px-4 mt-2" role="alert" id="alertBox">
    </div>
    

<?php
  include '../includes/admin-footer.php';
?>