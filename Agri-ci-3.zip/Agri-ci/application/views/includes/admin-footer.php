

<!-- REQUIRED SCRIPTS -->
<!-- AJAX -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<!-- jQuery -->
<script src="<?php echo base_url(); ?>/assets/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="<?php echo base_url(); ?>/assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- overlayScrollbars -->
<script src="<?php echo base_url(); ?>/assets/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url(); ?>/assets/dist/js/adminlte.js"></script>

<!-- PAGE PLUGINS -->
<!-- jQuery Mapael -->
<script src="<?php echo base_url(); ?>/assets/plugins/jquery-mousewheel/jquery.mousewheel.js"></script>
<script src="<?php echo base_url(); ?>/assets/plugins/raphael/raphael.min.js"></script>
<script src="<?php echo base_url(); ?>/assets/plugins/jquery-mapael/jquery.mapael.min.js"></script>
<script src="<?php echo base_url(); ?>/assets/plugins/jquery-mapael/usa_states.min.js"></script>
<!-- ChartJS -->
<script src="<?php echo base_url(); ?>/assets/plugins/chart.js/Chart.min.js"></script>
<!-- Summernote -->
<script src="<?php echo base_url(); ?>/assets/plugins/summernote/summernote-bs4.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url(); ?>/assets/dist/js/demo.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<!-- <script src="dist/js/pages/dashboard2.js"></script> -->


<!-- <script>
  $(document).ready(function() {
    const urlParams = new URLSearchParams(window.location.search);
    const myParam = urlParams.get('s');
    if(myParam == "add"){
      $("#alertBox").addClass("alert-success");
      $("#alertBox").text(" Added Successfully.");
      $("#alertBox").removeClass("d-none");
    }
    else if(myParam == "edit"){
      $("#alertBox").addClass("alert-primary");
      $("#alertBox").text(" Updated Successfully.");
      $("#alertBox").removeClass("d-none");
    }
    else if(myParam == "delete"){
      $("#alertBox").addClass("alert-danger");
      $("#alertBox").text(" Deleted Successfully.");
      $("#alertBox").removeClass("d-none");
    }
    else if(myParam == "subExist"){
      $("#alertBox").addClass("alert-warning");
      $("#alertBox").text("Sub Category Exist.");
      $("#alertBox").removeClass("d-none");
    }
    else if(myParam == "dataExist"){
      $("#alertBox").addClass("alert-warning");
      $("#alertBox").text("Product Exist.");
      $("#alertBox").removeClass("d-none");
    }
    else if(myParam == "update"){
      $("#alertBox").addClass("alert-success");
      $("#alertBox").text("Data Updated Successfully");
      $("#alertBox").removeClass("d-none");
    }
    else if(myParam == "error"){
      $("#alertBox").addClass("alert-danger");
      $("#alertBox").text("Something went wrong!");
      $("#alertBox").removeClass("d-none");
    }

    setTimeout(() => {
      $("#alertBox").fadeOut(800);    // For fadeOut animation. 
    }, 3200);

  });
</script>


<script>
  $(document).ready(function() {
    $('#category').change(function() {
      var category_id = $(this).val();
      $.ajax({
        url: 'action/getSub_categoryList.php',
        type: 'GET',
        data: {category_id: category_id},
        success: function(data) {
          $('#sub_category').html(data);
        }
      });
    });
  });

  $(document).ready(function() {

    const validImageTypes = ['image/gif', 'image/jpeg', 'image/png'];

    $('input[type="file"].image').on('change', function() {
      console.log(this.files.length);
      let file = this.files[0];
      if(file) {
        if (!validImageTypes.includes(file.type)) {
          $("#alertBox").text("Given file is not an Image.");
          $("#alertBox").removeClass("d-none");
          $(this).val("");
        }
        else {
          $("#alertBox").addClass("d-none");
        }
      }
    });
    
  });


  function isNumberKey(evt) {
    var charCode = (evt.which) ? evt.which : evt.keyCode
    if (charCode > 31 && (charCode != 46 &&(charCode < 48 || charCode > 57))){
      return false;
    }
    return true;
  }


  var _URL = window.URL || window.webkitURL;

  $("#featured_img").change(function(e) {
      var file, img;
      $("#alertBox").addClass("d-none");
      // alert(this.files[0].size);
      if ((file = this.files[0])) {
          img = new Image();
          img.onload = function() {
            if(this.width < 800 ) {
              $("#alertBox").text("Image Width should be Minimum 800 pixels. ");
              $("#alertBox").removeClass("d-none");
              $("#alertBox").focus();
              $("#featured_img").val("");
              // || this.size > 10000000
            }
          };
          img.onerror = function() {
            $("#alertBox").text("Given file is not an Image.");
            $("#alertBox").removeClass("d-none");
          };
          img.src = _URL.createObjectURL(file);
      }
  });

  function bytesToMB(bytes) {
    return bytes / (1024 * 1024);
  }

  let close = document.querySelectorAll(".img-close-btn");
  const arr = [];
  close.forEach(function(btn) {
    btn.addEventListener("click", function() {
      let imgBox = this.parentElement;
      let img = this.previousElementSibling;
      arr.push(img.alt);
      document.getElementById("old_gallery").value = arr;
      imgBox.remove();
    });
  });
</script> -->

<script>
  $(document).ready(function() {
    $('#showpass').on('click',function(){
      $('#password').attr('type',function(index, attr){
        $('#password').focus();
        return attr == 'password' ? 'text' : 'password';
      }); 
    })
  });
</script>

</body>
</html>
