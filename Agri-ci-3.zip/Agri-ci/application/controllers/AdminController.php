<?php
    
    defined('BASEPATH') OR exit('No direct script access allowed');

    class AdminController extends CI_Controller {

        // function __construct(){
        //     parent::__construct();
        //     if($this->session->userdata('admin') == ''){
        //         redirect('admin/login');
        //     }
        //     $config['encryption_key'] = 'bjA{<ATCs1w5?,8N(bJvgO3CW_<]t?@o';
        // }

        // View the dashboard page
         public function index(){
            $this->load->view('admin/dashboard');
        }


//      | ------------------ |  Admin Login Section  | ------------------ |

        // View login page 
        public function login(){
            $this->load->view('admin/index');
        }

        // Check admin validation
        public function checkAdmin(){
            $this->session->unset_userdata('admin');
            $errors = [
                'password' => [
                    'validateUser' => 'Email or Password don\'t match'
                ]
            ];
            if($this->form_validation->run('checkAdmin') == FALSE)
            {
                $this->load->view('admin/index');
            }
            else
            {
                $this->load->model('AdminModel');
                $result = $this->AdminModel->checkAdmin();
                if($result){
                    $this->session->set_userdata('admin', $result['username']);
                    $this->session->set_userdata('admin_id', $result['id']);
                    redirect('admin/dashboard');
                }else{
                    $data['error'] = 'Invalid username or password.';
                    $this->load->view('admin/index', $data);     // View the Index(login) page inside admin folder | Not route 
                }
            }

        }

//      | ------------------ |  Category Section     | ------------------ |
        // Get all the category details by a serach key.
        public function category($like=""){
            $like = $this->input->get('search');
            $this->load->model('AdminModel');
            $categories = $this->AdminModel->getCatagory($like);
            $data['category'] = $categories;
            $this->load->view('admin/category', $data);
	    }
        
        // View Category Add Page
        public function showAddCategory(){
            $this->load->view('admin/add_category');   
        }

        // Validate the given image
        public function validate_image() {
            if ((!isset($_FILES['image'])) || $_FILES['image']['size'] == 0) {
                $this->form_validation->set_message('validate_image', 'Something is Wrong With This {field}, Try Other One');
                return FALSE;
            }
            else if (isset($_FILES['image']) && $_FILES['image']['size'] != 0) {
                $allowedExts = array("gif", "jpeg", "jpg", "png", "JPG", "JPEG", "GIF", "PNG");
                $allowedTypes = array(IMAGETYPE_PNG, IMAGETYPE_JPEG, IMAGETYPE_GIF);
                $extension = pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION);
                $detectedType = exif_imagetype($_FILES['image']['tmp_name']);
                $type = $_FILES['image']['type'];
                if (!in_array($detectedType, $allowedTypes)) {
                    $this->form_validation->set_message('validate_image', 'Invalid Image Content!');
                    return FALSE;
                }
                if(filesize($_FILES['image']['tmp_name']) > 2000000) {
                    $this->form_validation->set_message('validate_image', 'The Image file size shoud not exceed 20MB!');
                    return FALSE;
                }
                if(!in_array($extension, $allowedExts)) {
                    $this->form_validation->set_message('validate_image', "Invalid file extension {$extension}");
                    return FALSE;
                }
            }
            return TRUE;
        }

        // Add New category
        public function addCategory(){
            if ($this->form_validation->run('addCategory') == FALSE) {
                $this->load->view('admin/add_category');
            } 
            else 
            {
                $config['upload_path'] = './uploads/category';
                $config['allowed_types'] = 'gif|jpg|png';
                $this->load->library('upload', $config);

                if (!$this->upload->do_upload('image')) {
                    $this->load->view('admin/add_category');
                } else {
                    $formdata = $this->input->post();
                    $image = $this->upload->data('file_name');
                    $this->load->model('AdminModel');
                    $result = $this->AdminModel->addCategory();
                    if($result){
                        $this->session->set_flashdata('message', 'New Category added successfully.');
                        redirect('admin/category');
                    }else{
                        $error['error'] = 'Something Went Wrong, Please Try again.';
                        $this->load->view('admin/add_category', $error);     // View the category page with error message 
                    }
                }
            }
        }

        // View the category edit page
        public function showEditCategory($id){
            $this->load->model('AdminModel');
            $categorie = $this->AdminModel->getCategoryById($id);
            $data['category'] = $categorie;
            $this->load->view('admin/edit_category',$data);
        }

        // Update category details
        public function editCategory(){
            $config['upload_path'] = './uploads/category';
            $config['allowed_types'] = 'gif|jpg|png';
            $this->load->library('upload', $config);

            $this->load->model('AdminModel');
            $id = $this->input->post('id');
            
            $this->form_validation->set_rules('name', 'Name', 'required');
            $this->form_validation->set_rules('order', 'Order', 'numeric');

            if(!empty($_FILES['image']['name'])){
                $this->form_validation->set_rules('image', 'Image', 'callback_validate_image');
            }
            if ($this->form_validation->run() == FALSE) {
                $categorie = $this->AdminModel->getCategoryById($id);
                $data['category'] = $categorie;
                $this->load->view('admin/edit_category',$data);
            }else{
                $this->upload->do_upload('image');
                $result = $this->AdminModel->updateCategory($id);
                if($result){
                    $this->session->set_flashdata('message', 'Category edit successfully.');
                    redirect('admin/category');
                }
            }
        }

        // Delete category details with image
        public function deleteCategory($id){
            $this->load->model('AdminModel');
            $category = $this->AdminModel->getCategoryById($id);
            if($category['num_sub_category'] <= 0){
                $result = $this->AdminModel->deleteCategory($id);
                if($result){
                    $path ='./uploads/category/' . $category['image'];
                    if (file_exists($path)) {
                        unlink($path);
                    }
                    $this->session->set_flashdata('message', 'Category deleted successfully.');
                    redirect('admin/category');
                }else{
                    $this->session->set_flashdata('message', 'Something went wrong.');
                    redirect('admin/category');
                }
            }
            else{
                $this->session->set_flashdata('message', 'Sub Category exsist can\'t be deleted');
                redirect('admin/category');
            }
        }

//      | ------------------ |  Sub-category Section | ------------------ |

        // Get all the Sub-category details by a search key.
        public function subCategory($like=""){
            $like = $this->input->get('search');
            $this->load->model('AdminModel');
            $x = $this->AdminModel->getSubCatagory($like);
            $data['subcategory'] = $x;
            $this->load->view('admin/sub_category',$data);
        }

        // View Sub-category add page
        public function showAddSubCategory(){
            $this->load->model('AdminModel');
            $categories = $this->AdminModel->getCatagory();
            $data['category'] = $categories;
            $this->load->view('admin/add_subCategory', $data);
        }

        // Add New Sub_category
        public function addSubCategory(){
            $this->load->model('AdminModel');
            $categories = $this->AdminModel->getCatagory();
            $data['category'] = $categories;
        
            if ($this->form_validation->run('addSubCategory') == FALSE) {
                $this->load->view('admin/add_subCategory', $data);
            } 
            else 
            {
                $formdata = $this->input->post();
                $this->load->model('AdminModel');
                $result = $this->AdminModel->addSubCategory();
                if($result){
                    $this->session->set_flashdata('message', 'New Sub Category added successfully.');
                    redirect('admin/sub_category');
                }else{
                    $error['error'] = 'Something Went Wrong, Please Try again.';
                    $this->load->view('admin/add_subCategory', $error);     
                }
            }
        }

        // View Sub category edit page
        public function showEditSubCategory($id){
            $this->load->model('AdminModel');
            $subCategory = $this->AdminModel->getSubCategoryById($id);
            $categories = $this->AdminModel->getCatagory();
            $data['sub_category'] = $subCategory;
            $data['category'] = $categories;
            $this->load->view('admin/edit_subCategory', $data);
        }

        // Edit Sub category by Sub category id
        public function editSubCategory(){
            $id = $this->input->post('id');
            $this->load->model('AdminModel');
            $subCategory = $this->AdminModel->getSubCategoryById($id);
            $categories = $this->AdminModel->getCatagory();
            $data['sub_category'] = $subCategory;
            $data['category'] = $categories;
            if ($this->form_validation->run('addSubCategory') == FALSE) {
                $this->load->view('admin/edit_subCategory',$data);
            }
            else{
                $result = $this->AdminModel->updateSubCategory($id);
                if($result){
                    $this->session->set_flashdata('message', 'Sub Category edited successfully.');
                    redirect('admin/sub_category');
                }else{
                    $error['error'] = 'Something Went Wrong, Please Try again.';
                    $this->load->view('admin/add_subCategory', $error);     
                }
            }
        }

        // Delete Sub_category details 
        public function deleteSubCategory($id){
            $this->load->model('AdminModel');
            $sub_category = $this->AdminModel->getSubCategoryById($id);
            if($sub_category['products'] == 0){
                $result = $this->AdminModel->deleteSubCategory($id);
                if($result){
                    $this->session->set_flashdata('message', 'Sub Category deleted successfully.');
                    redirect('admin/sub_category');
                }else{
                    $this->session->set_flashdata('message', 'Something went wrong.');
                    redirect('admin/sub_category');
                }
            }
            else{
                $this->session->set_flashdata('message', 'Product exsist can\'t be deleted');
                redirect('admin/sub_category');
            }
        }

//      | ------------------ |  Product Section      | ------------------ |

        // Get all the product details with category and subcategory by a search key...
        public function product($like=""){
            $like = $this->input->get('search');
            $this->load->model('AdminModel');
            $x = $this->AdminModel->getProduct($like);
            $data['product'] = $x;
            $this->load->view('admin/products',$data);
        }

//      | ------------------ |  Discount Section     | ------------------ |

        public function discount($like=""){
            $like = $this->input->get('search');
            $this->load->model('AdminModel');
            $data['data'] = $this->AdminModel->getDiscounts($like);
            $this->load->view('admin/discount', $data);
        }

//      | ------------------ | Setting Section | ------------------ |

        // Show setting page
        public function setting() {
            $id = $this->session->userdata('admin_id');
            $this->load->model('AdminModel');
            $settings = $this->AdminModel->getSettings($id);
            $data['settings'] = $settings;
            $this->load->view('admin/setting', $data);
        }

        // Update admin details
        public function updateSetting() {
            $id = $this->session->userdata('admin_id');
            $this->load->model('AdminModel');
            $result = $this->AdminModel->updateSetting($id);
            if ($result) {
                $this->session->set_flashdata('message', 'Settings updated successfully.');
                redirect('admin/setting');
            } else {
                $this->session->set_flashdata('message', 'Something went wrong. Please try again.');
                redirect('admin/setting');
            }
        }




    }

?>