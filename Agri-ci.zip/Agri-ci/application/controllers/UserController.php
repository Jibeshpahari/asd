<?php
    
    defined('BASEPATH') OR exit('No direct script access allowed');

    class UserController extends CI_Controller {
        public function __construct()
        {
            parent::__construct();
            $this->load->model('UserModel');
            $this->load->model('AdminModel');
            $this->load->library('cart');
        }

// --------------------- ||  FUNCTION FOR INDEX PAGE  || ---------------------
        // Show the index page
        public function index()
	    {
            $category = $this->UserModel->getCategory();
            $data['category'] = $category;
            $special = $this->UserModel->getSpecialProduct();
            $data['special'] = $special;
            $featured = $this->UserModel->getFeaturedProduct();
            $data['featured'] = $featured;
		    $this->load->view('index', $data);
	    }

// --------------------- ||  FUNCTION FOR PRODUCT PAGE  || ---------------------
        // Show the product page
        public function product($id) {
            $product = $this->AdminModel->getProductById($id);
            $data['product'] =  $product;
            $gallery = $this->UserModel->getProductGallery($id);
            $data['gallery'] = $gallery;
            $subProduct = $this->UserModel->getSimilarByProductId($id, $product['sub_category']);
            $data['subProduct'] = $subProduct;
            $category = $this->AdminModel->getCategoryById($product['category']);
            $data['category'] = $category;
            $subCategory = $this->AdminModel->getSubCategoryById($product['sub_category']);
            $data['subCategory'] = $subCategory;
            // echo "<pre>"; print_r($data);
            $this->load->view('product', $data);
        }

// --------------------- ||  FUNCTION FOR CATEGORY PAGE  || ---------------------
        // Show the category page
        public function category($id) {
            $product = $this->UserModel->getProductByCategory($id);
            $data['products'] = $product;
            $this->load->view('category', $data);
        }

        // Show the Sub Category page
        public function subCategory($id) {
            $product = $this->UserModel->getProductBySubCategory($id);
            $data['products'] = $product;
            $this->load->view('category', $data);
        }

        // Sort the product
        public function productSort(){  
            $products = $this->UserModel->getProductSegment();
            $result['products'] = $products;

            $segment = $this->input->post('segment');
            $id = $this->input->post('id');
            
            if ($segment == 'category') {
                $count = $this->UserModel->getProductByCategory($id);
                $count = count($count); 
            } elseif ($segment == 'sub_category') {
                $count = $this->UserModel->getProductBySubCategory($id);
                $count = count($count); 
            }

            $result['showing'] = $count;
            $this->load->view('getProduct', $result);
        }

// --------------------- ||  FUNCTION FOR SEARCH PAGE  || ---------------------
        // Show the search page
        public function search() {
            $search = $this->input->get('search');
            $product = $this->UserModel->getProductBySearch($search);
            $data['products'] = $product;
            if (empty($product)) {
                $data['message'] = "No products found for your search.";
            }
            $this->load->view('search', $data);
        }

// --------------------- ||  FUNCTION FOR CART PAGE  || ---------------------
        // Show
        public function show(){
            $cartItems = $this->cart->contents();
            echo "<pre>";
            print_r($cartItems);
            echo '<br>';
            echo $this->cart->total();
        }
        // add product to the cart using Ajax
        public function addToCart() {
            $productId = $this->input->post('product_id');
            $quantity = $this->input->post('quantity');
            $product = $this->AdminModel->getProductById($productId);
            if ($product) {
                $data = array(
                    'id'      => $productId,
                    'qty'     => $quantity,
                    'price'   => $product['price'],
                    'name'    => $product['name'],
                    'image'   => $product['featured_img']
                );
                $this->cart->insert($data);
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Product not found']);
            }
        }

        // Update the cart page using Ajax
        public function getCart() {
            $data['items'] = $this->cart->contents();
            $data['count'] = count($this->cart->contents());
            $data['sub_total'] = $this->cart->total();
            $data['tax'] =  $this->cart->total_items() * 2;
            $data['vat'] =   $data['sub_total'] * 0.2;
            $data['total'] = $data['sub_total'] + $data['tax'] + $data['vat'];
            $this->load->view('getCart',  $data);
        }

        // Show the cart page
        public function cart(){
            $data['items'] = $this->cart->contents();
            // $data['count'] = count($this->cart->contents());
            $data['sub_total'] = $this->cart->total();
            $data['tax'] =  $this->cart->total_items() * 2;
            $data['vat'] =   $data['sub_total'] * 0.2;
            $data['total'] = $data['sub_total'] + $data['tax'] + $data['vat'];
            // $this->load->view('cart', $data);
        }

        // Update list of the items
        public function getItemList(){
            // $cart = $this->session->userdata('cart');
            // $data['cart']['subtotal'] = 0;
            // $data['cart']['tax'] = 0;
            // $data['cart']['vat'] = 0;
            // $data['cart']['total'] = 0;
            // if(!empty($cart)) {
            //     foreach ($cart as $key => $value) {
            //         $productInfo = $this->AdminModel->getProductById($key);
            //         $data['cart']['items'][] = [
            //             'id' => $key,
            //             'image' => $productInfo['featured_img'],
            //             'name' => $productInfo['name'],
            //             'quantity' => $value['quantity'],
            //             'price' => $value['price'] * $value['quantity'],
            //         ];
            //         $data['cart']['subtotal'] += $value['quantity'] * $value['price'];
            //         $data['cart']['tax'] += $value['quantity'] * 2; // Assuming a fixed tax of 2 per item
            //         $data['cart']['vat'] += ($value['quantity'] * $value['price']) * 0.2; // Assuming a VAT of 20%
            //     }
            //     $data['cart']['total'] += $data['cart']['subtotal'] + $data['cart']['tax'] + $data['cart']['vat'];
            //     if(isset($data['cart']['discount'])){
            //         $data['cart']['total'] += $data['cart']['discount'];
            //     }
            // }
            // $this->load->view('getCartList', $data);
        }

        // Delete item from cart
        public function removeItem(){
            $id = $this->input->post('id');
            $cart = $this->session->userdata('cart');
            if (isset($cart[$id])) {
                unset($cart[$id]);
                $this->session->set_userdata('cart', $cart);
            }
        }












    }

?>