<?php

defined('BASEPATH') or exit('No direct script access allowed');

class UserController extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('UserModel');
        $this->load->model('AdminModel');
        $this->load->library('cart');
        $this->load->library('user_agent');
    }

// --------------------- ||  FUNCTION FOR INDEX PAGE     || ---------------------
    // Show the index page
    public function index()
    {
        $category = $this->UserModel->getCategory();
        $data['category'] = $category;
        $special = $this->UserModel->getSpecialProduct();
        $data['special'] = $special;
        $featured = $this->UserModel->getFeaturedProduct();
        $data['featured'] = $featured;
        $this->load->view('index', $data);
    }

// --------------------- ||  FUNCTION FOR PRODUCT PAGE   || ---------------------
    // Show the product page
    public function product($id)
    {
        $product = $this->AdminModel->getProductById($id);
        $data['product'] =  $product;
        $gallery = $this->UserModel->getProductGallery($id);
        $data['gallery'] = $gallery;
        $subProduct = $this->UserModel->getSimilarByProductId($id, $product['sub_category']);
        $data['subProduct'] = $subProduct;
        $category = $this->AdminModel->getCategoryById($product['category']);
        $data['category'] = $category;
        $subCategory = $this->AdminModel->getSubCategoryById($product['sub_category']);
        $data['subCategory'] = $subCategory;
        // echo "<pre>"; print_r($data);
        $this->load->view('product', $data);
    }

// --------------------- ||  FUNCTION FOR CATEGORY PAGE  || ---------------------
    // Show the category page
    public function category($id)
    {
        $product = $this->UserModel->getProductByCategory($id);
        $data['products'] = $product;
        $this->load->view('category', $data);
    }

    // Show the Sub Category page
    public function subCategory($id)
    {
        $product = $this->UserModel->getProductBySubCategory($id);
        $data['products'] = $product;
        $this->load->view('category', $data);
    }

    // Sort the product
    public function productSort()
    {
        $products = $this->UserModel->getProductSegment();
        $result['products'] = $products;

        $segment = $this->input->post('segment');
        $id = $this->input->post('id');

        if ($segment == 'category') {
            $count = $this->UserModel->getProductByCategory($id);
            $count = count($count);
        } elseif ($segment == 'sub_category') {
            $count = $this->UserModel->getProductBySubCategory($id);
            $count = count($count);
        }

        $result['showing'] = $count;
        $this->load->view('getProduct', $result);
    }

// --------------------- ||  FUNCTION FOR SEARCH PAGE    || ---------------------
    // Show the search page
    public function search()
    {
        $search = $this->input->get('search');
        $product = $this->UserModel->getProductBySearch($search);
        $data['products'] = $product;
        if (empty($product)) {
            $data['message'] = "No products found for your search.";
        }
        $this->load->view('search', $data);
    }

// --------------------- ||  FUNCTION FOR CART PAGE      || ---------------------
    // add product to the cart using Ajax
    public function addToCart()
    {
        $productId = $this->input->post('product_id');
        $quantity = $this->input->post('quantity');
        $product = $this->AdminModel->getProductById($productId);
        if ($product) {
            $data = array(
                'id'      => $productId,
                'qty'     => $quantity,
                'price'   => $product['price'],
                'name'    => $product['name'],
                'image'   => $product['featured_img']
            );
            $this->cart->insert($data);
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Product not found']);
        }
    }

    // Get the cart items with details
    public function getCartItems()
    {
        $cartItems = $this->cart->contents();
        $data['items'] = $cartItems;
        $data['count'] = count($cartItems);
        $data['sub_total'] = $this->cart->total();
        $data['tax'] =  $this->cart->total_items() * 2; // Assuming a fixed tax of 2 per item
        $data['vat'] =   $data['sub_total'] * 0.2; // Assuming a VAT of 20%
        $data['total'] = $data['sub_total'] + $data['tax'] + $data['vat'];
        return $data;
    }

    // Find the amount of discount
    public function findDiscount(){
        $data = $this->getCartItems();
        $discount = $this->session->discount;
        if (isset($discount)) {
            if ($data['sub_total'] > 0) {
                $dis = $this->UserModel->getDiscountByName($discount);
                if ($dis['type'] == 'PERCENTAGE') {
                    $discount = ($data['sub_total'] * $dis['amount']) / 100;
                } else {
                    $discount = $dis['amount'];
                }
            } else {
                $discount = 0;
                $this->session->unset_userdata('discount');
            }
        } else {
            $discount = null;
        }
        return $discount;
    }

    // Update the cart page using Ajax
    public function getCart()
    {
        $data = $this->getCartItems();
        $this->load->view('getCart',  $data);
    }

    // Show the cart page
    public function cart()
    {
        $data = $this->getCartItems();
        $this->load->view('cart', $data);
    }

    // Update list of the items using ajax
    public function getItemList()
    {
        $data = $this->getCartItems();
        $this->load->view('getCartList', $data);
    }

    // Update the quantity of the product using ajax
    public function updateQuantity()
    {
        $rowid = $this->input->post('rowid');
        $qty = $this->input->post('qty');
        if ($rowid && $qty > 0) {
            $data = array(
                'rowid' => $rowid,
                'qty'   => $qty
            );
            $this->cart->update($data);
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Invalid input']);
        }
    }

    // Delete item from cart using ajax
    public function removeItem()
    {
        $rowid = $this->input->post('id');
        if ($rowid) {
            $this->cart->remove($rowid);
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Invalid cart item']);
        }
    }

    // Add Coupon code using ajax
    public function addCoupon(){
        $this->session->set_userdata('discount');
        $coupon = $this->input->post('coupon');
        $discount = $this->UserModel->getDiscountByName($coupon);
        $date = date('Y-m-d');
        $cartItems = $this->cart->contents();
        if(!isset($cartItems) || empty($cartItems)){
            echo json_encode(['success' => false, 'message' => 'First add product']);
            die;
        }
        if ($discount) {
            if ($date >= $discount['valid_from'] && $date <= $discount['valid_till']) {
                $this->session->set_userdata('discount', $coupon);
                echo json_encode(['success' => true, 'message' => 'Coupon applied successfully']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Coupon expired or not yet valid']);
            }
        }
        else{
            echo json_encode(['success' => false, 'message' => 'Invalid Coupon Code']);
        }
    }

    // Update billing using ajax
    public function getBilling()
    {
        $data = $this->getCartItems();
        $discount = $this->findDiscount();
        $data['discount'] = $discount;
        $this->load->view('getBilling', $data);
    }

// --------------------- ||  FUNCTION FOR REGISTRATION   || ---------------------
    // View Registration page
    public function register(){
        $this->load->view('register');
    }

    // Add new user
    public function userRegistration(){
        if($this->form_validation->run('registration') == FALSE){
            $this->load->view('register');
        }else{
            // $id = $this->UserModel->registration();
            if(1){
                // $result = $this->UserModel->addAddress($id);
                if(1){
                    $to = $this->input->post('email');
                    $subject = 'Email Validation';
                    $message = "Click here to active your account.<br> <a href='http://localhost/Agri-ci/login'>Agri</a> ";
                    $this->sendMail($to, $subject, $message);
                }else{
                    $this->session->set_flashdata('message', 'Something went wrong, please try again later');
                    $this->load->view('register');
                }
            }else{
                $this->session->set_flashdata('message', 'Something went wrong, please try again later');
                $this->load->view('register');
            }
        }
    }
    // --------------------- ||  FUNCTION FOR MAIL           || ---------------------
    // Function for sending mail
    public function sendMail($to, $subject, $message)
    {
        // echo $to . " -- " . $subject . " -- " . $message;
        $config = array(
            'protocol' => 'sendmail',
            'mailpath' => '/usr/sbin/sendmail',
            'mailtype' => 'html',
            'newline' => "\r\n",
            'charset' => 'utf-8',
        );
        $this->load->library('email', $config);

        $this->email->from('sender@example.com', 'Agri');
        $this->email->to($to);
        $this->email->subject($subject);
        $this->email->message($message);
        $this->email->set_alt_message('This mail is send for testing purpose.');
        if ($this->email->send()) {
            echo 'Email sent.';
        } else {
            show_error($this->email->print_debugger());
        }
    }
// --------------------- ||  FUNCTION FOR LOGIN          || ---------------------

    // View login page
    public function login(){
        $this->load->view('login');
    }

    // Check login
    public function checkUser(){
        $email = $this->input->post('email');
        $password = $this->input->post('password');
        if ($this->form_validation->run('checkUser') == FALSE) {
            $this->load->view('login');
        }else{
            $user = $this->UserModel->userLogin($email, $password);
            if($user){
                if($user['status'] != 'ACTIVE'){
                    $this->session->set_flashdata('message', 'Active Your Account');
                    $this->load->view('login');
                }else{
                    $this->session->set_userdata('user', $user);
                    redirect('billing/address');
                }
            }else{
                $this->session->set_flashdata('message', 'Given details is incurred');
                $this->load->view('login');
            }
        }
    }

// --------------------- ||  FUNCTION FOR BILLING        || ---------------------

    // Show billing page
    public function showBilling(){
        $user = $this->session->user;
        $data['location'] = $this->AdminModel->getAddressByUserId($user['id']);
        $this->load->view('billing', $data);
    }

    // Add billing address in to session
    function addBillingAddress(){
        $billing_address = $this->input->post('billingAddress');
        $this->session->set_userdata('billing_address', $billing_address);
        redirect('shipping/address');
    }

    // View Address add page
    function viewAddAddress()
    {
        $refer =  $this->agent->referrer();
        $this->session->set_userdata('previous', $refer);
        $this->load->view('add_address');
    }

    // Add new addresses
    function addSubAddress(){
        if($this->form_validation->run('addNewAddress') == FALSE){
            $this->load->view('add_address');
        }else{
            $user = $this->session->user;
            $uid = $user['id'];
            $result = $this->UserModel->addAddress($uid);
            if($result){
                if($this->session->previous){
                    redirect($this->session->previous);
                }
            }else{
                echo "Not added";
            }
        }
    }

// --------------------- ||  FUNCTION FOR SHIPPING       || ---------------------
    // View shipping page
    public function  viewShipping(){
        $user = $this->session->user;
        $data['location'] = $this->AdminModel->getAddressByUserId($user['id']);
        $data['billing_address'] = $this->session->billing_address;
        $this->load->view('shipping', $data);
    }

    function addShippingAddress(){
        $b_address = $this->input->post('b_address');
        if($b_address){
            $this->session->set_userdata('shipping_address', $b_address);
        }else{
            $s_Address = $this->input->post('shippingAddress');
            $this->session->set_userdata('shipping_address', $s_Address);
        }
        redirect('payment');
    }

// --------------------- ||  FUNCTION FOR PAYMENT       || ---------------------
    // View payment page
    public function payment(){
        // $this->load->view('payment');
        echo "<pre>";
        $cart = $this->session->cart_contents;
        $cart['discount'] = 120 ;
        print_r($cart);
    }












}