<?php
    
    defined('BASEPATH') OR exit('No direct script access allowed');

    class UserController extends CI_Controller {

        public function index()
	    {
		    $this->load->view('login');
	    }
        
        public function show()
	    {
            $formArray = array();
            $formArray['email'] = $this->input->post('email');
            $formArray['password'] = $this->input->post('password');
            $this->load->model('UserLoginModel');
            $this->UserLoginModel->login($formArray);
	    }


    }


?>