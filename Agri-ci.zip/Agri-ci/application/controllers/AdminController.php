<?php

defined('BASEPATH') or exit('No direct script access allowed');

class AdminController extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('AdminModel');
        $this->load->helper('image');
        // if ($this->session->userdata('admin') == '') {
        //     redirect(base_url('admin/login'));
        //     $this->load->view('admin/index');
        // }else{
        //     $username = $this->session->userdata('admin');
        // }
        // $config['encryption_key'] = 'bjA{<ATCs1w5?,8N(bJvgO3CW_<]t?@o';
    }

    // View the dashboard page
    public function index()
    {
        $categories = $this->AdminModel->getCatagory();
        $data['categories'] = count($categories);
        $sub_categories = $this->AdminModel->getSubCatagory();
        $data['sub_categories'] = count($sub_categories);
        $products = $this->AdminModel->getProduct();
        $data['products'] = count($products);
        $orders = $this->AdminModel->getOrders();
        $data['orders'] = count($orders);
        $customers = $this->AdminModel->getCustomers();
        $data['customers'] = count($customers);
        $discounts = $this->AdminModel->getDiscounts();
        $data['discounts'] = count($discounts);
        $this->load->view('admin/dashboard', $data);
    }

    // Validate the given image
    public function validate_image()
    {
        if ((!isset($_FILES['image'])) || $_FILES['image']['size'] == 0) {
            $this->form_validation->set_message('validate_image', 'Something is Wrong With This {field}, Try Other One');
            return FALSE;
        } else if (isset($_FILES['image']) && $_FILES['image']['size'] != 0) {
            $allowedExts = array("gif", "jpeg", "jpg", "png", "JPG", "JPEG", "GIF", "PNG");
            $allowedTypes = array(IMAGETYPE_PNG, IMAGETYPE_JPEG, IMAGETYPE_GIF);
            $extension = pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION);
            $detectedType = exif_imagetype($_FILES['image']['tmp_name']);
            $type = $_FILES['image']['type'];
            if (!in_array($detectedType, $allowedTypes)) {
                $this->form_validation->set_message('validate_image', 'Invalid Image Content!');
                return FALSE;
            }
            if (filesize($_FILES['image']['tmp_name']) > 2000000) {
                $this->form_validation->set_message('validate_image', 'The Image file size shoud not exceed 20MB!');
                return FALSE;
            }
            if (!in_array($extension, $allowedExts)) {
                $this->form_validation->set_message('validate_image', "Invalid file extension {$extension}");
                return FALSE;
            }
        }
        return TRUE;
    }

    // Multi Image Validation
    public function validate_gallery_images()
    {
        $files = $_FILES['gallery'];
        $allowedExts = array("gif", "jpeg", "jpg", "png", "JPG", "JPEG", "GIF", "PNG");
        $allowedTypes = array(IMAGETYPE_PNG, IMAGETYPE_JPEG, IMAGETYPE_GIF);
        for ($i = 0; $i < count($files['name']); $i++) {
            // Check if image name is empty
            if (!empty($files['name'][$i])) {
                if ($files['size'][$i] > 2000000) {
                    $this->form_validation->set_message('validate_gallery_images', 'The Image file size shoud not exceed 20MB!');
                    return FALSE;
                }
                $extension = pathinfo($files["name"][$i], PATHINFO_EXTENSION);
                $detectedType = exif_imagetype($files['tmp_name'][$i]);
                if (!in_array($detectedType, $allowedTypes)) {
                    $this->form_validation->set_message('validate_gallery_images', 'Invalid Image Content!');
                    return FALSE;
                }
                if (!in_array($extension, $allowedExts)) {
                    $this->form_validation->set_message('validate_gallery_images', "Invalid file extension {$extension}");
                    return FALSE;
                }
            }
        }
        return TRUE;
    }

/*      | ------------------ |  Admin Login Section  | ------------------ | */

    // View login page 
    public function login()
    {
        $this->load->view('admin/index');
    }

    // Check admin validation
    public function checkAdmin()
    {
        $this->session->unset_userdata('admin');
        $errors = [
            'password' => [
                'validateUser' => 'Email or Password don\'t match'
            ]
        ];
        if ($this->form_validation->run('checkAdmin') == FALSE) {
            $this->load->view('admin/index');
        } else {
            
            $result = $this->AdminModel->checkAdmin();
            if ($result) {
                $this->session->set_userdata('admin', $result['username']);
                $this->session->set_userdata('admin_id', $result['id']);
                redirect('admin/dashboard');
            } else {
                $data['error'] = 'Invalid username or password.';
                $this->load->view('admin/index', $data);     // View the Index(login) page inside admin folder | Not route 
            }
        }
    }

/*      | ------------------ |  Category Section     | ------------------ | */

    // Get all the category details by a serach key.
    public function category($like = "")
    {
        $like = $this->input->get('search');
        
        $categories = $this->AdminModel->getCatagory($like);
        $data['category'] = $categories;
        $this->load->view('admin/category', $data);
    }

    // View Category Add Page
    public function showAddCategory()
    {
        $this->load->view('admin/add_category');
    }

    // Add New category
    public function addCategory()
    {
        if ($this->form_validation->run('addCategory') == FALSE) {
            $this->load->view('admin/add_category');
        } else {
            $config['upload_path'] = './uploads/category';
            $config['allowed_types'] = 'gif|jpg|png';
            $this->load->library('upload', $config);

            if (!$this->upload->do_upload('image')) {
                $this->load->view('admin/add_category');
            } else {
                $formdata = $this->input->post();
                $image = $this->upload->data('file_name');
                
                $result = $this->AdminModel->addCategory();
                if ($result) {
                    $this->session->set_flashdata('message', 'New Category added successfully.');
                    redirect('admin/category');
                } else {
                    $error['error'] = 'Something Went Wrong, Please Try again.';
                    $this->load->view('admin/add_category', $error);     // View the category page with error message 
                }
            }
        }
    }

    // View the category edit page
    public function showEditCategory($id)
    {
        
        $categorie = $this->AdminModel->getCategoryById($id);
        $data['category'] = $categorie;
        $this->load->view('admin/edit_category', $data);
    }

    // Update category details
    public function editCategory()
    {
        $config['upload_path'] = './uploads/category';
        $config['allowed_types'] = 'gif|jpg|png';
        $this->load->library('upload', $config);

        
        $id = $this->input->post('id');

        $this->form_validation->set_rules('name', 'Name', 'required');
        $this->form_validation->set_rules('order', 'Order', 'numeric');

        if (!empty($_FILES['image']['name'])) {
            $this->form_validation->set_rules('image', 'Image', 'callback_validate_image');
        }
        if ($this->form_validation->run() == FALSE) {
            $categorie = $this->AdminModel->getCategoryById($id);
            $data['category'] = $categorie;
            $this->load->view('admin/edit_category', $data);
        } else {
            $this->upload->do_upload('image');
            $result = $this->AdminModel->updateCategory($id);
            if ($result) {
                $this->session->set_flashdata('message', 'Category edit successfully.');
                redirect('admin/category');
            }
        }
    }

    // Delete category details with image
    public function deleteCategory($id)
    {
        
        $category = $this->AdminModel->getCategoryById($id);
        if ($category['num_sub_category'] <= 0) {
            $result = $this->AdminModel->deleteCategory($id);
            if ($result) {
                $path = './uploads/category/' . $category['image'];
                if (file_exists($path)) {
                    unlink($path);
                }
                $this->session->set_flashdata('message', 'Category deleted successfully.');
                redirect('admin/category');
            } else {
                $this->session->set_flashdata('message', 'Something went wrong.');
                redirect('admin/category');
            }
        } else {
            $this->session->set_flashdata('message', 'Sub Category exsist can\'t be deleted');
            redirect('admin/category');
        }
    }

/*      | ------------------ |  Sub-category Section | ------------------ | */

    // Get all the Sub-category details by a search key.
    public function subCategory($like = "")
    {
        $like = $this->input->get('search');
        
        $x = $this->AdminModel->getSubCatagory($like);
        $data['subcategory'] = $x;
        $this->load->view('admin/sub_category', $data);
    }

    // View Sub-category add page
    public function showAddSubCategory()
    {
        
        $categories = $this->AdminModel->getCatagory();
        $data['category'] = $categories;
        $this->load->view('admin/add_subCategory', $data);
    }

    // Add New Sub_category
    public function addSubCategory()
    {
        
        $categories = $this->AdminModel->getCatagory();
        $data['category'] = $categories;

        if ($this->form_validation->run('addSubCategory') == FALSE) {
            $this->load->view('admin/add_subCategory', $data);
        } else {
            // $formdata = $this->input->post();
            
            $result = $this->AdminModel->addSubCategory();
            if ($result) {
                $this->session->set_flashdata('message', 'New Sub Category added successfully.');
                redirect('admin/sub_category');
            } else {
                $error['error'] = 'Something Went Wrong, Please Try again.';
                $this->load->view('admin/add_subCategory', $error);
            }
        }
    }

    // View Sub category edit page
    public function showEditSubCategory($id)
    {
        
        $subCategory = $this->AdminModel->getSubCategoryById($id);
        $categories = $this->AdminModel->getCatagory();
        $data['sub_category'] = $subCategory;
        $data['category'] = $categories;
        $this->load->view('admin/edit_subCategory', $data);
    }

    // Edit Sub category by Sub category id
    public function editSubCategory()
    {
        $id = $this->input->post('id');
        
        $subCategory = $this->AdminModel->getSubCategoryById($id);
        $categories = $this->AdminModel->getCatagory();
        $data['sub_category'] = $subCategory;
        $data['category'] = $categories;
        if ($this->form_validation->run('addSubCategory') == FALSE) {
            $this->load->view('admin/edit_subCategory', $data);
        } else {
            $result = $this->AdminModel->updateSubCategory($id);
            if ($result) {
                $this->session->set_flashdata('message', 'Sub Category edited successfully.');
                redirect('admin/sub_category');
            } else {
                $error['error'] = 'Something Went Wrong, Please Try again.';
                $this->load->view('admin/add_subCategory', $error);
            }
        }
    }

    // Delete Sub_category details 
    public function deleteSubCategory($id)
    {
        
        $sub_category = $this->AdminModel->getSubCategoryById($id);
        if ($sub_category['products'] == 0) {
            $result = $this->AdminModel->deleteSubCategory($id);
            if ($result) {
                $this->session->set_flashdata('message', 'Sub Category deleted successfully.');
                redirect('admin/sub_category');
            } else {
                $this->session->set_flashdata('message', 'Something went wrong.');
                redirect('admin/sub_category');
            }
        } else {
            $this->session->set_flashdata('message', 'Product exsist can\'t be deleted');
            redirect('admin/sub_category');
        }
    }

/*      | ------------------ |  Product Section      | ------------------ | */

    // Get all the product details with category and subcategory by a search key...
    public function product($like = "")
    {
        $like = $this->input->get('search');
        $x = $this->AdminModel->getProduct($like);
        $data['product'] = $x;
        $this->load->view('admin/products', $data);
    }

    // View product add page
    public function showAddProduct(){
        $categories = $this->AdminModel->getCatagory();
        $data['categories'] = $categories;
        $this->load->view('admin/add_product', $data);
    }

    // Get sub-category by category id
    public function getSubCategoryByCategoryId()
    {
        $category_id = $this->input->post('category_id');
        $sub_categories = $this->AdminModel->getSubCategoryByCategoryId($category_id);
        echo json_encode($sub_categories);
    }

    // Add New Product
    public function addProduct()
    {
        $categories = $this->AdminModel->getCatagory();
        $data['categories'] = $categories;
        if ($this->form_validation->run('addProduct') == FALSE) {
            $this->load->view('admin/add_product', $data);
        } else {
            $featuredImage = $_FILES['image'];
            if ($featuredImage['error'] == 0) {
                resizeImage($featuredImage['tmp_name'], './uploads/lg/' . $featuredImage['name'], 800, 800);
                resizeImage($featuredImage['tmp_name'], './uploads/md/' . $featuredImage['name'], 420, 420);
                resizeImage($featuredImage['tmp_name'], './uploads/sm/' . $featuredImage['name'], 50, 50);
            }
            $galleryImages = $_FILES['gallery'];
            if ($galleryImages['error'][0] == 0) {
                foreach ($galleryImages['tmp_name'] as $key => $tmpName) {
                    resizeImage($tmpName, './uploads/lg/' . $galleryImages['name'][$key], 800, 800);
                    resizeImage($tmpName, './uploads/md/' . $galleryImages['name'][$key], 420, 420);
                    resizeImage($tmpName, './uploads/sm/' . $galleryImages['name'][$key], 50, 50);
                }
            }
            $result = $this->AdminModel->addProduct();
            if (isset($_FILES['gallery']) && $_FILES['gallery']['error'][0] == 0) {
                $insert_id = $this->db->insert_id();
                $this->AdminModel->addProductGallery($insert_id, $_FILES['gallery']);
            }
            if ($result) {
                $this->session->set_flashdata('message', 'New Product added successfully.');
                redirect('admin/product');
            } else {
                $data['error'] = 'Something Went Wrong, Please Try again.';
                $this->load->view('admin/add_product', $data);    
            }
        }
    }

    // View Product edit page
    public function showEditProduct($id)
    {
        $product = $this->AdminModel->getProductById($id);
        $data['product'] = $product;
        $categories = $this->AdminModel->getCatagory();
        $data['categories'] = $categories;
        $sub_categories = $this->AdminModel->getSubCategoryByCategoryId($product['category']);
        $data['sub_categories'] = $sub_categories;
        $gallery = $this->AdminModel->getGalleryByProductId($id);
        $data['gallery'] = $gallery;
        $this->load->view('admin/edit_product', $data);
    }

    // Edit Product by Product id
    public function editProduct()
    {
        $id = $this->input->post('id');
        
        $product = $this->AdminModel->getProductById($id);
        $data['product'] = $product;
        $categories = $this->AdminModel->getCatagory();
        $data['categories'] = $categories;
        $sub_categories = $this->AdminModel->getSubCategoryByCategoryId($product['category']);
        $data['sub_categories'] = $sub_categories;
        $gallery = $this->AdminModel->getGalleryByProductId($id);
        $data['gallery'] = $gallery;
        
        $this->form_validation->set_rules('category', 'Category', 'required');
        $this->form_validation->set_rules('sub_category', 'Sub Category', 'required');
        $this->form_validation->set_rules('name', 'Name', 'required');
        $this->form_validation->set_rules('price', 'Price', 'required|numeric');
        if(!empty($_FILES['image']['name'])) {
            $this->form_validation->set_rules('image', 'Featured Image', 'callback_validate_image');
        }
        if(!empty($_FILES['gallery']['name'][0])) {
            $this->form_validation->set_rules('gallery[]', 'Gallery Image', 'callback_validate_gallery_images');
        }

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('admin/edit_product', $data);
        } else {
            // Main Product Edit Portion
            if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
                resizeImage($_FILES['image']['tmp_name'], './uploads/lg/' . $_FILES['image']['name'], 800, 800);
                resizeImage($_FILES['image']['tmp_name'], './uploads/md/' . $_FILES['image']['name'], 420, 420);
                resizeImage($_FILES['image']['tmp_name'], './uploads/sm/' . $_FILES['image']['name'], 50, 50);
            }
            $x = (array) json_decode($this->input->post('trash'));
            foreach ($x as $old_gallery) {
                echo $old_gallery."<br>";
                $this->AdminModel->deleteProductGallery($old_gallery);
            }
            if (isset($_FILES['gallery']) && $_FILES['gallery']['error'][0] == 0) {
                foreach ($_FILES['gallery']['tmp_name'] as $key => $tmpName) {
                    resizeImage($tmpName, './uploads/lg/' . $_FILES['gallery']['name'][$key], 800, 800);
                    resizeImage($tmpName, './uploads/md/' . $_FILES['gallery']['name'][$key], 420, 420);
                    resizeImage($tmpName, './uploads/sm/' . $_FILES['gallery']['name'][$key], 50, 50);
                }
            }
            $result = $this->AdminModel->updateProduct($id);
            if (isset($_FILES['gallery']) && $_FILES['gallery']['error'][0] == 0) {
                $this->AdminModel->updateProductGallery($id, $_FILES['gallery']);
            }
            if ($result) {
                $this->session->set_flashdata('message', 'Product edited successfully.');
                redirect('admin/product');
            } else {
                $data['error'] = 'Something Went Wrong, Please Try again.';
                $this->load->view('admin/edit_product', $data);
            }
        }
    }

    // Delete Product By product id
    public function deleteProduct($id){
        $result = $this->AdminModel->deleteProduct($id);
        if ($result) {
            $images = $this->AdminModel->getGalleryByProductId($id);
            foreach ($images as $image) {
                $lg_path = './uploads/lg/'. $image['image'];
                $md_path = './uploads/md/'. $image['image'];
                $sm_path = './uploads/sm/'. $image['image'];
                uplink($lg_path);
                uplink($md_path);
                uplink($sm_path);
            }
            $this->session->set_flashdata('message', 'Product deleted successfully.');
            redirect('admin/product');
        } else {
            $this->session->set_flashdata('message', 'Something went wrong. Please try again.');
            redirect('admin/product');
        }
    }
    
/*      | ------------------ |  Order Section        | ------------------ | */

    // Get all the order details by a search key.
    public function orders($like = "")
    {
        $like = $this->input->get('search');
        $data['orders'] = $this->AdminModel->getOrders($like);
        $this->load->view('admin/orders', $data);
    }

    // View Order edit page
    public function showEditOrder($id)
    {
        $order = $this->AdminModel->getOrderDetailsById($id);
        $data['order'] = $order;
        $items = $this->AdminModel->getItemsByOrderId($id);
        $data['items'] = $items;
        $shipping = $this->AdminModel->getAddressById($order['shpg_address']);
        $data['shipping'] = $shipping;
        $billing = $this->AdminModel->getAddressById($order['bill_address']);
        $data['billing'] = $billing;
        $this->load->view('admin/edit_order', $data);
    }

    // Edit Order by Order id
    public function editOrder()
    {
        $id = $this->input->post('ord_id');
        $result = $this->AdminModel->updateOrder($id);
        if ($result) {
            $this->session->set_flashdata('message', 'Order updated successfully.');
            redirect('admin/orders');
        } else {
            $this->session->set_flashdata('message', 'Something went wrong. Please try again.');
            redirect('admin/orders');
        }
    }

    // Delete Order by Order id
    public function deleteOrder($id)
    {
        $result = $this->AdminModel->deleteOrder($id);
        if ($result) {
            $this->session->set_flashdata('message', 'Order deleted successfully.');
            redirect('admin/orders');
        } else {
            $this->session->set_flashdata('message', 'Something went wrong. Please try again.');
            redirect('admin/orders');
        }
    }

/*      | ------------------ |  Discount Section     | ------------------ | */

    public function discount($like = "")
    {
        $like = $this->input->get('search');
        $data['data'] = $this->AdminModel->getDiscounts($like);
        $this->load->view('admin/discount', $data);
    }

    // View Discount add page
    public function showAddDiscount()
    {
        $this->load->view('admin/add_discount');
    }

    //Edit Discount by Discount id
    public function addDiscount()
    {
        if ($this->form_validation->run('addDiscount') == FALSE) {
            $this->load->view('admin/add_discount');
        } else {
            $result = $this->AdminModel->addDiscount();
            if ($result) {
                $this->session->set_flashdata('message', 'Discount added successfully.');
                redirect('admin/discount');
            } else {
                $data['error'] = 'Something went wrong. Please try again.';
                $discount = $this->AdminModel->getDiscounts();
                $data['discount'] = $discount;
                $this->load->view('admin/add_discount', $data);
            }
        }
    }

    // View Discount edit page
    public function showEditDiscount($id)
    {
        $discount = $this->AdminModel->getDiscountById($id);
        $data['discount'] = $discount;
        $this->load->view('admin/edit_discount', $data);
    }

    // Edit Discount by Discount id
    public function editDiscount()
    {
        $id = $this->input->post('id');
        $discount = $this->AdminModel->getDiscountById($id);
        $data['discount'] = $discount;
        if ($this->form_validation->run('addDiscount') == FALSE) {
            $this->load->view('admin/edit_discount', $data);
        } else {
            $result = $this->AdminModel->updateDiscount($id);
            if ($result) {
                $this->session->set_flashdata('message', 'Discount edited successfully.');
                redirect('admin/discount');
            } else {
                $data['error'] = 'Something went wrong. Please try again.';
                $this->load->view('admin/edit_discount', $data);
            }
        }
    }

    // Delete Discount by Discount id
    public function deleteDiscount($id)
    {
        $result = $this->AdminModel->deleteDiscount($id);
        if ($result) {
            $this->session->set_flashdata('message', 'Discount deleted successfully.');
            redirect('admin/discount');
        } else {
            $this->session->set_flashdata('message', 'Something went wrong. Please try again.');
            redirect('admin/discount');
        }
    }

/*      | ------------------ |  Customer Section     | ------------------ | */

    // View Customer page
    public function customer()
    {
        $like = $this->input->get('search');
        $data['customers'] = $this->AdminModel->getCustomers($like);
        $this->load->view('admin/customer', $data);
    }

    // View Customer edit page
    public function showEditCustomer($id)
    {
        $customer = $this->AdminModel->getCustomerById($id);
        $data['customer'] = $customer;
        $addresses = $this->AdminModel->getAddressByUserId($id);
        $data['addresses'] = $addresses;
        $this->load->view('admin/edit_customer', $data);
    }

    // Edit Customer by Customer id
    public function editCustomer()
    {
        $uid = $this->input->post('uid');
        $result = $this->AdminModel->updateCustomer($uid);
        $resultAddress = $this->AdminModel->getAddressByUserId($uid);
        $count = count($resultAddress);
        if ($count > 0) {
            for ($i = 1; $i <= $count; $i++) {
                $address = $this->input->post('ads_id'.$i);
                $this->AdminModel->updateAddress($address, $i);
            }
        }
        if ($result && $resultAddress) {
            $this->session->set_flashdata('message', 'Customer updated successfully.');
            redirect('admin/customer');
        } else {
            $data['error'] = 'Something went wrong. Please try again.';
            $this->showEditCustomer($uid);
        }

    }

    // View Customer Order page
    public function customerOrder($id)
    {
        $data['orders'] = $this->AdminModel->getOrdersByUserId($id);
        $this->load->view('admin/customer_order', $data);
    }

    // Delete Customer by Customer id
    public function deleteCustomer($id)
    {
        $result = $this->AdminModel->deleteCustomer($id);
        if ($result) {
            $this->session->set_flashdata('message', 'Customer deleted successfully.');
            redirect('admin/customer');
        } else {
            $this->session->set_flashdata('message', 'Something went wrong. Please try again.');
            redirect('admin/customer');
        }
    }

    /*      | ------------------ |  Setting Section      | ------------------ | */

    // Show setting page
    public function setting()
    {
        $id = $this->session->userdata('admin_id');
        
        $settings = $this->AdminModel->getSettings($id);
        $data['settings'] = $settings;
        $this->load->view('admin/setting', $data);
    }

    // Update admin details
    public function updateSetting()
    {
        $id = $this->session->userdata('admin_id');
        $result = $this->AdminModel->updateSetting($id);
        if ($result) {
            $this->session->set_flashdata('message', 'Settings updated successfully.');
            redirect('admin/setting');
        } else {
            $this->session->set_flashdata('message', 'Something went wrong. Please try again.');
            redirect('admin/setting');
        }
    }

}