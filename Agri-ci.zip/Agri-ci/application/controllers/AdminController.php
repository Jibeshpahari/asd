<?php
    
    defined('BASEPATH') OR exit('No direct script access allowed');

    class AdminController extends CI_Controller {

        // function __construct(){
        //     parent::__construct();
        //     if($this->session->userdata('admin') == ''){
        //         redirect('admin/login');
        //     }
        // }

        // View the dashboard page
         public function index(){
            $this->load->view('admin/dashboard');
        }

//      | ------------------ | Login for admin | ------------------ |
        // View login page 
        public function login(){
            $this->load->view('admin/index');
        }

        // Check admin validation
        public function checkAdmin(){
            $this->session->unset_userdata('admin');
            $errors = [
                'password' => [
                    'validateUser' => 'Email or Password don\'t match'
                ]
            ];
            if($this->form_validation->run('checkAdmin') == FALSE)
            {
                $this->load->view('admin/index');
            }
            else
            {
                $this->load->model('AdminModel');
                $result = $this->AdminModel->checkAdmin();
                if($result){
                    $this->session->set_userdata('admin', $result['username']);
                    redirect('admin/dashboard');
                }else{
                    $data['error'] = 'Invalid username or password.';
                    $this->load->view('admin/index', $data);     // View the Index(login) page inside admin folder | Not route 
                }
            }

        }

        // Get all the category details by a serach key.
        public function category($like=""){
            $like = $this->input->get('search');
            $this->load->model('AdminModel');
            $categories = $this->AdminModel->getCatagory($like);
            $data['category'] = $categories;
            $this->load->view('admin/category', $data);
	    }
        
        // View Add category page
        public function addCategory(){
            $this->load->view('admin/add_category');   
        }

        public function validate_image() {
            if ((!isset($_FILES['image'])) || $_FILES['image']['size'] == 0) {
                $this->form_validation->set_message('validate_image', 'Something is Wrong With This {field}, Try Other One');
                return FALSE;
            }
            else if (isset($_FILES['image']) && $_FILES['image']['size'] != 0) {
                $allowedExts = array("gif", "jpeg", "jpg", "png", "JPG", "JPEG", "GIF", "PNG");
                $allowedTypes = array(IMAGETYPE_PNG, IMAGETYPE_JPEG, IMAGETYPE_GIF);
                $extension = pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION);
                $detectedType = exif_imagetype($_FILES['image']['tmp_name']);
                $type = $_FILES['image']['type'];
                if (!in_array($detectedType, $allowedTypes)) {
                    $this->form_validation->set_message('validate_image', 'Invalid Image Content!');
                    return FALSE;
                }
                if(filesize($_FILES['image']['tmp_name']) > 2000000) {
                    $this->form_validation->set_message('validate_image', 'The Image file size shoud not exceed 20MB!');
                    return FALSE;
                }
                if(!in_array($extension, $allowedExts)) {
                    $this->form_validation->set_message('validate_image', "Invalid file extension {$extension}");
                    return FALSE;
                }
            }
            return TRUE;
        }

        public function insertCategory(){

            if ($this->form_validation->run('addCategory') == FALSE) {
                $this->load->view('admin/add_category');
            } 
            else 
            {
                $config['upload_path'] = './uploads/category';
                $config['allowed_types'] = 'gif|jpg|png';
                $this->load->library('upload', $config);

                if (!$this->upload->do_upload('image')) {
                    $this->load->view('admin/add_category', $data);
                } else {
                    $formdata = $this->input->post();
                    $image = $this->upload->data('file_name');
                    $this->load->model('AdminModel');
                    $result = $this->AdminModel->addCategory();
                    if($result){
                        redirect('admin/category');
                    }else{
                        $error['error'] = 'Something Went Wrong, Please Try again.';
                        $this->load->view('admin/add_category', $error);     // View the category page with error message 
                    }
                }
            }
        }

        public function deleteCategory($id){
            $this->load->library('encryption');
            $encrypted_id = urlencode('12');
            echo $encrypted_id;

        }

        // Get all the Sub-category details by a search key.
        public function subCategory($like=""){
            $like = $this->input->get('search');
            $this->load->model('AdminModel');
            $x = $this->AdminModel->getSubCatagory($like);
            $data['subcategory'] = $x;
            $this->load->view('admin/sub_category',$data);
        }

        // Get all the product details with category and subcategory by a search key...
        public function product($like=""){
            $like = $this->input->get('search');
            $this->load->model('AdminModel');
            $x = $this->AdminModel->getProduct($like);
            $data['product'] = $x;
            $this->load->view('admin/products',$data);
        }


    }


?>