<div class="row">
<?php
    foreach ($products as $product) {
?>
    <div class="product-layout product-grid col-lg-4 col-md-4 col-sm-6 col-xs-12">
        <div class="product-thumb transition">
            <div class="image">
                <a href="<?= base_url('product/' . $product['id']); ?>">
                    <img src="<?= base_url('uploads/md/'.$product['featured_img']); ?>" alt="" title="" class="img-responsive" />
                </a>
            </div>
            <div class="caption">
                <h4>
                    <a href="<?= base_url('product/' . $product['id']); ?>"><?php echo $product['name']; ?></a>
                </h4>
                    <div class="rating">
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i
                                class="fa fa-star-o fa-stack-2x"></i></span>
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i
                                class="fa fa-star-o fa-stack-2x"></i></span>
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i
                                class="fa fa-star-o fa-stack-2x"></i></span>
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i
                                class="fa fa-star-o fa-stack-2x"></i></span>
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i
                                class="fa fa-star-o fa-stack-2x"></i></span>
                    </div>
                    <p class="price">&#8364; <?php echo $product['price']; ?></p>
                </div>
            </div>
        </div>
        <?php
            }
            if(empty($products)) {
                echo '<div class="col-sm-12 text-center"><h3>No Products Found</h3></div>';
            }
        ?>
    </div>

    <div class="row">
        <div class="col-sm-6 text-left"></div>
        <div class="col-sm-6 text-right">Showing <?= isset($product) ? 1 : 0 ?> to <?= count($products) ?> of <?= isset($showing)? $showing : count($products) ?> (1 Pages)</div>
    </div>
</div>