<?php
  $title['page'] = 'subCategory';
  $this->load->view('includes/admin-header.php',$title);
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <!-- Horizontal Form -->
            <div class="card card-outline card-info">
              <div class="card-header">
                <h3 class="card-title text-capitalize text-indigo text-lg text-bold" >Edit Sub Category </h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form class="form-horizontal" method="POST" action="<?= base_url('admin/sub_category/action/edit'); ?>" enctype="multipart/form-data" onsubmit="">
                <!-- <input type="hidden" value="" name="page"> -->
                 <input type="hidden" value="<?= $sub_category['id']; ?>" name="id">
                <div class="card-body">
                  <div class="form-group row">
                    <label for="category" class="col-sm-2 col-form-label">Category <span class="text-danger">*</span> </label>
                    <div class="col-sm-10">
                        <select class="form-control" name="category" id="category" >
                          <option value=""> -- Choose -- </option>
                          <?php
                            foreach($category as $row){
                          ?>
                            <option value="<?= $row['id']; ?>" <?= set_select('category',  $row['id'], $sub_category['category_id'] == $row['id']); ?> > <?= $row['name']; ?></option>
                          <?php
                            }
                          ?>
                        </select>
                    </div>
                    <?php echo form_error('category','<p class="text-danger mb-0">','</p>'); ?>
                  </div>
                  <div class="form-group row">
                    <label for="name" class="col-sm-2 col-form-label"> Name <span class="text-danger">*</span> </label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="name" value="<?= set_value('name',$sub_category['name']); ?>" name="name" placeholder="Name">
                      <?php echo form_error('name','<p class="text-danger mb-0">','</p>'); ?>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="order" class="col-sm-2 col-form-label"> Order </label>
                    <div class="col-sm-10">
                      <input type="number" class="form-control" id="order" name="order" value="<?= set_value('order',$sub_category['ranking']); ?>" placeholder="Order" onkeypress="return isNumberKey(event)">
                      <?php echo form_error('order','<p class="text-danger mb-0">','</p>'); ?>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="status" class="col-sm-2 col-form-label">Status</label>
                    <div class="col-sm-10">
                      <div class="form-group">
                        <select class="form-control" name="status" id="status" >
                          <option value="ACTIVE" <?= set_select('status', 'ACTIVE', $sub_category['status'] == 'ACTIVE'); ?> >ACTIVE</option>
                          <option value="DEACTIVE" <?= set_select('status', 'DEACTIVE', $sub_category['status'] == 'DEACTIVE'); ?> >DEACTIVE</option>
                        </select>
                      </div>
                      <?php echo form_error('status','<p class="text-danger mb-0">','</p>'); ?>
                    </div>
                  </div>
                  <div class="alert alert-danger w-50 mx-auto d-none text-center" role="alert" id="alertBox">
                  </div>
                <!-- /.card-body -->
                <div class="card-footer text-center">
                  <button type="submit" class="btn btn-success">Update</button>
                  <button type="reset" class="btn btn-warning ml-5">Reset</button>
                </div>
              </form>
            </div>
            <!-- /.card -->
             
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->


<?php
  $this->load->view('includes/admin-footer.php');
?>