
<?php
    $title['page'] = 'setting';
    $this->load->view('includes/admin-header.php',$title);
    $row = $settings;
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper p-2">
    <div class="pl-3">
        <p class="h4 font-weight-bold text-info"><u>Setting</u></p>
    </div>
    <div class="card card-outline card-info">
        <form method="POST" action="<?= base_url('admin/setting/action/update'); ?>" >
        <?php
            if($this->session->flashdata('message') !== null ){  
                echo '<div class="alert alert-warning mx-auto w-50 text-center py-2 mt-3">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.
                $this->session->flashdata('message')
                .'</div>'; 
            }        
        ?>
            <div class="row px-5 mt-4 mb-2">
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="username">Username(Admin Mail)</label>
                        <input type="text" name="username" id="username" value="<?= set_value('username', $row['username']);?>" class="form-control" placeholder="Username(Admin Mail)">
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="password">Password</label>
                        <div class="input-group">
                            <input type="password" name="password" id="password" value="" class="form-control" placeholder="Password">
                            <div class="input-group-append">
                                <span class="input-group-text" id="showpass">Show</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 d-none">
                    <div class="form-group">
                        <label for="new_password">New Password</label>
                        <div class="input-group">
                            <input type="password" name="new_password" id="new_password" value="" class="form-control" placeholder="New Password">
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 d-none">
                    <div class="form-group">
                        <label for="c_password">Confirm Password</label>
                        <div class="input-group">
                            <input type="password" name="c_password" id="c_password" value="" class="form-control" placeholder="Confirm Password">
                        </div>
                    </div>
                </div>
            </div>
            <div class="text-right px-5 mb-4">
                <button class="btn btn-success" type="submit" >Save</button>
            </div>
        </form>
    </div>
    <div class="alert w-50 mx-auto text-center d-none py-2 px-4 mt-2" role="alert" id="alertBox">
    </div>
    

<?php
  $this->load->view('includes/admin-footer.php');
?>