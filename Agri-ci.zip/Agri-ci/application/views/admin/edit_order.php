<?php
  $title['page'] = 'orders';
  $this->load->view('includes/admin-header.php', $title);
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper p-2">
    <div class="pl-3">
        <p class="h3 font-weight-bold text-info"><u>Edit Order</u></p>
    </div>
    <div class="card card-outline card-info">
        <form method="POST" action="<?= base_url('admin/orders/edit/action') ?>" >
            <div class="row px-3 mt-4 mb-2">
                <div class="col-12">
                    <h3>Product Details</h3>
                    <hr>
                </div>
            <?php 
                $i =1;
                foreach ( $items as $item){
            ?>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="username">Prouct <?php echo $i++; ?></label>
                        <input type="text" value="<?php echo $item['product_name']; ?>" class="form-control" disabled>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="form-group">
                        <label for="password">Quantity</label>
                        <input type="text" value="<?php echo $item['qty']; ?>" class="form-control" disabled>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="form-group">
                        <label for="password">Price</label>
                        <input type="text" value="<?php echo $item['price']; ?>" class="form-control" disabled>
                    </div>
                </div>
            <?php
                }
            ?>
                <div class="col-12 mt-4">
                    <h3>Address Details</h3>
                    <hr>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="username">Delivery Address</label>
                        <input type="text" value="<?php echo $shipping['address1']; ?>" class="form-control" disabled>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="password">Billing Address</label>
                        <input type="text" value="<?php echo $billing['address1']; ?>" class="form-control" disabled>
                    </div>
                </div>

                <div class="col-12 mt-4">
                    <h3>Billing Details</h3>
                    <hr>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="username">SubTotal</label>
                        <input type="text" value="<?php echo $order['sub_total']; ?>" class="form-control" disabled>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="password">Eco Tax(-2.00)</label>
                        <input type="text" value="<?php echo $order['tax']; ?>" class="form-control" disabled>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="password">VAT(20%)</label>
                        <input type="text" value="<?php echo $order['vat']; ?>" class="form-control" disabled>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="password">Discount</label>
                        <input type="text" value="<?php echo $order['discount']; ?>" class="form-control" disabled>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="password">Total</label>
                        <input type="text" value="<?php echo $order['total_price']; ?>" class="form-control" disabled>
                    </div>
                </div>

                <div class="col-12 mt-4">
                    <h3>Payment Details</h3>
                    <hr>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="username">Payment Mode</label>
                        <input type="text" value="<?php echo $order['pay_method']; ?>" class="form-control" disabled>
                    </div>
                </div>
                <?php
                $date1 = date_create($order['ord_date']);
                $date = date_format($date1,"d-M-Y");
                ?>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="password">Order Date</label>
                        <input type="text" value="<?php echo $date; ?>" class="form-control" disabled>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="password">Transanction Id</label>
                        <input type="text" value="" class="form-control" disabled>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="password">Order Status</label>
                        <select class="form-control" name="ord_status" id="" required>
                        <option value="PROCESSING" <?= set_select('ord_status', 'PROCESSING', $order['ord_status']=='PROCESSING'); ?>>PROCESSING</option>
                          <option value="SHIPPTED" <?= set_select('ord_status', 'SHIPPTED', $order['ord_status']=='SHIPPTED'); ?>>SHIPPED</option>
                          <option value="COMPLETED" <?= set_select('ord_status', 'COMPLETED', $order['ord_status']=='COMPLETED'); ?>>COMPLETED</option>
                        </select>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="password">Payment Status</label>
                        <select class="form-control" name="pay_status" id="" required>
                            <option value="SUCCESSFULL" <?= set_select('pay_status', 'SUCCESSFULL', $order['pay_status']=='SUCCESSFULL'); ?>>SUCCESSFULL</option>
                            <option value="UNSUCCESSFULL" <?= set_select('pay_status', 'UNSUCCESSFULL', $order['pay_status']=='UNSUCCESSFULL'); ?>>UNSUCCESSFULL</option>
                        </select>
                    </div>
                </div>
                <input type="hidden" name="ord_id" value="<?php echo $order['id']; ?>">
            </div>

            <div class="text-center mb-4">
                <button class="btn btn-success" type="submit" >Save</button>
                <button class="btn btn-warning ml-4" type="reset" >Reset</button>
            </div>
        </form>
    </div>
    <div class="alert w-50 mx-auto text-center d-none py-2 px-4 mt-2" role="alert" id="alertBox">
    </div>
    

<?php
  $this->load->view('includes/admin-footer.php');
?>