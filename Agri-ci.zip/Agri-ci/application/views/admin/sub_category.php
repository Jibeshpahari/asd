<?php
  $title['page'] = 'subCategory';
  $this->load->view('includes/admin-header.php',$title);
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper p-2">
    <div class="pl-3">
        <p class="h4 font-weight-bold text-info"><u>Sub Category</u></p>
    </div>
    <div class="card card-outline card-info">
        <div class="d-flex justify-content-center g-5 p-2">
          <a href="<?php echo base_url('admin/sub_category'); ?>"><button class="btn btn-success py-0 px-2 mr-1">ALL</button></a>
          <a href="<?php echo base_url(); ?>admin/subCategory?search=A"><button class="btn btn-success py-0 px-2 mr-1">A</button></a>
          <a href="<?php echo base_url(); ?>admin/subCategory?search=B"><button class="btn btn-success py-0 px-2 mr-1">B</button></a>
          <a href="<?php echo base_url(); ?>admin/subCategory?search=C"><button class="btn btn-success py-0 px-2 mr-1">C</button></a>
          <a href="<?php echo base_url(); ?>admin/subCategory?search=D"><button class="btn btn-success py-0 px-2 mr-1">D</button></a>
          <a href="<?php echo base_url(); ?>admin/subCategory?search=E"><button class="btn btn-success py-0 px-2 mr-1">E</button></a>
          <a href="<?php echo base_url(); ?>admin/subCategory?search=F"><button class="btn btn-success py-0 px-2 mr-1">F</button></a>
          <a href="<?php echo base_url(); ?>admin/subCategory?search=G"><button class="btn btn-success py-0 px-2 mr-1">G</button></a>
          <a href="<?php echo base_url(); ?>admin/subCategory?search=H"><button class="btn btn-success py-0 px-2 mr-1">H</button></a>
          <a href="<?php echo base_url(); ?>admin/subCategory?search=I"><button class="btn btn-success py-0 px-2 mr-1">I</button></a>
          <a href="<?php echo base_url(); ?>admin/subCategory?search=J"><button class="btn btn-success py-0 px-2 mr-1">J</button></a>
          <a href="<?php echo base_url(); ?>admin/subCategory?search=K"><button class="btn btn-success py-0 px-2 mr-1">K</button></a>
          <a href="<?php echo base_url(); ?>admin/subCategory?search=L"><button class="btn btn-success py-0 px-2 mr-1">L</button></a>
          <a href="<?php echo base_url(); ?>admin/subCategory?search=M"><button class="btn btn-success py-0 px-2 mr-1">M</button></a>
          <a href="<?php echo base_url(); ?>admin/subCategory?search=N"><button class="btn btn-success py-0 px-2 mr-1">N</button></a>
          <a href="<?php echo base_url(); ?>admin/subCategory?search=O"><button class="btn btn-success py-0 px-2 mr-1">O</button></a>
          <a href="<?php echo base_url(); ?>admin/subCategory?search=P"><button class="btn btn-success py-0 px-2 mr-1">P</button></a>
          <a href="<?php echo base_url(); ?>admin/subCategory?search=Q"><button class="btn btn-success py-0 px-2 mr-1">Q</button></a>
          <a href="<?php echo base_url(); ?>admin/subCategory?search=R"><button class="btn btn-success py-0 px-2 mr-1">R</button></a>
          <a href="<?php echo base_url(); ?>admin/subCategory?search=S"><button class="btn btn-success py-0 px-2 mr-1">S</button></a>
          <a href="<?php echo base_url(); ?>admin/subCategory?search=T"><button class="btn btn-success py-0 px-2 mr-1">T</button></a>
          <a href="<?php echo base_url(); ?>admin/subCategory?search=U"><button class="btn btn-success py-0 px-2 mr-1">U</button></a>
          <a href="<?php echo base_url(); ?>admin/subCategory?search=V"><button class="btn btn-success py-0 px-2 mr-1">V</button></a>
          <a href="<?php echo base_url(); ?>admin/subCategory?search=W"><button class="btn btn-success py-0 px-2 mr-1">W</button></a>
          <a href="<?php echo base_url(); ?>admin/subCategory?search=X"><button class="btn btn-success py-0 px-2 mr-1">X</button></a>
          <a href="<?php echo base_url(); ?>admin/subCategory?search=Y"><button class="btn btn-success py-0 px-2 mr-1">Y</button></a>
          <a href="<?php echo base_url(); ?>admin/subCategory?search=Z"><button class="btn btn-success py-0 px-2 mr-1">Z</button></a>
        </div>
        <hr>
        <div class="px-5">
          <form method="GET" action="<?php echo base_url(); ?>admin/subCategory">
            <div class="form-group px-5 d-flex">
              <input type="search" class="form-control" name="search" id=""  placeholder="Search...">
              <button type="submit" class="btn btn-success ml-3">Submit</button>
            </div>
          </form>
        </div>
    </div>
    <?php 
        if(isset($error)){  echo '<div class="alert alert-danger">'.$error.'</div>'; }
        if($this->session->flashdata('message') !== null ){  
          echo '<div class="alert alert-warning mx-auto w-50 text-center py-2">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.
            $this->session->flashdata('message')
          .'</div>'; 
        }
    ?>
    <div class="px-5 my-3 text-right">
        <a href="<?= base_url('admin/sub_category/add'); ?>"><button class="btn btn-success">ADD NEW</button></a>
    </div>
    <!-- Content Header (Page header) -->
    <div class="card-body p-0">
                <table class="table table-striped">
                  <thead>
                    <tr>
                      <th class="text-center">No.</th>
                      <th class="text-center">Sub Category Name</th>
                      <th class="text-center">Order</th>
                      <th class="text-center">Parent Category</th>
                      <th class="text-center">Status</th>
                      <th class="text-center">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                      if($subcategory){
                        $i=1;
                        foreach($subcategory as $row){
                    ?>
                    <tr>
                      <td class="text-center"><?php echo $i++; ?></td>
                      <td class="text-center"><?php echo $row['name'] ?></td>
                      <td class="text-center"><?php echo $row['ranking'] ?></td>
                      <td class="text-center"><?php echo $row['category'] ?></td>
                      <td class="text-center"><?php echo $row['status'] ?></td>
                      <td class="text-center">
                        <a href="<?= base_url('admin/sub_category/edit/'.$row['id']); ?> "><button class="btn btn-info py-1">EDIT</button></a> 
                        <a href="<?= base_url('admin/sub_category/delete/'.$row['id']); ?> "><button class="btn btn-danger py-1">DELETE</button></a>
                      </td>
                    </tr>
                    <?php
                        }
                      }else{
                        echo "<tr><td class='text-center ' colspan='5'> No Data Found </td></tr>";
                      }
                    ?>
                  </tbody>
                </table>
              </div>
             
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->



<?php
  $this->load->view('includes/admin-footer.php');
?>