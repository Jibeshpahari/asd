<?php
  $title['page'] = 'orders';
  $this->load->view('includes/admin-header.php', $title);
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper p-2">
    <div class="pl-3">
        <p class="h4 font-weight-bold text-info"><u>Orders</u></p>
    </div>
    <div class="card card-outline card-info px-5 py-3">
        <form method="GET" action="<?= base_url('admin/orders'); ?>">
            <div class="form-group px-5 d-flex">
                <label class="mr-3 text-nowrap align-content-center" > Order Id: </label>
              <input type="search" class="form-control" name="search" id=""  placeholder="Search...">
              <button type="submit" class="btn btn-success ml-3">Submit</button>
            </div>
        </form>
    </div>
    <?php 
        if(isset($error)){  echo '<div class="alert alert-danger">'.$error.'</div>'; }
        if($this->session->flashdata('message') !== null ){  
          echo '<div class="alert alert-warning mx-auto w-50 text-center py-2">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.
            $this->session->flashdata('message')
          .'</div>'; 
        }
    ?>  
    <!-- Content Header (Page header) -->
    <div class="card-body card-outline card-info p-0">
                <table class="table table-striped">
                  <thead>
                    <tr>
                      <th class="text-center">Order ID</th>
                      <th class="text-center">Deliver To</th>
                      <th class="text-center">Date</th>
                      <th class="text-center">Price($)</th>
                      <th class="text-center">Status</th>
                      <th class="text-center">Who Ordered</th>
                      <th class="text-center">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                      foreach($orders as $row){ 
                         $date = $row['ord_date'];
                         $date1 = date_create($date);
                         $date = date_format($date1,"d-M-Y");
                    ?>
                    <tr>
                      <td class="text-center"><?php echo $row['id'] ?> </td>
                      <td class="text-center"><?php echo $row['address1'] ?> </td>
                      <td class="text-center"><?php echo $date ?> </td>
                      <td class="text-center"><?php echo $row['total_price'] ?> </td>
                      <td class="text-center"><?php echo $row['ord_status'] ?> </td>
                      <td class="text-center"><?php echo $row['fname'].' '.$row['lname']; ?> </td>
                      <td class="text-center">
                        <a href="<?= base_url('admin/orders/edit/'.$row['id']) ?>"><button class="btn btn-info py-1">VIEW</button></a> 
                        <a href=""><button class="btn btn-warning py-1">Cancel</button></a>
                        <a href="<?= base_url('admin/orders/delete/'.$row['id']) ?>"><button class="btn btn-danger py-1">DELETE</button></a>
                      </td>
                    </tr>
                    <?php
                      }
                    ?>
                  </tbody>
                </table>
              </div>
             
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->


<?php
  $this->load->view('includes/admin-footer.php');
?>