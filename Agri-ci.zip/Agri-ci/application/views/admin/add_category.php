<?php
$title['page'] = 'category';
$this->load->view('includes/admin-header.php', $title);
?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <!-- Horizontal Form -->
  <div class="card card-outline card-info">
    <div class="card-header">
      <h3 class="card-title text-capitalize text-indigo text-lg text-bold">Add New Category</h3>
    </div>
    <!-- /.card-header -->

    <!-- form start -->
    <form class="form-horizontal" method="POST" action="<?php echo base_url(); ?>admin/category/add/action" enctype="multipart/form-data" onsubmit="">
      <!-- <input type="hidden" value="" name="page"> -->
      <div class="card-body">
        <?php
        if (isset($error)) {
          echo '<div class="alert alert-danger">' . $error . '</div>';
        }
        ?>
        <div class="form-group row">
          <label for="name" class="col-sm-2 col-form-label">Name <span class="text-danger">*</span></label>
          <div class="col-sm-10">
            <input type="text" class="form-control" name="name" value="<?php echo set_value('name'); ?>" id="name" placeholder="Name" required>
            <?php echo form_error('name', '<p class="text-danger mb-0">', '</p>'); ?>
          </div>
        </div>
        <div class="form-group row">
          <label for="order" class="col-sm-2 col-form-label"> Order </label>
          <div class="col-sm-10">
            <input type="number" class="form-control" id="order" value="<?php echo set_value('order'); ?>" name="order" placeholder="Order" onkeypress="return isNumberKey(event)">
            <?php echo form_error('Order', '<p class="text-danger mb-0">', '</p>'); ?>
          </div>
        </div>
        <div class="form-group row">
          <label for="image" class="col-sm-2 col-form-label"> Image <span class="text-danger">*</span></label>
          <div class="col-sm-10 ">
            <input type="file" class="image form-control-file border rounded p-1" name="image" id="image" accept="image/*" required>
            <?php echo form_error('image', '<p class="text-danger mb-0">', '</p>'); ?>
          </div>
        </div>
        <div class="form-group row">
          <label for="status" class="col-sm-2 col-form-label">Status</label>
          <div class="col-sm-10">
            <div class="form-group">
              <select class="form-control" name="status" id="status">
                <option value="ACTIVE" <?= set_select('status', 'ACTIVE') ?>>ACTIVE</option>
                <option value="DEACTIVE" <?= set_select('status', 'DEACTIVE') ?>>DEACTIVE</option>
              </select>
            </div>
            <?php echo form_error('status', '<p class="text-danger mb-0">', '</p>'); ?>
          </div>
        </div>
        <div class="alert alert-danger w-50 mx-auto d-none text-center" role="alert" id="alertBox">
        </div>
        <!-- /.card-body -->
        <div class="card-footer text-center">
          <button type="submit" class="btn btn-success">Add + </button>
          <button type="reset" class="btn btn-warning ml-5">Reset</button>
        </div>
    </form>
  </div>
  <!-- /.card -->

</div>
<!-- /.content-wrapper -->

<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
  <!-- Control sidebar content goes here -->
</aside>
<!-- /.control-sidebar -->


<?php
$this->load->view('includes/admin-footer.php');
?>