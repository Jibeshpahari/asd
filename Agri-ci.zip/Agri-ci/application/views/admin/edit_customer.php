<?php

    $u_id = $_GET['id'];

    $page = "customer"; // Set active page to category.

    include '../includes/admin-header.php';
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper p-2">
    <div class="pl-3">
        <p class="h3 font-weight-bold text-info"><u>Edit Order</u></p>
    </div>
    <div class="card card-outline card-info">
        <form method="POST" action="action/edit_customer_act.php" >
            <div class="row px-3 mt-4 mb-2">
                <div class="col-12">
                    <h3>Product Details</h3>
                    <hr>
                </div>
            <?php 
                $query = getUserDetailsById($u_id);
                while($row = mysqli_fetch_assoc($query)){
            ?>
                <input type="hidden" name="uid" value="<?php echo $u_id; ?>">
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="username">First Name</label>
                        <input type="text" value="<?php echo $row['fname']; ?>" name="fname" class="form-control" >
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="password">Last Name</label>
                        <input type="text" value="<?php echo $row['lname']; ?>" name="lname" class="form-control" >
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="username">Email</label>
                        <input type="text" value="<?php echo $row['email']; ?>" name="email" class="form-control" >
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="password">Telephone</label>
                        <input type="text" value="<?php echo $row['phone']; ?>" name="telephone" class="form-control" >
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="username">Fax</label>
                        <input type="text" value="<?php echo $row['fax']; ?>" name="fax" class="form-control" >
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="password">Status</label>
                        <select class="form-control" name="status" id="" required>
                            <option value="DEACTIVE" <?php echo $row['status']=='DEACTIVE'? 'selected' : ''; ?>>DEACTIVE</option>
                            <option value="ACTIVE"   <?php echo $row['status']=='ACTIVE'? 'selected' : ''; ?>>ACTIVE</option>
                        </select>
                    </div>
                </div>
            <?php
                }
                $query = getAddressByUserId($u_id);
                $i = 1;
                while($row = mysqli_fetch_assoc($query)){
            ?>

                <div class="col-12 mt-4">
                    <h3>Address <?php echo $i; ?></h3>
                    <hr>
                </div>
                <input type="hidden" name="ads_id<?php echo $i; ?>" value="<?php echo $row['id']; ?>" >
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="password">Company</label>
                        <input type="text" value="<?php echo $row['company']; ?>" name="company<?php echo $i; ?>" class="form-control" >
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="password">Address Line 1</label>
                        <input type="text" value="<?php echo $row['address1']; ?>" name="firstlocation<?php echo $i; ?>" class="form-control" >
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="password">Address Line 1</label>
                        <input type="text" value="<?php echo $row['address2']; ?>" name="secondlocation<?php echo $i; ?>" class="form-control" >
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="password">City</label>
                        <input type="text" value="<?php echo $row['city']; ?>" name="city<?php echo $i; ?>" class="form-control" >
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="password">Postcode</label>
                        <input type="text" value="<?php echo $row['postcode']; ?>" name="postcode<?php echo $i; ?>" class="form-control" >
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="password">Country</label>
                        <input type="text" value="<?php echo $row['country']; ?>" name="country<?php echo $i; ?>" class="form-control" >
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="password">Region</label>
                        <input type="text" value="<?php echo $row['region']; ?>" name="region<?php echo $i; ?>" class="form-control" >
                    </div>
                </div>
            <?php
                    $i++;
                }
            ?>
            </div> 

            <div class="text-center mb-4">
                <button class="btn btn-success" type="submit"> Save </button>
                <button class="btn btn-warning ml-4" type="reset"> Reset </button>
            </div>
        </form>
    </div>
    <div class="alert w-50 mx-auto text-center d-none py-2 px-4 mt-2" role="alert" id="alertBox">
    </div>
    

<?php
  include '../includes/admin-footer.php';
?>