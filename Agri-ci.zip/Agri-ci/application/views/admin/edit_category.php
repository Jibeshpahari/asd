<?php
$title['page'] = 'category';
$this->load->view('includes/admin-header.php', $title);
$row = $category;
?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <!-- Horizontal Form -->
  <div class="card card-outline card-info">
    <div class="card-header">
      <h3 class="card-title text-capitalize text-indigo text-lg text-bold">Edit Category</h3>
    </div>
    <!-- /.card-header -->
    <!-- form start -->
    <form class="form-horizontal" method="POST" action="<?= base_url('admin/category/edit/action') ?>" enctype="multipart/form-data" onsubmit="">
      <!-- <input type="hidden" value="" name="page"> -->
      <input type="hidden" value="<?php echo $row['id']; ?>" name="id">
      <div class="card-body">
        <div class="form-group row">
          <label for="name" class="col-sm-2 col-form-label">Name <span class="text-danger">*</span></label>
          <div class="col-sm-10">
            <input type="text" class="form-control" name="name" value="<?= set_value('name', $row['name']); ?>" id="name" placeholder="Name">
            <?php echo form_error('name', '<p class="text-danger mb-0">', '</p>'); ?>
          </div>
        </div>
        <div class="form-group row">
          <label for="order" class="col-sm-2 col-form-label"> Order </label>
          <div class="col-sm-10">
            <input type="number" class="form-control" id="order" value="<?= set_value('order', $row['ranking']); ?>" name="order" placeholder="Order" onkeypress="return isNumberKey(event)">
            <?php echo form_error('order', '<p class="text-danger mb-0">', '</p>'); ?>
          </div>
        </div>
        <div class="form-group row">
          <label for="image" class="col-sm-2 col-form-label"> Image <span class="text-danger">*</span></label>
          <div class="col-sm-10 ">
            <div class="preview">
              <img src="<?php echo base_url('/uploads/category/') . $row['image']; ?>" alt="" class="img-fluid" width="70px" height="70px">
            </div>
            <input type="file" class="image form-control-file" name="image" id="image">
            <?php echo form_error('image', '<p class="text-danger mb-0">', '</p>'); ?>
          </div>
        </div>
        <div class="form-group row">
          <label for="status" class="col-sm-2 col-form-label">Status</label>
          <div class="col-sm-10">
            <div class="form-group">
              <select class="form-control" name="status" id="status">
                <option value="ACTIVE" <?= set_select('status', 'ACTIVE', $row['status'] == 'ACTIVE'); ?>>ACTIVE</option>
                <option value="DEACTIVE" <?= set_select('status', 'DEACTIVE', $row['status'] == 'DEACTIVE'); ?>>DEACTIVE</option>
              </select>
            </div>
            <?php echo form_error('status', '<p class="text-danger mb-0">', '</p>'); ?>
          </div>
        </div>
        <div class="alert alert-danger w-50 mx-auto d-none text-center" role="alert" id="alertBox">
        </div>
        <!-- /.card-body -->
        <div class="card-footer text-center">
          <button type="submit" class="btn btn-success">Update</button>
          <button type="reset" class="btn btn-warning ml-5">Reset</button>
        </div>
    </form>
  </div>
  <!-- /.card -->

</div>
<!-- /.content-wrapper -->

<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
  <!-- Control sidebar content goes here -->
</aside>
<!-- /.control-sidebar -->


<?php
$this->load->view('includes/admin-footer.php');
?>