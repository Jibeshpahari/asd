<?php
    $page = "category";
    include '../includes/admin-header.php';
    $query = getCategoryById($_GET['id']);
    $row = mysqli_fetch_assoc($query);
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <!-- Horizontal Form -->
            <div class="card card-outline card-info">
              <div class="card-header">
                <h3 class="card-title text-capitalize text-indigo text-lg text-bold" >Edit Category</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form class="form-horizontal" method="POST" action="action/editCategory_Act.php" enctype="multipart/form-data" onsubmit="">
                <!-- <input type="hidden" value="" name="page"> -->
                 <input type="hidden" value="<?php echo $row['id']; ?>" name="id">
                 <input type="hidden" value="<?php echo $row['image']; ?>" name="old_image">
                <div class="card-body">
                  <div class="form-group row">
                    <label for="inputEmail3" class="col-sm-2 col-form-label">Name <span class="text-danger">*</span></label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" name="name" value="<?php echo $row['name']; ?>" id="" placeholder="Name" required>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label"> Order </label>
                    <div class="col-sm-10">
                      <input type="number" class="form-control" id="order" value="<?php echo $row['ranking']; ?>" name="order" placeholder="Order" onkeypress="return isNumberKey(event)">
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label"> Image <span class="text-danger">*</span></label>
                    <div class="col-sm-10 ">
                      <div class="preview">
                        <img src="../uploads/category/<?php echo $row['image']; ?>" alt="" class="img-fluid" width="70px" height="70px">
                      </div>
                      <input type="file" class="image form-control-file" name="image">
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label">Status</label>
                    <div class="col-sm-10">
                      <div class="form-group">
                        <select class="form-control" name="status" id="" required>
                          <option value="ACTIVE" <?php if($row['status']=='ACTIVE'){echo 'selected';} ?> >ACTIVE</option>
                          <option value="DEACTIVE" <?php if($row['status']=='DEACTIVE'){echo 'selected';} ?> >DEACTIVE</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  <div class="alert alert-danger w-50 mx-auto d-none text-center" role="alert" id="alertBox">
                  </div>
                <!-- /.card-body -->
                <div class="card-footer text-center">
                  <button type="submit" class="btn btn-success">Update</button>
                  <button type="reset" class="btn btn-warning ml-5">Reset</button>
                </div>
              </form>
            </div>
            <!-- /.card -->
             
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->


<?php
  include '../includes/admin-footer.php';
?>