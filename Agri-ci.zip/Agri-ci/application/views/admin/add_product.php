<?php
$title['page'] = 'products';
$this->load->view('includes/admin-header.php', $title);
?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <!-- Horizontal Form -->
  <div class="card card-outline card-info">
    <div class="card-header">
      <h3 class="card-title text-capitalize text-indigo text-lg text-bold">Add New Products</h3>
    </div>
    <!-- /.card-header -->
    <!-- form start -->
    <form class="form-horizontal" method="POST" action="<?= base_url('admin/product/add/action') ?>" enctype="multipart/form-data">
      <!-- <input type="hidden" value="" name="page"> -->
      <div class="card-body">
        <?php
        if (isset($error)) {
          echo '<div class="alert alert-danger">' . $error . '</div>';
        }
        ?>
        <div class="form-group row">
          <label for="inputPassword3" class="col-sm-2 col-form-label">Category <span class="text-danger">*</span> </label>
          <div class="col-sm-10">
            <select class="form-control" name="category" id="category">
              <option value=""> -- Choose Category -- </option>
              <?php
              foreach ($categories as $category) {
                $row = $this->AdminModel->getCategoryById($category['id']);
              ?>
                <option value="<?php echo $row['id']; ?>" <?= set_select('category', $row['id']) ?>><?php echo $row['name']; ?></option>
              <?php
              }
              ?>
            </select>
            <small class="text-danger"><?= form_error('category'); ?></small>
          </div>
        </div>
        <div class="form-group row">
          <label for="sub_category" class="col-sm-2 col-form-label">Sub Category <span class="text-danger">*</span> </label>
          <div class="col-sm-10">
            <select class="form-control" name="sub_category" id="sub_category">
              <option value=""> -- Choose Sub Category -- </option>
            </select>
            <small class="text-danger"><?= form_error('sub_category'); ?></small>
          </div>
        </div>
        <div class="form-group row">
          <label for="name" class="col-sm-2 col-form-label"> Name <span class="text-danger">*</span> </label>
          <div class="col-sm-10">
            <input type="text" class="form-control" id="name" value="<?= set_value('name'); ?>" name="name" placeholder="Name">
            <small class="text-danger"><?= form_error('name'); ?></small>
          </div>
        </div>
        <div class="form-group row">
          <label for="description" class="col-sm-2 col-form-label"> Description </label>
          <div class="col-sm-10">
            <textarea class="form-control" rows="4" name="description" placeholder="Description"><?= set_value('description'); ?></textarea>
            <small class="text-danger"><?= form_error('description'); ?></small>
          </div>
        </div>
        <div class="form-group row">
          <label for="inputPassword3" class="col-sm-2 col-form-label"> Price <span class="text-danger">*</span></label>
          <div class="col-sm-10">
            <input type="number" class="form-control" id="price" value="<?= set_value('price'); ?>" name="price" step="0.01" placeholder="Price" onkeypress="return isNumberKey(event)">
            <small class="text-danger"><?= form_error('price'); ?></small>
          </div>
        </div>
        <div class="form-group row">
          <label for="image" class="col-sm-2 col-form-label">Featured Image <span class="text-danger">*</span></label>
          <div class="col-sm-10 ">
            <input type="file" class="form-control-file" name="image" id="image" accept="image/*">
            <small class="text-danger"><?= form_error('image'); ?></small>
            <p class="text-capitalize text-sm text-info my-1">( Image should be > 10MB and Minimum 1000x1000 pixels square width )</p>
          </div>
        </div>
        <div class="form-group row">
          <label for="inputPassword3" class="col-sm-2 col-form-label"> Availability </label>
          <div class="col-sm-10">
            <select class="form-control" name="availability" id="">
              <option value="In Stock" <?= set_select('availability', 'In Stock') ?>> In Stock </option>
              <option value="Out Of Stock" <?= set_select('availability', 'Out Of Stock') ?>> Out Of Stock </option>
            </select>
            <small class="text-danger"><?= form_error('availability'); ?></small>
          </div>
        </div>
        <div class="form-group row">
          <label for="gallery" class="col-sm-2 col-form-label">Gallery Image </label>
          <div class="col-sm-10 ">
            <input type="file" class="form-control-file" name="gallery[]" id="gallery" multiple>
            <small class="text-danger"><?= form_error('gallery[]'); ?></small>
            <p class="text-capitalize text-sm text-info my-1">***You can select multiple images from here for product gallery***</p>
          </div>
        </div>
        <div class="form-group row">
          <label for="inputPassword3" class="col-sm-2 col-form-label"></label>
          <div class="col-sm-10 ">
            <div class="row">
              <div class="col-sm-4">
                <div class="form-group">
                  <div class="custom-control custom-checkbox">
                    <input class="custom-control-input" type="checkbox" id="spacial" value="special" name="special" <?= set_checkbox('special', 'special'); ?>>
                    <label for="spacial" class="custom-control-label font-weight-normal">Add To Special Product</label>
                  </div>
                  <small class="text-danger"><?= form_error('special'); ?></small>
                </div>
              </div>
              <div class="col-sm-8">
                <div class="form-group">
                  <div class="custom-control custom-checkbox">
                    <input class="custom-control-input" type="checkbox" id="featured" value="featured" name="featured" <?= set_checkbox('featured', 'featured'); ?>>
                    <label for="featured" class="custom-control-label font-weight-normal">Add To Featured Product</label>
                  </div>
                  <small class="text-danger"><?= form_error('featured'); ?></small>
                </div>
              </div>
            </div>
          </div>
        </div>
        <?php
        if (isset($msg)) {
          unset($_SESSION['product']);
        }
        ?>
        <div class="alert alert-danger w-50 mx-auto d-none text-center" role="alert" id="alertBox">
        </div>
        <!-- /.card-body -->
        <div class="card-footer text-center">
          <button type="submit" class="btn btn-success">Add + </button>
          <button type="reset" class="btn btn-warning ml-5">Reset</button>
        </div>
      </div>
    </form>
  </div>
  <!-- /.card -->

</div>
<!-- /.content-wrapper -->

<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
  <!-- Control sidebar content goes here -->
</aside>
<!-- /.control-sidebar -->


<?php
$this->load->view('includes/admin-footer.php');
?>