<?php

    $page = "customer"; 

    $lk = "";
    if(isset($_GET['l'])){
      $lk = $_GET['l'];
    }

    include '../includes/admin-header.php';
    $query = getUserDetails($lk);   
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper p-2">
    <div class="pl-3">
        <p class="h4 font-weight-bold text-info"><u>Customer</u></p>
    </div>
    <div class="card card-outline card-info">
        <div class="d-flex justify-content-center g-5 p-2">
          <a href="customer.php"><button class="btn btn-success py-0 px-2 mr-1">ALL</button></a>
          <a href="customer.php?l=A"><button class="btn btn-success py-0 px-2 mr-1">A</button></a>
          <a href="customer.php?l=B"><button class="btn btn-success py-0 px-2 mr-1">B</button></a>
          <a href="customer.php?l=C"><button class="btn btn-success py-0 px-2 mr-1">C</button></a>
          <a href="customer.php?l=D"><button class="btn btn-success py-0 px-2 mr-1">D</button></a>
          <a href="customer.php?l=E"><button class="btn btn-success py-0 px-2 mr-1">E</button></a>
          <a href="customer.php?l=F"><button class="btn btn-success py-0 px-2 mr-1">F</button></a>
          <a href="customer.php?l=G"><button class="btn btn-success py-0 px-2 mr-1">G</button></a>
          <a href="customer.php?l=H"><button class="btn btn-success py-0 px-2 mr-1">H</button></a>
          <a href="customer.php?l=I"><button class="btn btn-success py-0 px-2 mr-1">I</button></a>
          <a href="customer.php?l=J"><button class="btn btn-success py-0 px-2 mr-1">J</button></a>
          <a href="customer.php?l=K"><button class="btn btn-success py-0 px-2 mr-1">K</button></a>
          <a href="customer.php?l=L"><button class="btn btn-success py-0 px-2 mr-1">L</button></a>
          <a href="customer.php?l=M"><button class="btn btn-success py-0 px-2 mr-1">M</button></a>
          <a href="customer.php?l=N"><button class="btn btn-success py-0 px-2 mr-1">N</button></a>
          <a href="customer.php?l=O"><button class="btn btn-success py-0 px-2 mr-1">O</button></a>
          <a href="customer.php?l=P"><button class="btn btn-success py-0 px-2 mr-1">P</button></a>
          <a href="customer.php?l=Q"><button class="btn btn-success py-0 px-2 mr-1">Q</button></a>
          <a href="customer.php?l=R"><button class="btn btn-success py-0 px-2 mr-1">R</button></a>
          <a href="customer.php?l=S"><button class="btn btn-success py-0 px-2 mr-1">S</button></a>
          <a href="customer.php?l=T"><button class="btn btn-success py-0 px-2 mr-1">T</button></a>
          <a href="customer.php?l=U"><button class="btn btn-success py-0 px-2 mr-1">U</button></a>
          <a href="customer.php?l=V"><button class="btn btn-success py-0 px-2 mr-1">V</button></a>
          <a href="customer.php?l=W"><button class="btn btn-success py-0 px-2 mr-1">W</button></a>
          <a href="customer.php?l=X"><button class="btn btn-success py-0 px-2 mr-1">X</button></a>
          <a href="customer.php?l=Y"><button class="btn btn-success py-0 px-2 mr-1">Y</button></a>
          <a href="customer.php?l=Z"><button class="btn btn-success py-0 px-2 mr-1">Z</button></a>
        </div>
        <hr>
    <div class="card card-outline card-info px-5 py-3">
        <form method="GET" action="customer.php">
            <div class="form-group px-5 d-flex">
              <input type="search" class="form-control" name="l" id=""  placeholder="Search...">
              <button type="submit" class="btn btn-success ml-3">Submit</button>
            </div>
        </form>
    </div>
    <div class="alert alert-primary w-50 mx-auto text-center d-none py-2 px-4 " role="alert" id="alertBox">
    </div>
    
    <!-- Content Header (Page header) -->
    <div class="card-body p-0">
                <table class="table table-striped">
                  <thead>
                    <tr>
                      <th class="text-center">Name</th>
                      <th class="text-center">Mail</th>
                      <th class="text-center">Telephone</th>
                      <th class="text-center">Status</th>
                      <th class="text-center">No. of order</th>
                      <th class="text-center">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                      while($row=mysqli_fetch_assoc($query)){
                        $id =  $row['id'];
                        $sql2 = "SELECT * FROM `orderlist` WHERE `user_id`='$id' ";
                        $query2 = mysqli_query($conn, $sql2);
                        $count = mysqli_num_rows($query2);
                    ?>
                    <tr>
                        <td class="text-center"><?php echo $row['fname'].' '.$row['lname']; ?></td>
                      <td class="text-center"><?php echo $row['email']; ?></td>
                      <td class="text-center"><?php echo $row['phone']; ?></td>
                      <td class="text-center"><?php echo $row['status']; ?></td>
                      <td class="text-center"><?php echo $count; ?></td>
                      <td class="text-center">
                        <a href="edit_customer.php?id=<?php echo $row['id']; ?> "><button class="btn btn-info py-1">EDIT</button></a> 
                        <a href="customer_order.php?id=<?php echo $row['id']; ?>"><button class="btn btn-primary py-1">Order</button></a>
                        <a href="action/delete_customer_act.php?id=<?php echo $row['id']; ?> "><button class="btn btn-danger py-1">DELETE</button></a>
                      </td>
                    </tr>
                    <?php
                      }
                    ?>
                  </tbody>
                </table>
              </div>
             
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->


<?php
  include '../includes/admin-footer.php';
?>