<?php
$title['page'] = 'discount';
$this->load->view('includes/admin-header.php', $title);
?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <!-- Horizontal Form -->
  <div class="card card-outline card-info">
    <div class="card-header">
      <h3 class="card-title text-capitalize text-indigo text-lg text-bold">Add New Discount</h3>
    </div>
    <!-- /.card-header -->
    <!-- form start -->
    <form class="form-horizontal" method="POST" action="<?= base_url('admin/discount/add/action') ?>" enctype="multipart/form-data" onsubmit="">
      <?php
        if (isset($error)) {
          echo '<div class="alert alert-danger">' . $error . '</div>';
        }
      ?>
      <div class="card-body">
        <div class="form-group row">
          <label for="name" class="col-sm-2 col-form-label"> Name <span class="text-danger">*</span> </label>
          <div class="col-sm-10">
            <input type="text" class="form-control" id="name" value="<?= set_value('name') ?>" name="name" placeholder="Name" >
            <?= form_error('name', '<p class="text-danger mb-0">', '</p>'); ?>
          </div>
        </div>
        <div class="form-group row">
          <label for="validForm" class="col-sm-2 col-form-label"> Valid From </label>
          <div class="col-sm-10">
            <input type="date" class="form-control" id="validFrom" value="<?= set_value('validFrom') ?>" name="validFrom">
            <?php echo form_error('validFrom', '<p class="text-danger mb-0">', '</p>'); ?>
          </div>
        </div>
        <div class="form-group row">
          <label for="validTill" class="col-sm-2 col-form-label"> Valid Till </label>
          <div class="col-sm-10">
            <input type="date" class="form-control" id="validTill" value="<?= set_value('validTill') ?>" name="validTill" placeholder>
            <?php echo form_error('validTill', '<p class="text-danger mb-0">', '</p>'); ?>
          </div>
        </div>
        <div class="form-group row">
          <label for="type" class="col-sm-2 col-form-label">Type <span class="text-danger">*</span> </label>
          <div class="col-sm-10">
            <div class="form-group mb-0">
              <select class="form-control" name="type" id="type" >
                <option value="PERCENTAGE" <?= set_select('type', 'PERCENTAGE')?>>PERCENTAGE</option>
                <option value="FLAT" <?= set_select('type', 'FLAT')?>>FLAT</option>
              </select>
            </div>
            <?php echo form_error('type', '<p class="text-danger mb-0">', '</p>'); ?>
          </div>
        </div>
        <div class="form-group row">
          <label for="amount" class="col-sm-2 col-form-label"> Amount <span class="text-danger">*</span> </label>
          <div class="col-sm-10">
            <input type="number" class="form-control" id="amount" name="amount" value="<?= set_value('amount') ?>" placeholder="Amount" onkeypress="return isNumberKey(event)" >
            <?php echo form_error('amount', '<p class="text-danger mb-0">', '</p>'); ?>
          </div>
        </div>
        <div class="form-group row">
          <label for="status" class="col-sm-2 col-form-label">Status</label>
          <div class="col-sm-10">
            <div class="form-group">
              <select class="form-control" name="status" id="status">
                <option value="ACTIVE" <?= set_select('status', 'ACTIVE')?> >ACTIVE</option>
                <option value="DEACTIVE" <?= set_select('status', 'DEACTIVE')?> >DEACTIVE</option>
              </select>
            </div>
            <?php echo form_error('status', '<p class="text-danger mb-0">', '</p>'); ?>
          </div>
        </div>
        <div class="alert alert-danger w-50 mx-auto d-none text-center" role="alert" id="alertBox">
        </div>
        <!-- /.card-body -->
        <div class="card-footer text-center">
          <button type="submit" class="btn btn-success">Add + </button>
          <button type="reset" class="btn btn-warning ml-5">Reset</button>
        </div>
    </form>
  </div>
  <!-- /.card -->

</div>
<!-- /.content-wrapper -->

<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
  <!-- Control sidebar content goes here -->
</aside>
<!-- /.control-sidebar -->


<?php
$this->load->view('includes/admin-footer.php');
?>