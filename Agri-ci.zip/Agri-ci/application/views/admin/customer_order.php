<?php
  $title['page'] = 'customer';
  $this->load->view('includes/admin-header.php', $title);
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper p-2">
    <div class="pl-3">
        <p class="h3 font-weight-bold text-info"><u>Customer Order</u></p>
    </div>
    <div class="card card-outline card-info p-4">
        <form method="POST" action="" >
            <div id="accordion">
                <?php
                if(!empty($orders)){
                    $i = 0;
                    foreach($orders as $order){
                        $i++;
                        $items = $this->AdminModel->getItemsByOrderId($order['id']);
                        $shipping = $this->AdminModel->getAddressById($order['shpg_address']);
                        $billing = $this->AdminModel->getAddressById($order['bill_address']);
                        $date = date('d M Y', strtotime($order['ord_date']));
                        $ord_id = $order['id'];
                ?>
                <div class="card card-olive">
                    <div class="card-header">
                        <h4 class="card-title w-100">
                            <a class="d-block w-100" data-toggle="collapse" href="#collapse<?php echo $i;?>">
                              Order #<?php echo $i;?>
                            </a>
                        </h4>
                    </div>
                    <div id="collapse<?php echo $i;?>" class="collapse <?php echo $i==1? 'show':''; ?>" data-parent="#accordion">
                        <div class="card-body">
                            <div class="row">
                                <?php
                                    $j = 0;
                                    foreach($items as $item){
                                        $j++;
                                        $product = $this->AdminModel->getProductById($item['pro_id']);
                                ?>
                                <div class="col-sm-6">
                                <div class="form-group">
                                    <label for="password">Product <?php echo $j; ?> </label>
                                    <input type="text" value="<?php echo $product['name']; ?>" class="form-control" disabled>
                                </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="password">Quantity</label>
                                        <input type="text" value="<?php echo $item['qty']; ?>" class="form-control" disabled>
                                    </div>
                                </div>
                                <?php
                                    }
                                ?>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="password">Delivery Address</label>
                                        <input type="text" value="<?php echo $shipping['address1']; ?>" class="form-control" disabled>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="password">Billing Address</label>
                                        <input type="text" value="<?php echo $billing['address1']; ?>" class="form-control" disabled>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="username">SubTotal</label>
                                        <input type="text" value="<?php echo $order['sub_total']; ?>" class="form-control" disabled>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="password">Eco Tax(-2.00)</label>
                                        <input type="text" value="<?php echo $order['tax']; ?>" class="form-control" disabled>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="password">VAT(20%)</label>
                                        <input type="text" value="<?php echo $order['vat']; ?>" class="form-control" disabled>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="password">Discount</label>
                                        <input type="text" value="<?php echo $order['discount']; ?>" class="form-control" disabled>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="password">Total</label>
                                        <input type="text" value="<?php echo $order['total_price']; ?>" class="form-control" disabled>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="username">Payment Mode</label>
                                        <input type="text" value="<?php echo $order['pay_method']; ?>" class="form-control" disabled>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="password">Order Date</label>
                                        <input type="text" value="<?php echo $date; ?>" class="form-control" disabled>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="password">Payment Status</label>
                                        <select class="form-control" name="pay_status" id="" required disabled>
                                            <option value="SUCCESSFULL"   <?php echo $order['pay_status']=='SUCCESSFULL'? 'selected' : ''; ?>>SUCCESSFULL</option>
                                            <option value="UNSUCCESSFULL" <?php echo $order['pay_status']=='UNSUCCESSFULL'? 'selected' : ''; ?>>UNSUCCESSFULL</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="password">Transanction Id</label>
                                        <input type="text" value="" class="form-control" disabled>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="password">Order Status</label>
                                        <select class="form-control" name="ord_status" id="" required disabled >
                                        <option value="PROCESSING" <?php echo $order['ord_status']=='PROCESSING'? 'selected' : ''; ?>>PROCESSING</option>
                                        <option value="SHIPPTED" <?php echo $order['ord_status']=='SHIPPTED'? 'selected' : ''; ?>>SHIPPTED</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-12 text-right mb-4">
                                    <a href="<?= base_url('admin/orders/edit/'.$ord_id) ?>"> <button class="btn btn-info" type="button">Edit</button> </a>
                                    <a href=""> <button class="btn btn-warning ml-2" type="button">Cancel</button> </a>
                                    <a href=""> <button class="btn btn-danger ml-2" type="button">Delete</button> </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                    }
                } else {
                    echo '<div class="col-sm-12"><div class="alert alert-info text-center" role="alert">No orders found.</div></div>';
                }
                ?>
                
            </div> 
            
        </form>
    </div>
    

<?php
  $this->load->view('includes/admin-footer.php');
?>