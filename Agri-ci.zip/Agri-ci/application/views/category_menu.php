<aside class="col-sm-3 hidden-xs" id="column-left">
    <h4 class="widget-title">CATEGORIES</h4>
    <ul class="category-list">
        <?php
            $categories = $this->UserModel->getCategory();
            foreach($categories as $category) {
        ?>              
        <li>
            <a id=" " data-id="<?php echo $category['id']; ?>" class="category"><?php echo $category['name'];?></a>
            <ul class="sub-category-list d-none">
            <?php
                $sub_categories = $this->UserModel->getSubCategory($category['id']);
                foreach ($sub_categories as $sub_category) {
            ?> 
            <li>
                <a href="<?= base_url('category/sub_category/' . $sub_category['id']); ?>" id="" data-id="<?php echo $sub_category['id']; ?>" class="sub-category">
                    <?php echo $sub_category['name']; ?>
                </a>
            </li>
            <?php
              }
            ?>
            </ul>
        </li>
        <?php
            }
        ?>
    </ul>    
</aside>          