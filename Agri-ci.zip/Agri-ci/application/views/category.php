<?php
    $this->load->view('includes/header');
?>

<div class="banner-in">
    <div class="container">
        <h1>CATEGORIES</h1>
        <ul class="newbreadcrumb">
            <li><a href="<?= base_url() ?>">Home</a></li>
            <li>Categories</li>
        </ul>
    </div>
</div>
<div id="main-container">
    <div class="container">
        <div class="row">
        <?php $this->load->view('category_menu') ?>
            <div class="col-sm-9" id="content">
                <div class="search-bar">
                    <div class="row">
                        <div class="col-md-4 col-sm-12"><a id="compare-total" href="#">Product Compare (0)</a></div>
                        <div class="col-md-2 col-sm-2 text-right">
                            <label for="input-sort" class="control-label">Sort By:</label>
                        </div>
                        <div class="col-md-3  col-sm-5 text-right">
                            <select class="form-control" id="input-sort">
                                <option value="0" selected="selected">Default</option>
                                <option value="1">Name (A - Z)</option>
                                <option value="2">Name (Z - A)</option>
                                <option value="3">Price (Low &gt; High)</option>
                                <option value="4">Price (High &gt; Low)</option>
                            </select>
                        </div>
                        <div class="col-md-1 col-sm-3 text-right">
                            <label for="input-limit" class="control-label">Show:</label>
                        </div>
                        <div class="col-md-2 col-sm-2 text-right">
                            <select class="form-control" id="input-limit">
                                <option value="0" selected="selected">All</option>
                                <option value="2">2</option>
                                <option value="4">4</option>
                                <option value="8">8</option>
                                <option value="16">16</option>
                                <option value="32">32</option>
                            </select>
                        </div>
                    </div>
                </div>
                <br>
                <div id="product-list">
                    <div class="row">
                        <?php
                            foreach ($products as $product) {
                          ?>
                        <div class="product-layout product-grid col-lg-4 col-md-4 col-sm-6 col-xs-12">
                            <div class="product-thumb transition">
                                <div class="image">
                                    <a href="<?= base_url('product/' . $product['id']); ?>">
                                        <img src="<?= base_url('uploads/md/'.$product['featured_img']); ?>" alt="" title=""
                                            class="img-responsive" />
                                    </a>
                                </div>
                                <div class="caption">
                                    <h4><a
                                            href="<?= base_url('product/' . $product['id']); ?>"><?php echo $product['name']; ?></a>
                                    </h4>
                                    <div class="rating">
                                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i
                                                class="fa fa-star-o fa-stack-2x"></i></span>
                                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i
                                                class="fa fa-star-o fa-stack-2x"></i></span>
                                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i
                                                class="fa fa-star-o fa-stack-2x"></i></span>
                                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i
                                                class="fa fa-star-o fa-stack-2x"></i></span>
                                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i
                                                class="fa fa-star-o fa-stack-2x"></i></span>
                                    </div>
                                    <p class="price">&#8364; <?php echo $product['price']; ?></p>
                                </div>
                            </div>
                        </div>

                        <?php
                            }
                            if(empty($products)) {
                                echo '<div class="col-sm-12 text-center"><h3>No Products Found</h3></div>';
                            }
                          ?>

                    </div>

                    <div class="row">
                        <div class="col-sm-6 text-left"></div>
                        <div class="col-sm-6 text-right">Showing <?= isset($product) ? 1 : 0 ?> to <?= isset($showing)? $showing : count($products) ?> of <?= count($products) ?> (1 Pages)</div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<?php
  $this->load->view('includes/footer');
?>