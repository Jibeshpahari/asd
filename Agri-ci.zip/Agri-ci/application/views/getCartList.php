<?php
if (!empty($items)) {
  foreach ($items as $item) {
?>
    <tr>
      <td class="text-center">
        <a href="#"><img class="img-thumbnail" src="./uploads/md/<?php echo $item['image']; ?>" alt="" width="65px" height="65px"></a>
      </td>
      <td class="text-left">
        <a href="product.php?id=<?php echo $item['id']; ?>"><?php echo $item['name']; ?></a>
      </td>
      <td class="text-left">€<?php echo $item['price']; ?></td>
      <td class="text-left">
        <div style="max-width: 200px;" class="input-group btn-block">
          <input type="number" class="form-control" value="<?php echo $item['qty']; ?>" min="1" name="quantity" vk_14527="subscribed">
          <span class="input-group-btn">
            <button class="btn btn-primary cart-update" title="Update" data-cart-id="<?php echo $item['rowid']; ?>" data-original-title="Update">
              <i class="fa fa-refresh"></i>
            </button>
            <button class="btn btn-danger cart-remove" title="Remove" type="button" data-cart-id="<?php echo $item['rowid']; ?>" data-original-title="Remove">
              <i class="fa fa-times-circle"></i>
            </button></span>
        </div>
      </td>
      <td class="text-left">€<?= $item['price'] * $item['qty'] ?></td>
    </tr>
<?php
  }
} else {
  echo "<tr><td colspan='5x' class='text-center'>Missing Cart items?</td></tr>";
}
?>