<?php
$this->load->view('includes/header');
?>

<div class="banner-in">
    <div class="container">
        <h1>Payment</h1>
        <ul class="newbreadcrumb">
            <li><a href="<?= base_url() ?>"> Home </a></li>
        </ul>
    </div>
</div>
<div id="main-container">
    <div class="container">
        <form action="<?= base_url('UserController/addPayment'); ?>" method="post">
            <div class="form-group">
                <input type="radio" name="payment" id="cod" value="CASH ON DELIVERY" checked required>
                <label for="cod"> CASH ON DELIVERY </label>
                <br>
                <input type="radio" name="payment" id="cc" value="CREDIT CARD">
                <label for="cc"> CREDIT CARD </label>
            </div>
            <div class="pull-left">
                <button class="btn btn160 btn-lg btn-primary" type="submit" id="next">Next</button>
            </div>
        </form>
    </div>
</div>

<?php
$this->load->view('includes/footer');
?>