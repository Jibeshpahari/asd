<?php
    if(isset($discount) && !empty($discount) && $discount > 0){
        $vat = ($sub_total - $discount ) * 0.2 ;
        $total =  ($sub_total + $tax + $vat) - $discount;
    }
?>
    <tbody>
        <tr>
            <td class="text-right"><strong>Sub-Total:</strong></td>
            <td class="text-right">$<?= $sub_total; ?></td>
        </tr>
        <tr>
            <td class="text-right"><strong>Eco Tax (-2.00):</strong></td>
            <td class="text-right">$<?= $tax; ?></td>
        </tr>
        <?php
            if($discount > 0 ) {
        ?>
        <tr>
            <td class="text-right"><strong>Discount:</strong></td>
            <td class="text-right">($<?= $discount; ?>)</td>
        </tr>
        <?php
            }
        ?>
        <tr>
            <td class="text-right"><strong>VAT (20%):</strong></td>
            <td class="text-right">$<?= $vat ?></td>
        </tr>
        <tr>
            <td class="text-right"><strong>Total:</strong></td>
            <td class="text-right">$<?= $total; ?></td>
        </tr>
    </tbody>