<?php
    $this->load->view('includes/header');
?>
<div class="banner-in">
	<div class="container">
    	<h1>Search result</h1>
        <ul class="newbreadcrumb">
            <li><a href="<?= base_url() ?>">Home</a></li>
      </ul>
    </div>
</div>
<div id="main-container">
    <div class="container">
        <div id="product-list">
            <div class="row">
                <?php 
                    foreach ($products as $product){
                ?>
                <div class="product-layout product-grid col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="product-thumb transition">
                        <div class="image">
                            <a href="<?= base_url('product/' . $product['id']); ?>">
                                <img src="<?= base_url('uploads/md/' . $product['featured_img']); ?>" alt="" title="" class="img-responsive" />
                            </a>
                        </div>
                        <div class="caption">
                            <h4><a href="<?= base_url('product/' . $product['id']); ?>"><?= $product['name']; ?></a></h4>
                            <div class="rating">
                                <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                                <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                                <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                                <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                                <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                            </div>
                            <p class="price">&#8364; <?= $product['price']; ?></p>
                        </div>
                    </div>
                </div>
                <?php
                    }
                ?>
            </div>
        </div>
    </div>
</div>

<?php
  $this->load->view('includes/footer');
?>