<?php
$this->load->view('includes/header');
?>
<div class="banner-in">
    <div class="container">
        <h1>Billing Address</h1>
        <ul class="newbreadcrumb">
            <li><a href="index.php">Home</a></li>
        </ul>
    </div>
</div>
<div id="main-container">
    <div class="container">
        <form action="<?= base_url('UserController/addBillingAddress'); ?>" method="post">
            <div class="row">
                <?php
                foreach($location as $row){
                ?>
                    <div class=" col-lg-3">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="card-title"><?= $row['fname'] . ' ' . $row['lname']; ?></h5>
                            </div>
                            <div class="card-body">
                                <p class="card-text">
                                    <?php
                                    echo $row['address1'] . '<br>';
                                    echo $row['city'] . ' - ';
                                    echo $row['postcode'] . '<br>';
                                    echo $row['email'] . '<br>';
                                    echo $row['phone'] . '<br>';
                                    ?>
                                </p>
                            </div>
                        </div>
                        <div>
                            <div class="form-group">
                                <input type="radio" name="billingAddress" id="<?php echo $row['id']; ?>" value="<?php echo $row['id']; ?>" required>
                                <label for="<?php echo $row['id']; ?>">Select</label>
                            </div>
                        </div>

                    </div>
                <?php
                }
                ?>
                <div class="col-lg-3 btn-col " style="display: flex; justify-content: center; align-items: center;">
                    <a href="<?= base_url('add/address'); ?>"> <button class="btn btn160 btn-success" type="button" id="add_address">
                            ADD NEW <strong>+</strong>
                        </button></a>
                </div>

            </div>

            <div class="pull-right">
                <button class="btn btn160 btn-lg btn-primary" type="submit" id="">Next</button>
            </div>

        </form>


    </div>
</div>

<?php
$this->load->view('includes/footer');
?>