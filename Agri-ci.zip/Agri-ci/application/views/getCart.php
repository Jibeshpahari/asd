<button class="btn btn-viewcart dropdown-toggle" data-loading-text="Loading..." data-toggle="dropdown" type="button" aria-expanded="false">
    <span class="lg">My Cart</span>
    <span id="cart-total">
        <i class="fa fa-shopping-basket"></i> (<?= isset($count) ? $count : '0'; ?>) items
    </span>
</button>
<ul class="dropdown-menu pull-right">
    <li>
        <table class="table table-striped">
            <tbody>
                <?php
                if (empty($items) || !isset($items)) {
                    echo '<tr><td class="text-center">Your cart is empty!</td></tr>';
                } else {
                    foreach ($items as $item) {
                ?>
                        <tr>
                            <td class="text-center">
                                <a href="product.php?id=<?= $item['id']; ?>">
                                    <img class="img-thumbnail" title="<?php echo $item['name']; ?>" alt="<?php echo $item['name']; ?>" src="<?= base_url('uploads/sm/' . $item['image']); ?>">
                                </a>
                            </td>
                            <td class="text-left">
                                <a href="product.php?id=<?php echo $item['id']; ?>"><?php echo $item['name']; ?></a>
                            </td>
                            <td class="text-right">x<?php echo $item['qty']; ?></td>
                            <td class="text-right">$<?php echo $item['price']; ?></td>
                            <td class="text-center">
                                <button class="btn btn-danger btn-xs cart-remove" data-cart-id="<?= $item['rowid'] ?>" title="Remove Product" onclick="" type="button" style="padding: 4px 8px;font-size: 15px;">
                                    <i class="fa fa-times"></i>
                                </button>
                            </td>
                        </tr>
                <?php
                    }
                }
                ?>

            </tbody>
        </table>
    </li>
    <li>
        <div>
            <table class="table table-bordered">
                <tbody>
                    <tr>
                        <td class="text-right"><strong>Sub-Total</strong></td>
                        <td class="text-right">$<?= $sub_total; ?></td>
                    </tr>
                    <tr>
                        <td class="text-right"><strong>Eco Tax (-2.00)</strong></td>
                        <td class="text-right">$<?= $tax ?></td>
                    </tr>
                    <tr>
                        <td class="text-right"><strong>VAT (20%)</strong></td>
                        <td class="text-right">$<?= $vat; ?></td>
                    </tr>
                    <tr>
                        <td class="text-right"><strong>Total</strong></td>
                        <td class="text-right">$<?= $total ?></td>
                    </tr>
                </tbody>
            </table>
            <p class="text-right">
                <a href="<?= base_url('cart'); ?>">
                    <strong> <i class="fa fa-shopping-cart"></i> View Cart </strong>
                </a>
                &nbsp;&nbsp;&nbsp;
                <a href="<?= base_url('cart'); ?>">
                    <strong> <i class="fa fa-share"></i> Checkout </strong>
                </a>
            </p>
        </div>
    </li>
</ul>