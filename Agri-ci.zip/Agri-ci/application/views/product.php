<?php $this->load->view('includes/header'); ?>

<div class="banner-in">
	<div class="container">
    	<h1><?= $product['name']; ?></h1>
        <ul class="newbreadcrumb">
            <li><a href="index.php">Home</a></li>
            <li><a href="category.php?id=<?= $category['id'] ?>"><?= $category['name'] ?></a></li>
            <li><a href="category.php?sb_id=<?= $subCategory['id'] ?>"><?= $subCategory['name'] ?></a></li>
            <li><?= $product['name']; ?></li>
      </ul>
    </div>
</div>
<div id="main-container"> 
    <div class="container">
    	  
        <div class="row">               
        	<div class="col-sm-12" id="content">    
              
                <div class="row">
                    <div class="col-sm-1">
                        <ul class="img-box">
                          <li>
                            <div class="sub-img-box">
                                  <img src="<?=base_url('uploads/sm/'.$product['featured_img']); ?>" alt="<?= $product['featured_img']; ?>" >
                                </div>
                          </li>
                          <?php
                            foreach ($gallery as $image) {
                          ?>
                            <li>
                                <div class="sub-img-box">
                                  <img src="<?=base_url('uploads/sm/'.$image['img']); ?>" alt="<?= $image['img']; ?>" >
                                </div>
                            </li>
                          <?php
                            }
                          ?>
                        </ul>
                    </div>
                    <div class="col-sm-5">
                        <div class="pro-thumbnail">
                            <img src="<?=base_url('uploads/md/'.$product['featured_img']); ?>" alt="<?= $product['featured_img']; ?>" id="main-image" 
                            title="<?= $product['name']; ?>" class="img-responsive"  />
                            <div class="zoomer d-none">
                              <div class="dot">
                                
                              </div>
                            </div>
                            <div class="overlay"></div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                      <div class="lightbox d-none"> 
                        <div class="lightbox-image">
                          <img src="" alt="" id="projector"></i>
                        </div>
                      </div>
                        <div class="product-details">
                            <div class="product-header">
                            <h1><?php echo $product['name']; ?></h1>
                            
                            <h2>€ <?php echo $product['price']; ?></h2>
                            <button onclick="wishlist.add('40');" title="" class="btn btn-wishlist" data-toggle="tooltip" type="button" data-original-title="Add to Wish List"><i class="fa fa-heart"></i></button>
                        </div>
                        <hr>
                        <ul class="list-unstyled">
                        	<li>Availability: <?php echo $product['stock']; ?></li>
                        </ul>
                        <hr>
                        <h4>Description</h4>
                        <p><?php echo $product['description']; ?></p>
                        <br>
                        <div id="product">
                            <div class="form-group clearfix">
                                <label for="input-quantity" class="control-label">Qty</label>
                                <input type="number" class="form-control" id="input-quantity" size="2" min="1" value="1" name="quantity" vk_106cf="subscribed">
                                <input type="hidden" value="<?= $product['id']; ?>" name="product_id" id="product_id" >
                                <button class="btn btn-default btn-lg <?= $product['stock'] == 'Out Of Stock'? 'disabled ':''; ?>" data-loading-text="Loading..." id="button-cart" type="button" <?= $product['stock'] == 'Out Of Stock'? 'disabled ':''; ?>>Add to Cart</button>
                            </div>
                        </div>
                        <hr>
                        <div class="rating">
                            <div class="row">
                                <div class="col-lg-6">
                                <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i></span>
                                            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i></span>
                                            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i></span>
                                            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i></span>
                                            <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i></span>
                                <a onclick="$('a[href=\'#tab-review\']').trigger('click'); return false;" href="">0 reviews</a> / <a onclick="$('a[href=\'#tab-review\']').trigger('click'); return false;" href="">Write a review</a>
                                </div>
                                <div class="col-lg-6">
                                    <div class="pull-right">
                                        <img src="<?= base_url('assets/images/addthis.jpg'); ?>" alt="">
                                    </div>
                                </div>
                            </div>
                        	<hr>
                        </div>
                        </div>
                    </div>
                </div>
          
          		<br>
      
                <ul class="nav nav-tabs">
                  <li class="active"><a data-toggle="tab" href="#tab-description">Description</a></li>
                  <li><a data-toggle="tab" href="#tab-review">Reviews (0)</a></li>
                </ul>

                <div class="tab-content">
                <div id="tab-description" class="tab-pane active">
                <p class="intro"><?php echo $product['description']; ?></p>
                </div>
                <div id="tab-review" class="tab-pane">
                  <form id="form-review" class="form-horizontal">
                    <div id="review"><p>There are no reviews for this product.</p>
                    </div>
                    <h2>Write a review</h2>
                    <div class="form-group required">
                      <div class="col-sm-12">
                        <label for="input-name" class="control-label">Your Name</label>
                        <input type="text" class="form-control" id="input-name" value="" name="name" vk_106cf="subscribed">
                      </div>
                    </div>
                    <div class="form-group required">
                      <div class="col-sm-12">
                        <label for="input-review" class="control-label">Your Review</label>
                        <textarea class="form-control" id="input-review" rows="5" name="text"></textarea>
                        <div class="help-block"><span class="text-danger">Note:</span> HTML is not translated!</div>
                      </div>
                    </div>
                    <div class="form-group required">
                      <div class="col-sm-12">
                        <label class="control-label">Rating</label>
                        &nbsp;&nbsp;&nbsp; Bad&nbsp;
                        <input type="radio" value="1" name="rating">
                        &nbsp;
                        <input type="radio" value="2" name="rating">
                        &nbsp;
                        <input type="radio" value="3" name="rating">
                        &nbsp;
                        <input type="radio" value="4" name="rating">
                        &nbsp;
                        <input type="radio" value="5" name="rating">
                        &nbsp;Good</div>
                    </div>
                                    <div class="buttons clearfix">
                      <div class="pull-right">
                        <button class="btn btn-primary" data-loading-text="Loading..." id="button-review" type="button">Continue</button>
                      </div>
                    </div>
                  </form>
                </div>
                </div>
                          
                <div class="product-carousel relater-product">
                    <h3>Related Products</h3>
                    <div class="row">
                        <div id="carouse21" class="owl-carousel">
                          <?php
                            foreach ($subProduct as $row){
                          ?>
                            <div class="item">
                                <div class="product-layout">
                                <div class="product-thumb transition">
                                  <div class="image">
                                    <a href="<?= base_url('product/' . $row['id']); ?>">
                                      <img src="<?= base_url('uploads/md/' . $row['featured_img']); ?>" alt="" title="" class="img-responsive" />
                                    </a>
                                  </div>
                                  <div class="caption">
                                    <h4><a href="#"><?php echo $row['name']; ?></a></h4>
                                    <div class="rating">
                                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                                    </div>
                                     <p class="price">&#8364; <?php echo $row['price']; ?></p>
                                   </div>
                                </div>
                                </div>
                            </div>
                          <?php
                            }
                          ?>
                        </div>
                    </div>
                </div>
                
                <script type="text/javascript">
                $('#carouse21').owlCarousel({
                    items: 4,
                    autoPlay: 3000,
                    navigation: true,
                    navigationText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
                    pagination: false,
                    autoPlay: false,	
                    itemsDesktopSmall: [1199,3],
                    itemsTablet: [991,3],
                    itemsTabletSmall: [767,2],
                });
                </script>
      
        	</div>
    	</div>
        
        <script type="text/javascript">
			// $(document).ready(function() {
			// 	$('.thumbnails').magnificPopup({
			// 		type:'image',
			// 		delegate: 'a',
			// 		gallery: {
			// 			enabled:true
			// 		}
			// 	});
			// });
		</script>
    </div>
</div>

<?php  $this->load->view('includes/footer');  ?>