<?php
$this->load->view('includes/header');
?>
<div class="banner-in">
    <div class="container">
        <h1>Payment</h1>
        <ul class="newbreadcrumb">
            <li><a href="<?= base_url() ?>"> Home </a></li>
        </ul>
    </div>
</div>
<div id="main-container">
    <div class="container">
        <div class="row">
            <div class="col-lg-4"></div>
            <div class="col-lg-4" style="margin: 0 auto;">
                <div class="card">
                    <h4 style="text-align:center;"> Thanks for placing order #<?php echo $ord_id; ?> </h4>
                    <p style="text-align:center;"> Please check email for updates. </p>
                    <div style="text-align:center;"><a class="btn btn160 btn-lg btn-default" href="<?= base_url() ?>">Continue Shopping</a></div>
                </div>
            </div>
            <div class="col-lg-4"></div>
        </div>
    </div>
</div>

<?php
$this->load->view('includes/footer');
?>