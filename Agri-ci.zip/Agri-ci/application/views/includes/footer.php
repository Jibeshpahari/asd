<footer class="footer">
  <div class="container">
    <div class="row">
      <div class="col-sm-4">
        <aside class="widget">
          <h4>Navigation</h4>
          <ul class="list-unstyled">
            <li><a href="<?= base_url(); ?>">Home</a></li>
            <?php
            $categories = $this->UserModel->getCategory();
            foreach ($categories as $category) {
              echo '<li> <a href="#">' . $category['name'] . '</a> </li>';
            }
            ?>
          </ul>
        </aside>
      </div>
      <div class="col-sm-4">
        <aside class="widget">
          <h4>CONTACT US</h4>
          <p><i class="fa fa-paper-plane"></i> &nbsp; Ballinahowen, Athlone, Co. Westmeath</p>
          <p style="font-size:18px;"><i class="fa fa-phone"></i> &nbsp; (090) 6430244</span></p>
          <i class="fa fa-envelope"></i> &nbsp; <a
            href="mailto:agriexpress@outlook.com"><em>agriexpress@outlook.com</em></a>
          <div class="social-link">
            <a href="#"><i class="fa fa-facebook"></i></a>
            <a href="#"><i class="fa fa-twitter"></i></a>
            <a href="#"><i class="fa fa-linkedin"></i></a>
            <a href="#"><i class="fa fa-rss"></i></a>
          </div>
        </aside>
      </div>
      <div class="col-sm-4">
        <aside class="widget">
          <h4>OPENING HOURS</h4>
          <p>Our opening hours are as follows:<br>
            Monday-Saturday: 9a.m. - 6p.m.<br>
            Sunday: Closed<br>
            Bank Holidays: Closed </p>
          <p><strong>WE ACCEPT</strong></p>
          <img src="<?php echo base_url(); ?>/assets/images/cart.png" alt="">
        </aside>
      </div>
    </div>
  </div>
</footer>

<div class="footer-bottom">
  <div class="container">
    <div class="footer-logos"><img src="<?php echo base_url(); ?>/assets/images/logo-footer.png" alt=""></div>
    <div class="copyright">Copyright 2016 agridirect | All Rights Reserved :: Department of Agriculture, Food and
      the Marine </div>
  </div>
</div>

<script>
  // For Category and Sub-Category Menu
  $(document).ready(function() {
    $('.sub-category-list').addClass('d-none');
    <?php $segments = $this->uri->total_segments(); ?>
    var id = '<?= $this->uri->segment($segments) ?>';
    var segment = '<?= $this->uri->segment($segments - 1) ?>';
    if (segment == 'category') {
      var $el = $('.category[data-id="' + id + '"]');
      $el.addClass('active');
      $el.siblings('.sub-category-list').removeClass('d-none');
    } else {
      var $el = $('.sub-category[data-id="' + id + '"]');
      $el.addClass('active');
      $el.parent().parent().siblings().addClass('active');
      $el.parent().parent().toggleClass('d-none');
    }
    $('.category-list>li>a').on('click', function(e) {
      e.preventDefault();
      $(this).toggleClass('active');
      $(this).next('.sub-category-list').toggleClass('d-none');
      $(this).parent().siblings().find('.sub-category-list').addClass('d-none');
      $(this).parent().siblings().find('a').removeClass('active');
    });
  });

  function getProduct(segment, id, option, limit) {
    $.ajax({
      url: '<?= base_url('UserController/productSort'); ?>',
      type: 'POST',
      dataType: 'HTML',
      data: {
        segment: segment,
        id: id,
        option: option,
        limit: limit
      },
      success: function(data) {
        $('#product-list').html(data);
      }
    });
  }

  $(document).ready(function() {
    $('#input-sort, #input-limit').on('change', function() {
      <?php $segments = $this->uri->total_segments(); ?>
      var segment = '<?= $this->uri->segment($segments - 1) ?>';
      var id = '<?= $this->uri->segment($segments) ?>';
      var option = $('#input-sort').val();
      var limit = $('#input-limit').val();
      getProduct(segment, id, option, limit);
    });
  });

  $('div.sub-img-box').on('click', function() {
    var x = $(this).children().attr('alt');
    var y = $('#main-image').attr('alt');
    $('#main-image').attr('src', '<?= base_url('/uploads/md/') ?>' + x);
    $('#main-image').attr('alt', x);
  });

  $('.overlay').on('mouseover', function() {
    var x = $('#main-image').attr('alt');
    var path = '<?= base_url('/uploads/lg/') ?>' + x;
    $('#projector').attr('src', path);
    $('.lightbox').removeClass('d-none');
    $('.zoomer').removeClass('d-none');
    console.log(path);
  });

  $('.overlay').on('mousemove', function(e) {
    let fe_img = $('#main-image')[0];
    let projector_img = $('#projector')[0];
    let zoomer_img = $('.zoomer')[0];

    var imgW = fe_img.naturalWidth;
    var imgH = fe_img.naturalHeight;

    var cx = imgW - 250;
    var cy = imgH - 225;

    var parentOffset = $(this).parent().offset(); // get the real offset of the parent
    var relX = e.pageX - parentOffset.left;
    var relY = e.pageY - parentOffset.top;

    var leftX = relX - (250 / 2);
    var topY = relY - (225 / 2);

    if (leftX < 0) leftX = 0;
    if (topY < 0) topY = 0;
    if (leftX > cx) leftX = cx;
    if (topY > cy) topY = cy;

    $('.zoomer').css({
      'top': topY,
      'left': leftX
    });

    $('#projector').css({
      'top': -(topY * 2),
      'left': -(leftX * 2)
    });

  });

  $('.overlay').on('mouseout', function() {
    $('.lightbox').addClass('d-none');
    $('.zoomer').addClass('d-none');
  });

  // ----------------- Cart Page jquery -----------------

  function updateCart() {
    setTimeout(function() {
      $.ajax({
        url: '<?= base_url('UserController/getCart'); ?>',
        type: 'POST',
        dataType: 'HTML',
        success: function(data) {
          $('#cart').html(data);
        }
      });
    }, 0);
  }

  // FUNCTION TO GET BILLING DETAILS
  function billing() {
    $.ajax({
      url: '<?= base_url('UserController/getBilling'); ?>',
      type: 'POST',
      dataType: 'HTML',
      success: function(data) {
        $('#total-bill').html(data);
      }
    });
  }

  // FUNCTION TO REMOVE PRODUCT FROM CART
  function removeCart(cart_id) {
    $.ajax({
      url: '<?= base_url('UserController/removeItem'); ?>',
      type: 'POST',
      data: {
        id: cart_id
      },
      success: function(data) {

      }
    });
  }

  // Update the list of the items
  function cartList(message) {
    $.ajax({
      url: '<?= base_url('UserController/getItemList') ?>',
      type: 'GET',
      dataType: 'HTML',
      success: function(data) {
        $('.cart-table tbody').html(data);
        setInfoBox(message);
      }
    });
  }

  let timeout = null;

  function setInfoBox(message, type = "right") {
    $('.infoBox p').html(message);
    clearTimeout(timeout);
    if (type == 'error' || type == 'wrong') {
      $('.infoBox #right').attr("class", "d-none");
      $('.infoBox #wrong').attr("class", "");
    } else {
      $('.infoBox #right').attr("class", "");
      $('.infoBox #wrong').attr("class", "d-none");
    }
    $('.infoBox').css("display", "flex");
    timeout = setTimeout(function() {
      $('.infoBox').fadeOut(600);
    }, 3200);
  }


  // --------------------------- || ADD PRODUCT TO CART || ---------------------------
  // Update the cart on page load
  updateCart();

  // Add product to cart on click
  $(document).ready(function() {
    $('#button-cart').on('click', function() {
      var product_id = $('#product_id').val();
      var quantity = $('#input-quantity').val();
      if (quantity < 1 || quantity == "") {
        quantity = 1;
      }
      $.ajax({
        url: '<?= base_url('UserController/addToCart'); ?>',
        type: 'POST',
        dataType: 'json',
        beforeSend: function() {
          $('#button-cart').button('loading');
        },
        data: {
          product_id: product_id,
          quantity: quantity
        },
        success: function(data) {
          message = "Product added to cart successfully!";
          setInfoBox(message);
          updateCart();
          $('#button-cart').button('reset');
        }
      });
    });

  });

  // REMOVE PRODUCT FROM CART ON CLICK
  $(document).on('click', '.cart-remove', function() {
    var cart_id = $(this).data('cart-id');
    removeCart(cart_id);
    message = "Product removed from cart successfully!";
    setTimeout(function() {
      updateCart();
    }, 10);
    setTimeout(function() {
      billing();
    }, 10);
    setTimeout(function() {
      cartList(message);
    }, 10);
    var trCount = $('.cart-table tbody tr').length;
    if (trCount <= 1) {
      $('.checkout-btn').prop('disabled', true);
    }
  });

  // UPDATE PRODUCT QUANTITY
  $(document).on('click', '.cart-update', function(event) {
    event.preventDefault();
    var cart_id = $(this).data('cart-id');
    var qty = $(this).parent().parent().find('input[name="quantity"]').val();

    if (qty < 1 || qty == "") {
      qty = 1;
    }

    $.ajax({
      url: '<?= base_url('UserController/updateQuantity') ?>',
      type: 'POST',
      dataType: 'json',
      data: {
        rowid: cart_id,
        qty: qty
      },
      success: function(data) {
        if (data && data.success) {
          billing();
          message = "Product quantity updated successfully!";
          cartList(message);
        } else {
          message = "Something went wrong, please try again later";
          cartList(message, 'error');
        }
      }
    });
  });

  // ADD COUPON CODE TO BILLING
  $(document).on('click', '#button-coupon', function(event) {
    event.preventDefault();
    var coupon = $('#input-coupon').val();
    $.ajax({
      url: '<?= base_url('UserController/addCoupon'); ?>',
      type: 'POST',
      dataType: 'json',
      data: {
        coupon: coupon
      },
      success: function(data) {
        if (data.success) {
          message = data.message;
          setInfoBox(message);
        } else {
          message = data.message;
          setInfoBox(message, 'error');
        }
        billing();
      }
    });
  });

  $(document).ready(function() {
    $('#b_address').prop('checked', true);
    $('#b_address').on('change', function() {
      $('.row').toggleClass('d-none');
    });
  });

  //showing error messages
  $(document).ready(function() {
    var message = "<?= $this->session->flashdata('message'); ?>";
    if (message) {
      setInfoBox(message, 'error');
    }
  });
</script>


</body>

</html>