<?php

/*
| Define form validation rules
| ----------------------------
*/

$config = array(
        'checkAdmin' => array(
                array(
                        'field' => 'username',
                        'label' => 'Username',
                        'rules' => 'required'
                ),
                array(
                        'field' => 'password',
                        'label' => 'Password',
                        'rules' => 'required'
                )
        ),
        'addCategory' => array(
                array(
                        'field' => 'name',
                        'label' => 'Name',
                        'rules' => 'required'
                ),
                array(
                        'field' => 'order',
                        'label' => 'Order',
                        'rules' => 'numeric'
                ),
                array(
                        'field' => 'image',
                        'label' => 'Image',
                        'rules' => 'callback_validate_image'
                )
        ),
        'addSubCategory' => array(
                array(
                        'field' => 'category',
                        'label' => 'Category',
                        'rules' => 'required'
                ),
                array(
                        'field' => 'name',
                        'label' => 'Name',
                        'rules' => 'required'
                ),
                array(
                        'field' => 'order',
                        'label' => 'Order',
                        'rules' => 'numeric'
                )
        ),
        'addDiscount' => array(
                array(
                        'field' => 'name',
                        'label' => 'Name',
                        'rules' => 'required'
                ),
                array(
                        'field' => 'type',
                        'label' => 'Type',
                        'rules' => 'required'
                ),
                array(
                        'field' => 'amount',
                        'label' => 'Amount',
                        'rules' => 'required|numeric'
                )
        ),
        'addProduct' => array(
                array(
                        'field' => 'category',
                        'label' => 'Category',
                        'rules' => 'required'
                ),
                array(
                        'field' => 'sub_category',
                        'label' => 'Sub Category',
                        'rules' => 'required'
                ),
                array(
                        'field' => 'name',
                        'label' => 'Name',
                        'rules' => 'required'
                ),
                array(
                        'field' => 'price',
                        'label' => 'Price',
                        'rules' => 'required|numeric'
                ),
                array(
                        'field' => 'image',
                        'label' => 'Featured Image',
                        'rules' => 'callback_validate_image'
                ),
                array(
                        'field' => 'gallery[]',
                        'label' => 'Gallery Images',
                        'rules' => 'callback_validate_gallery_images'
                ),
        ),
        'checkUser' => array(
                array(
                        'field' => 'email',
                        'label' => 'Email Address',
                        'rules' => 'required|valid_email'
                ),
                array(
                        'field' => 'password',
                        'label' => 'Password',
                        'rules' => 'required'
                ),
        ),
        'registration' => array(
                array(
                        'field' => 'firstname',
                        'label' => 'First Name',
                        'rules' => 'trim|required'
                ),
                array(
                        'field' => 'lastname',
                        'label' => 'Last Name',
                        'rules' => 'trim|required'
                ),
                array(
                        'field' => 'email',
                        'label' => 'E-Mail',
                        'rules' => 'required|valid_email|is_unique[user.email]',
                        'errors' => array(
                                'is_unique' => 'Already have an account, please login'
                        )
                ),
                array(
                        'field' => 'telephone',
                        'label' => 'Telephone',
                        'rules' => 'trim|required|numeric|exact_length[10]'
                ),
                array(
                        'field' => 'address_1',
                        'label' => 'Address 1',
                        'rules' => 'trim|required'
                ),
                array(
                        'field' => 'city',
                        'label' => 'City',
                        'rules' => 'trim|required'
                ),
                array(
                        'field' => 'postcode',
                        'label' => 'Post Code',
                        'rules' => 'trim|required|numeric'
                ),
                array(
                        'field' => 'country_id',
                        'label' => 'Country',
                        'rules' => 'required'
                ),
                array(
                        'field' => 'zone_id',
                        'label' => 'Region / State',
                        'rules' => 'required'
                ),
                array(
                        'field' => 'password',
                        'label' => 'Password',
                        'rules' => 'required|min_length[4]'
                ),
                array(
                        'field' => 'confirm',
                        'label' => 'Confirm Password',
                        'rules' => 'required|matches[password]'
                ),
                array(
                        'field' => 'agree[]',
                        'label' => 'Recipients',
                        'rules' => 'required',
                        'errors' => array(
                                'required' => '*You must agree to the terms and conditions.'
                        )
                ),
        ),
        'addNewAddress' => array(
                array(
                        'field' => 'firstname',
                        'label' => 'First Name',
                        'rules' => 'trim|required'
                ),
                array(
                        'field' => 'lastname',
                        'label' => 'Last Name',
                        'rules' => 'trim|required'
                ),
                array(
                        'field' => 'email',
                        'label' => 'E-Mail',
                        'rules' => 'required|valid_email'
                ),
                array(
                        'field' => 'telephone',
                        'label' => 'Telephone',
                        'rules' => 'trim|required|numeric|exact_length[10]'
                ),
                array(
                        'field' => 'address_1',
                        'label' => 'Address 1',
                        'rules' => 'trim|required'
                ),
                array(
                        'field' => 'city',
                        'label' => 'City',
                        'rules' => 'trim|required'
                ),
                array(
                        'field' => 'postcode',
                        'label' => 'Post Code',
                        'rules' => 'trim|required|numeric'
                ),
                array(
                        'field' => 'country_id',
                        'label' => 'Country',
                        'rules' => 'required'
                ),
                array(
                        'field' => 'zone_id',
                        'label' => 'Region / State',
                        'rules' => 'required'
                )
        )

);
