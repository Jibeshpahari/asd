<?php

/*
| Define form validation rules
| ----------------------------
*/

$config = array(
    'checkAdmin' => array(
            array(
                    'field' => 'username',
                    'label' => 'Username',
                    'rules' => 'required'
            ),
            array(
                    'field' => 'password',
                    'label' => 'Password',
                    'rules' => 'required'
            )
        ),
    'addCategory' => array(
                array(
                                'field' => 'name',
                                'label' => 'Name',
                                'rules' => 'required'
                ),
                array(
                                'field' => 'order',
                                'label' => 'Order',
                                'rules' => 'numeric'
                ),
                array(
                                'field' => 'image',
                                'label' => 'Image',
                                'rules' => 'callback_validate_image'
                )
        )    
);