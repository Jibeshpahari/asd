<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/userguide3/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'UserController';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

/* ------------  Route for user  -------------------  */
// Route For Product page
$route['product/(:num)'] = 'UserController/product/$1';

// Route For Category page
$route['category/(:num)'] = 'UserController/category/$1';

// Route For Sub-category page
$route['category/sub_category/(:num)'] = 'UserController/subCategory/$1';

// Route For Search page
$route['search'] = 'UserController/search';

// Route For cart page
$route['cart'] = 'UserController/cart';

// Route for login page
$route['login'] = 'UserController/login';

// Route for registration page
$route['registration'] = 'UserController/register';

// Route for adding new addresses
$route['add/address'] = 'UserController/viewAddAddress';

// Route for billing
$route['billing/address'] = 'UserController/showBilling';

// Route for shipping
$route['shipping/address'] = 'UserController/viewShipping';

// Route for payment
$route['payment'] = 'UserController/payment';




/* ------------  Route for admin  -------------------  */
// For admin dashboard
$route['admin'] = 'AdminController/index';
$route['admin/dashboard'] = 'AdminController/index';

// For admin login
$route['admin/login'] = 'AdminController/login';
$route['admin/login_check'] = 'AdminController/checkAdmin';


// For Category in admin
$route['admin/category'] = 'AdminController/category';
$route['admin/category/add'] = 'AdminController/showAddCategory';
$route['admin/category/add/action'] = 'AdminController/addCategory';
$route['admin/category/edit/(:num)'] = 'AdminController/showEditCategory/$1';
$route['admin/category/edit/action'] = 'AdminController/editCategory/';
$route['admin/category/delete/(:any)'] = 'AdminController/deleteCategory/$1';

// For Sub-category in admin
$route['admin/sub_category'] = 'AdminController/subCategory';
$route['admin/sub_category/add'] = 'AdminController/showAddSubCategory';
$route['admin/sub_category/add/action'] = 'AdminController/addSubCategory';
$route['admin/sub_category/edit/(:any)'] = 'AdminController/showEditSubCategory/$1';
$route['admin/sub_category/action/edit'] = 'AdminController/editSubCategory/';
$route['admin/sub_category/delete/(:any)'] = 'AdminController/deleteSubCategory/$1';

// For Product in admin
$route['admin/product'] = 'AdminController/product';
$route['admin/product/add'] = 'AdminController/showAddProduct';
$route['admin/product/add/action'] = 'AdminController/addProduct';
$route['admin/product/edit/(:num)'] = 'AdminController/showEditProduct/$1';
$route['admin/product/edit/action'] = 'AdminController/editProduct';
$route['admin/product/delete/(:num)'] = 'AdminController/deleteProduct/$1';

// For Order in admin
$route['admin/orders'] = 'AdminController/orders';
$route['admin/orders/edit/(:num)'] = 'AdminController/showEditOrder/$1';
$route['admin/orders/edit/action'] = 'AdminController/editOrder';
$route['admin/orders/delete/(:num)'] = 'AdminController/deleteOrder/$1';

// For discount in admin
$route['admin/discount'] = 'AdminController/discount';
$route['admin/discount/add'] = 'AdminController/showAddDiscount';
$route['admin/discount/add/action'] = 'AdminController/addDiscount';
$route['admin/discount/edit/(:num)'] = 'AdminController/showEditDiscount/$1';
$route['admin/discount/edit/action'] = 'AdminController/editDiscount';
$route['admin/discount/delete/(:num)'] = 'AdminController/deleteDiscount/$1';

// For Customer in admin
$route['admin/customer'] = 'AdminController/customer';
$route['admin/customer/edit/(:num)'] = 'AdminController/showEditCustomer/$1';
$route['admin/customer/edit/action'] = 'AdminController/editCustomer';
$route['admin/customer/order/(:num)'] = 'AdminController/customerOrder/$1';
$route['admin/customer/delete/(:num)'] = 'AdminController/deleteCustomer/$1';

// For setting in admin
$route['admin/setting'] = 'AdminController/setting';
$route['admin/setting/action/update'] = 'AdminController/updateSetting';
