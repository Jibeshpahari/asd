<?php

defined('BASEPATH') or exit('No direct script access allowed');

class AdminModel extends CI_Model
{

    //      ------------------- ||  FUNCTION FOR ADMIN        || -------------------

    public function checkAdmin()
    {
        $username = $this->input->post('username');
        $password = $this->input->post('password');   // password - admin
        $password = md5($password);
        $this->db->where('username', $username);
        $this->db->where('password', $password);
        $query = $this->db->get('admin');
        if ($query->num_rows() == 1) {
            return $query->row_array();
        } else {
            return false;
        }

        // $this->db->or_where('password', $password);
    }

    //      ------------------- ||  FUNCTION FOR CATEGORY     || -------------------

    // Get the catagory from database by search key
    public function getCatagory($like = "")
    {
        $this->db->select('category.*, COUNT(sub_category.id) as num_sub_category');
        $this->db->from('category');
        $this->db->join('sub_category', 'category.id = sub_category.category', 'left');
        if (!empty($like)) {
            $this->db->like('category.name', $like);
        }
        $this->db->group_by('category.id');
        $this->db->order_by('category.id', 'DESC');
        $query = $this->db->get();
        return $query->result_array();
    }

    // Get category details from database by category id
    public function getCategoryById($id)
    {
        $this->db->select('category.*, COUNT(sub_category.id) as num_sub_category');
        $this->db->from('category');
        $this->db->join('sub_category', 'category.id = sub_category.category', 'left');
        $this->db->where('category.id', $id);
        $this->db->group_by('category.id');
        $query = $this->db->get();
        return $query->row_array();
    }

    // Add new category in databse
    public function addCategory()
    {
        $data = array(
            'name'    => $this->input->post('name'),
            'ranking' => $this->input->post('order'),
            'image'   => $this->upload->data('file_name'),
            'status'  =>  $this->input->post('status')
        );
        return $this->db->insert('category', $data);
    }

    // Update category details
    public function updateCategory($id)
    {
        $data = array(
            'name'    => $this->input->post('name'),
            'ranking' => $this->input->post('order'),
            'status'  => $this->input->post('status')
        );

        // Check if a new image is uploaded
        if ($this->upload->data('file_name')) {
            $data['image'] = $this->upload->data('file_name');
        }

        $this->db->where('id', $id);
        return $this->db->update('category', $data);
    }

    // Delete catagory by category id
    public function deleteCategory($id)
    {
        $this->db->where('id', $id);
        $result = $this->db->delete('category');
        return $result;
    }


    //      ------------------- ||  FUNCTION FOR SUB-CATEGORY || -------------------

    // Get the Sub-catagory from database by search key
    public function getSubCatagory($like = "")
    {
        $this->db->select('sub_category.*, category.name as category');
        $this->db->from('sub_category');
        $this->db->join('category', 'sub_category.category = category.id', 'inner');
        if (!empty($like)) {
            $this->db->like('sub_category.name', $like);
        }
        $this->db->order_by('sub_category.id', 'DESC');
        $query = $this->db->get();
        return $query->result_array();
    }

    // Get Sub_category details from databse by Sub_category id
    public function getSubCategoryById($id)
    {
        $this->db->select('sub_category.*, category.name as category, category.id as category_id, COUNT(product.id) as products');
        $this->db->from('sub_category');
        $this->db->join('category', 'sub_category.category = category.id', 'inner');
        $this->db->join('product', 'sub_category.id = product.sub_category', 'left');
        $this->db->where('sub_category.id', $id);
        $this->db->group_by('sub_category.id');
        $query = $this->db->get();
        return $query->row_array();
    }

    // Add new Sub_category in databse
    public function addSubCategory()
    {
        $data = array(
            'category' => $this->input->post('category'),
            'name'     => $this->input->post('name'),
            'ranking'  => $this->input->post('order'),
            'status'   => $this->input->post('status')
        );
        return $this->db->insert('sub_category', $data);
    }

    // Update Sub Category by Sub Category Id
    public function updateSubCategory($id)
    {
        $data = array(
            'category' => $this->input->post('category'),
            'name'     => $this->input->post('name'),
            'ranking'  => $this->input->post('order'),
            'status'   => $this->input->post('status')
        );
        $this->db->where('id', $id);
        return $this->db->update('sub_category', $data);
    }

    // Delete catagory by category id
    public function deleteSubCategory($id)
    {
        $this->db->where('id', $id);
        $result = $this->db->delete('sub_category');
        return $result;
    }

    //      ------------------- ||  FUNCTION FOR PRODUCT      || -------------------

    // Get the Product from database by search key
    public function getProduct($like = "")
    {
        $this->db->select('product.*, category.name as category, sub_category.name as sub_category');
        $this->db->from('product');
        $this->db->join('category', 'product.category = category.id', 'inner');
        $this->db->join('sub_category', 'product.sub_category = sub_category.id', 'inner');
        if (!empty($like)) {
            $this->db->like('product.name', $like);
        }
        $this->db->order_by('product.id', 'DESC');
        $query = $this->db->get()->result_array();
        return $query;
    }

    // Get sub-category details from database by category id
    public function getSubCategoryByCategoryId($category_id)
    {
        $this->db->select('sub_category.*, category.name as category');
        $this->db->from('sub_category');
        $this->db->join('category', 'sub_category.category = category.id', 'inner');
        $this->db->where('sub_category.category', $category_id);
        $query = $this->db->get();
        return $query->result_array();
    }

    // Get product details from database by product id
    public function getProductById($id)
    {
        $this->db->select('*');
        $this->db->from('product');
        $this->db->where('id', $id);
        $query = $this->db->get();
        return $query->row_array();
    }

    // Get product gallery images by product id
    public function getGalleryByProductId($id)
    {
        $this->db->where('pro_id', $id);
        $query = $this->db->get('gallery');
        return $query->result_array();
    }

    // Get gallery image by id
    public function getGalleryImageById($id)
    {
        return $this->db->get_where('gallery', ['id' => $id])->row_array();
    }
    // Add new product in database
    public function addProduct()
    {
        $data = array(
            'category'     => $this->input->post('category'),
            'sub_category' => $this->input->post('sub_category'),
            'name'         => $this->input->post('name'),
            'description'  => $this->input->post('description'),
            'price'        => $this->input->post('price'),
            'featured_img' => $_FILES['image']['name'],
            'stock'        => $this->input->post('availability'),
            'special'      => $this->input->post('special') ? 1 : 0,
            'featured'     => $this->input->post('featured') ? 1 : 0
        );
        return $this->db->insert('product', $data);
    }

    // Add product gallery images in database
    public function addProductGallery($product_id, $images)
    {
        $data = array();
        foreach ($images['name'] as $key => $image) {
            $data[] = array(
                'pro_id' => $product_id,
                'img'    => $image
            );
        }
        return $this->db->insert_batch('gallery', $data);
    }

    // Update product details
    public function updateProduct($id)
    {
        $data = array(
            'category'     => $this->input->post('category'),
            'sub_category' => $this->input->post('sub_category'),
            'name'         => $this->input->post('name'),
            'description'  => $this->input->post('description'),
            'price'        => $this->input->post('price'),
            'stock'        => $this->input->post('availability'),
            'special'      => $this->input->post('special') ? 1 : 0,
            'featured'     => $this->input->post('featured') ? 1 : 0
        );
        if ($_FILES['image']['name']) {
            $data['featured_img'] = $_FILES['image']['name'];
        }
        $this->db->where('id', $id);
        return $this->db->update('product', $data);
    }

    // Update product gallery images
    public function updateProductGallery($product_id, $images)
    {
        $data = array();
        foreach ($images['name'] as $key => $image) {
            $data[] = array(
                'pro_id' => $product_id,
                'img'    => $image
            );
        }
        return $this->db->insert_batch('gallery', $data);
    }

    // Delete Product gallery images
    public function deleteProductGallery($id)
    {
        $this->db->where('id', $id);
        return $this->db->delete('gallery');
    }

    // Delete product by product id
    public function deleteProduct($id)
    {
        $this->db->where('pro_id', $id);
        $this->db->delete('gallery');
        $this->db->where('id', $id);
        return $this->db->delete('product');
    }

    //      ------------------- ||  FUNCTION FOR ORDER        || -------------------

    // Get the Order from database by search key
    public function getOrders($like = "")
    {
        $this->db->select('orderlist.*, location.address1, user.fname, user.lname');
        $this->db->from('orderlist');
        $this->db->join('location', 'orderlist.shpg_address = location.id', 'inner');
        $this->db->join('user', 'orderlist.user_id = user.id', 'inner');
        if (!empty($like)) {
            $this->db->like('orderlist.id', $like);
        }
        $this->db->order_by('orderlist.id', 'DESC');
        $query = $this->db->get();
        return $query->result_array();
    }

    // Get order details by order id
    public function getOrderDetailsById($id)
    {
        $this->db->select('*');
        $this->db->from('orderlist');
        $this->db->where('id', $id);
        $query = $this->db->get();
        return $query->row_array();
    }

    // Get Items by order id
    public function getItemsByOrderId($order_id)
    {
        $this->db->select('items.*, product.name as product_name');
        $this->db->from('items');
        $this->db->join('product', 'items.pro_id = product.id', 'inner');
        $this->db->where('items.order_id', $order_id);
        $query = $this->db->get();
        return $query->result_array();
    }

    // Update order details
    public function updateOrder($id)
    {
        $data = array(
            'ord_status' => $this->input->post('ord_status'),
            'pay_status' => $this->input->post('pay_status'),
        );
        $this->db->where('id', $id);
        return $this->db->update('orderlist', $data);
    }

    // Delete order by order id
    public function deleteOrder($id)
    {
        // First delete items associated with the order
        $this->db->where('order_id', $id);
        $this->db->delete('items');

        // Then delete the order itself
        $this->db->where('id', $id);
        return $this->db->delete('orderlist');
    }

    // Get all orders by user id
    public function getOrdersByUserId($user_id)
    {
        $this->db->select('*');
        $this->db->from('orderlist');
        $this->db->where('user_id', $user_id);
        $this->db->order_by('id', 'DESC');
        $query = $this->db->get();
        return $query->result_array();
    }

    //      ------------------- ||  FUNCTION FOR CUSTOMER     || -------------------

    // Get the customer from database by search key
    public function getCustomers($like = "")
    {
        $this->db->select('user.*, COUNT(orderlist.id) as num_orders');
        $this->db->from('user');
        $this->db->join('orderlist', 'user.id = orderlist.user_id', 'left');
        if (!empty($like)) {
            $this->db->like('user.fname', $like);
            $this->db->or_like('user.lname', $like);
        }
        $this->db->group_by('user.id');
        $this->db->order_by('user.id', 'DESC');
        $query = $this->db->get();
        return $query->result_array();
    }

    // Get customer details from database by customer id
    public function getCustomerById($id)
    {
        $this->db->where('id', $id);
        $query = $this->db->get('user');
        return $query->row_array();
    }

    // Update customer details
    public function updateCustomer($id)
    {
        $data = array(
            'fname'    => $this->input->post('fname'),
            'lname'    => $this->input->post('lname'),
            'email'    => $this->input->post('email'),
            'phone'    => $this->input->post('telephone'),
            'fax'      => $this->input->post('fax'),
            'status'   => $this->input->post('status')
        );
        $this->db->where('id', $id);
        return $this->db->update('user', $data);
    }

    // Delete customer by customer id
    public function deleteCustomer($id)
    {
        $this->db->where('user_id', $id);
        $order_count = $this->db->count_all_results('orderlist');

        if ($order_count > 0) {
            $this->session->set_flashdata('message', 'Cannot delete customer with existing orders.');
            redirect('admin/customer');
        } else {
            $this->db->where('u_id', $id);
            $this->db->delete('location');
            $this->db->where('id', $id);
            return $this->db->delete('user');
        }
    }

    //      ------------------- ||  FUNCTION FOR DISCOUNT     || -------------------

    // Get the discount from database by search key
    public function getDiscounts($like = '')
    {
        $this->db->select('*');
        $this->db->from('discount');
        if (!empty($like)) {
            $this->db->like('name', $like);
        }
        $this->db->order_by('id', 'DESC');
        $query = $this->db->get();
        return $query->result_array();
    }

    // Get discount details from database by discount id
    public function getDiscountById($id)
    {
        $this->db->where('id', $id);
        $query = $this->db->get('discount');
        return $query->row_array();
    }

    // Add new discount in database
    public function addDiscount()
    {
        $data = array(
            'name'       => $this->input->post('name'),
            'valid_from' => $this->input->post('validFrom'),
            'valid_till' => $this->input->post('validTill'),
            'type'       => $this->input->post('type'),
            'amount'     => $this->input->post('amount'),
            'status'     => $this->input->post('status')
        );
        return $this->db->insert('discount', $data);
    }

    // Edit discount details
    public function updateDiscount($id)
    {
        $data = array(
            'name'       => $this->input->post('name'),
            'valid_from' => $this->input->post('validFrom'),
            'valid_till' => $this->input->post('validTill'),
            'type'       => $this->input->post('type'),
            'amount'     => $this->input->post('amount'),
            'status'     => $this->input->post('status')
        );
        $this->db->where('id', $id);
        return $this->db->update('discount', $data);
    }

    // Delete discount by discount id
    public function deleteDiscount($id)
    {
        $this->db->where('id', $id);
        $result = $this->db->delete('discount');
        return $result;
    }



    //      ------------------- ||  FUNCTION FOR SETTING      || -------------------

    public function getSettings($id)
    {
        $this->db->where('id', $id);
        $query = $this->db->get('admin');
        return $query->row_array();
    }

    public function updateSetting($id)
    {
        $data = array(
            'username' => $this->input->post('username')
        );
        if ($this->input->post('password')) {
            $data['password'] = md5($this->input->post('password'));
        }
        $this->db->where('id', $id);
        return $this->db->update('admin', $data);
    }

    //      ------------------- ||  FUNCTION FOR ADDRESS      || -------------------

    // Get address by id
    public function getAddressById($id)
    {
        $this->db->where('id', $id);
        $query = $this->db->get('location');
        return $query->row_array();
    }

    // Get location by order id
    public function getLocationByOrderId($order_id)
    {
        $this->db->select('location.*');
        $this->db->from('location');
        $this->db->join('orderlist', 'location.id = orderlist.shpg_address', 'inner');
        $this->db->where('orderlist.id', $order_id);
        $query = $this->db->get();
        return $query->row_array();
    }

    // Get all addresses by user id
    public function getAddressByUserId($user_id)
    {
        $this->db->where('u_id', $user_id);
        $query = $this->db->get('location');
        return $query->result_array();
    }

    // Update address details
    public function updateAddress($id, $i)
    {
        $data = array(
            'company'  => $this->input->post('company1' . $i),
            'address1' => $this->input->post('firstlocation' . $i),
            'address2' => $this->input->post('secondlocation' . $i),
            'city'     => $this->input->post('city' . $i),
            'postcode' => $this->input->post('postcode' . $i),
            'country'  => $this->input->post('country' . $i),
            'region'   => $this->input->post('region' . $i)
        );
        $this->db->where('id', $id);
        return $this->db->update('location', $data);
    }
}
