<?php

    defined('BASEPATH') OR exit('No direct script access allowed');

    class AdminModel extends CI_Model {

//      ------------------- ||  FUNCTION FOR ADMIN        || -------------------

        public function checkAdmin(){
            $username = $this->input->post('username');
            $password = $this->input->post('password');   // password - admin
            $password = md5($password);
            $this->db->where('username', $username);
            $this->db->where('password', $password);
            $query = $this->db->get('admin');
            if ($query->num_rows() == 1) {
                return $query->row_array();
            } else {
                return false;
            }

            // $this->db->or_where('password', $password);
        }

//      ------------------- ||  FUNCTION FOR CATEGORY     || -------------------

        // Get the catagory from database by search key
        public function getCatagory($like = "") {
            $this->db->select('category.*, COUNT(sub_category.id) as num_sub_category');
            $this->db->from('category');
            $this->db->join('sub_category', 'category.id = sub_category.category', 'left');
            if (!empty($like)) {
                $this->db->like('category.name', $like);
            }
            $this->db->group_by('category.id');
            $this->db->order_by('category.id', 'DESC');
            $query = $this->db->get();
            return $query->result_array();
        }

        // Add new category in databse
        public function addCategory(){
            $data = array(
                'name'    => $this->input->post('name'),
                'ranking' => $this->input->post('order'),
                'image'   => $this->upload->data('file_name'),
                'status'  =>  $this->input->post('status')
            );
            return $this->db->insert('category', $data);
        }

        // Get category details from database by category id
        public function getCategoryById($id){
            $this->db->select('category.*, COUNT(sub_category.id) as num_sub_category');
            $this->db->from('category');
            $this->db->join('sub_category', 'category.id = sub_category.category', 'left');
            $this->db->where('category.id', $id);
            $this->db->group_by('category.id');
            $query = $this->db->get();
            return $query->row_array();
        }

        // Update category details
        public function updateCategory($id) {
            $data = array(
                'name'    => $this->input->post('name'),
                'ranking' => $this->input->post('order'),
                'status'  => $this->input->post('status')
            );

            // Check if a new image is uploaded
            if ($this->upload->data('file_name')) {
                $data['image'] = $this->upload->data('file_name');
            }

            $this->db->where('id', $id);
            return $this->db->update('category', $data);
        }

        // Delete catagory by category id
        public function deleteCategory($id) {
            $this->db->where('id', $id);
            $result = $this->db->delete('category');
            return $result;
        }


//      ------------------- ||  FUNCTION FOR SUB-CATEGORY || -------------------

        // Get the Sub-catagory from database by search key
        public function getSubCatagory($like = "") {
            $this->db->select('sub_category.*, category.name as category');
            $this->db->from('sub_category');
            $this->db->join('category', 'sub_category.category = category.id', 'inner');
            if (!empty($like)) {
                $this->db->like('sub_category.name', $like);
            }
            $this->db->order_by('sub_category.id', 'DESC');
            $query = $this->db->get();
            return $query->result_array();
        }

        // Get Sub_category details from databse by Sub_category id
        public function getSubCategoryById($id) {
            $this->db->select('sub_category.*, category.name as category, category.id as category_id, COUNT(product.id) as products');
            $this->db->from('sub_category');
            $this->db->join('category', 'sub_category.category = category.id', 'inner');
            $this->db->join('product', 'sub_category.id = product.sub_category', 'left');
            $this->db->where('sub_category.id', $id);
            $this->db->group_by('sub_category.id');
            $query = $this->db->get();
            return $query->row_array();
        }

        // Add new Sub_category in databse
        public function addSubCategory(){
            $data = array(
                'category' => $this->input->post('category'),
                'name'     => $this->input->post('name'),
                'ranking'  => $this->input->post('order'),
                'status'   => $this->input->post('status')
            );
            return $this->db->insert('sub_category', $data);
        }

        // Update Sub Category by Sub Category Id
        public function updateSubCategory($id){
            $data = array(
                'category' => $this->input->post('category'),
                'name'     => $this->input->post('name'),
                'ranking'  => $this->input->post('order'),
                'status'   => $this->input->post('status')
            );
            $this->db->where('id', $id);
            return $this->db->update('sub_category', $data);
        } 

        // Delete catagory by category id
        public function deleteSubCategory($id) {
            $this->db->where('id', $id);
            $result = $this->db->delete('sub_category');
            return $result;
        }


//      ------------------- ||  FUNCTION FOR PRODUCT      || -------------------

        // Get the Product from database by search key
        public function getProduct($like = ""){
            $this->db->select('product.*, category.name as category, sub_category.name as sub_category');
            $this->db->from('product');
            $this->db->join('category','product.category = category.id', 'inner');
            $this->db->join('sub_category','product.sub_category = sub_category.id', 'inner');
            if (!empty($like)) {
                $this->db->like('product.name', $like);
            }
            $this->db->order_by('product.id', 'DESC');
            $query = $this->db->get()->result_array();
            return $query;
        }

//      ------------------- ||  FUNCTION FOR DISCOUNT     || -------------------

        // Get the discount from database by search key
        public function getDiscounts($like=''){
            $this->db->select('*');
            $this->db->from('discount');
            if (!empty($like)) {
                $this->db->like('name', $like);
            }
            $this->db->order_by('id', 'DESC');
            $query = $this->db->get();
            return $query->result_array();
        }

        // Get discount details from database by discount id
        public function getDiscountById($id) {
            $this->db->where('id', $id);
            $query = $this->db->get('discount');
            return $query->row_array();
        }

        // Add new discount in database
        public function addDiscount() {
            $data = array(
                'name'       => $this->input->post('name'),
                'valid_from' => $this->input->post('validFrom'),
                'valid_till' => $this->input->post('validTill'),
                'type'       => $this->input->post('type'),
                'amount'     => $this->input->post('amount'),
                'status'     => $this->input->post('status')
            );
            return $this->db->insert('discount', $data);
        }

        // Edit discount details
        public function updateDiscount($id) {
            $data = array(
                'name'       => $this->input->post('name'),
                'valid_from' => $this->input->post('validFrom'),
                'valid_till' => $this->input->post('validTill'),
                'type'       => $this->input->post('type'),
                'amount'     => $this->input->post('amount'),
                'status'     => $this->input->post('status')
            );
            $this->db->where('id', $id);
            return $this->db->update('discount', $data);
        }

        // Delete discount by discount id
        public function deleteDiscount($id) {
            $this->db->where('id', $id);
            $result = $this->db->delete('discount');
            return $result;
        }


//      ------------------- ||  FUNCTION FOR SETTING      || -------------------

        public function getSettings($id){
            $this->db->where('id', $id);
            $query = $this->db->get('admin');
            return $query->row_array();
        }

        public function updateSetting($id) {
            $data = array(
                'username' => $this->input->post('username')
            );
            if ($this->input->post('password')) {
                $data['password'] = md5($this->input->post('password'));
            }
            $this->db->where('id', $id);
            return $this->db->update('admin', $data);
        }







    }