<?php
    defined('BASEPATH') OR exit('No direct script access allowed');

    class HomeModel extends CI_Model{
        public function data(){
            $query = $this->db->where('id', 28)->get('user')->result();
            return $query;
        }
    }