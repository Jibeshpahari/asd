<?php

defined('BASEPATH') or exit('No direct script access allowed');

class UserModel extends CI_Model
{
    //  --------------------- ||  FUNCTION FOR CATEGORY      || ---------------------
    // Get all active category
    public function getCategory()
    {
        $this->db->where('status', 'ACTIVE');
        $query = $this->db->get('category');
        return $query->result_array();
    }

    //  --------------------- ||  FUNCTION FOR SUB CATEGORY  || ---------------------
    // Get all sub category by category id
    public function getSubCategory($category_id)
    {
        $this->db->where('category', $category_id);
        $query = $this->db->get('sub_category');
        return $query->result_array();
    }

    //  --------------------- ||  FUNCTION FOR PRODUCT       || ---------------------
    // Get all the special product
    public function getSpecialProduct()
    {
        $this->db->where('special', '1');
        $this->db->order_by('RAND()');
        $query = $this->db->get('product')->result_array();
        return $query;
    }

    // Get all the featured product
    public function getFeaturedProduct()
    {
        $this->db->where('featured', '1');
        $this->db->order_by('RAND()');
        $query = $this->db->get('product')->result_array();
        return $query;
    }

    // Get product images by product id
    public function getProductGallery($id)
    {
        $this->db->where('pro_id', $id);
        $query = $this->db->get('gallery');
        return $query->result_array();
    }

    // Get similar products by product id
    public function getSimilarByProductId($id, $sub_category_id)
    {
        $this->db->where('id !=', $id);
        $this->db->where('sub_category', $sub_category_id);
        $this->db->order_by('RAND()');
        $query = $this->db->get('product', 4);
        return $query->result_array();
    }

    // Get products by category id
    public function getProductByCategory($category_id)
    {
        $this->db->where('category', $category_id);
        $this->db->order_by('RAND()');
        $query = $this->db->get('product');
        return $query->result_array();
    }

    // Get products by sub category id
    public function getProductBySubCategory($sub_category_id)
    {
        $this->db->where('sub_category', $sub_category_id);
        $this->db->order_by('RAND()');
        $query = $this->db->get('product');
        return $query->result_array();
    }

    // Get products by search keyword
    public function getProductBySearch($search)
    {
        $this->db->like('name', $search);
        // $this->db->or_like('description', $search);
        $this->db->order_by('RAND()');
        $query = $this->db->get('product');
        return $query->result_array();
    }

    // Get product by condition
    public function getProductSegment()
    {
        $segment = $this->input->post('segment');
        $id = $this->input->post('id');
        $option = $this->input->post('option');
        $limit = $this->input->post('limit');

        $this->db->select('*');

        if ($segment == 'category') {
            $this->db->where('category', $id);
        } elseif ($segment == 'sub_category') {
            $this->db->where('sub_category', $id);
        }

        switch ($option) {
            case 1:
                $this->db->order_by('name', 'asc');
                break;
            case 2:
                $this->db->order_by('name', 'desc');
                break;
            case 3:
                $this->db->order_by('price', 'asc');
                break;
            case 4:
                $this->db->order_by('price', 'desc');
                break;
            default:
                $this->db->order_by('RAND()');
                break;
        }

        if (!empty($limit) && is_numeric($limit)) {
            $this->db->limit($limit);
        }

        $query = $this->db->get('product');
        return $query->result_array();
    }

    //  --------------------- ||  FUNCTION FOR DISCOUNT      || ---------------------
    // Get the category dta by name
    public function getDiscountByName($coupon)
    {
        $this->db->select('*');
        $this->db->where('name', $coupon);
        $this->db->where('status', 'ACTIVE');
        $query = $this->db->get('discount')->row_array();
        return $query;
    }

    //  --------------------- ||  FUNCTION FOR LOGIN         || ---------------------
    // Hashing the given value
    public function hash_password($password)
    {
        return password_hash($password, PASSWORD_BCRYPT);
    }

    // check user details
    public function userLogin($email, $password)
    {
        $password = md5($password);
        $this->db->select('*');
        $this->db->where('email', $email);
        $this->db->where('password', $password);
        $result = $this->db->get('user')->row_array();
        return $result;
    }

    //  --------------------- ||  FUNCTION FOR REGISTER      || ---------------------
    // Register new user
    public function registration()
    {
        $user = array(
            'fname'    => $this->input->post('firstname'),
            'lname'    => $this->input->post('lastname'),
            'email'    => $this->input->post('email'),
            'phone'    => $this->input->post('telephone'),
            'fax'      => $this->input->post('fax'),
            'password' => $this->input->post('password')
        );

        $this->db->insert('user', $user);
        return $this->db->insert_id();
    }

    // add user address
    public function addAddress($id)
    {
        $location = array(
            'u_id'      => $id,
            'fname'     => $this->input->post('firstname'),
            'lname'     => $this->input->post('lastname'),
            'email'     => $this->input->post('email'),
            'phone'     => $this->input->post('telephone'),
            'fax'       => $this->input->post('fax'),
            'company'   => $this->input->post('company'),
            'address1'  => $this->input->post('address_1'),
            'address2'  => $this->input->post('address_2'),
            'postcode'  => $this->input->post('postcode'),
            'country'   => $this->input->post('country_id'),
            'region'    => $this->input->post('zone_id'),
        );

        return $this->db->insert('location', $location);
    }

    //  --------------------- ||  FUNCTION FOR ORDER         || ---------------------
    // INSERT ORDER
    public function insertOrder($data)
    {
        $this->db->insert('orderlist', $data);
        return $this->db->insert_id();
    }

    // Insert Order Items
    public function insertItems($items, $order_ID)
    {
        foreach ($items as $item) {
            $order_item = array(
                'order_id'   => $order_ID,
                'pro_id' => isset($item['id']) ? $item['id'] : null,
                'qty'   => isset($item['quantity']) ? $item['quantity'] : 1,
                'price'      => isset($item['price']) ? $item['price'] : 0
            );
            return $this->db->insert('items', $order_item);
        }
    }
}
