<?php

    defined('BASEPATH') OR exit('No direct script access allowed');

    class UserLoginModel extends CI_Model{

        public function login($fromArray){
            print_r($fromArray);
        }

    }