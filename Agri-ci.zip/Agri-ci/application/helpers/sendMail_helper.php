<?php
defined('BASEPATH') OR exit('No direct script access allowed');

if (!function_exists('send_mail')) {

    function send_mail($to, $subject, $message, $from = 'agri@stagedwebsite.com', $from_name = 'Agri Express', $attachments = [])
    {
        $CI =& get_instance();
        $CI->load->library('email');

        // Use default mail settings from php.ini/sendmail.ini
        $config = [
            'protocol'  => 'mail', // Use PHP's mail() function
            'mailtype'  => 'html',
            'charset'   => 'utf-8',
            'newline'   => "\r\n",
            'crlf'      => "\r\n",
        ];

        $CI->email->initialize($config);

        $CI->email->from($from, $from_name);
        $CI->email->to($to);
        $CI->email->subject($subject);
        $CI->email->message($message);
        $CI->email->set_header('Content-Type', 'text/html');

        if (!empty($attachments)) {
            foreach ($attachments as $file) {
                $CI->email->attach($file);
            }
        }

        if ($CI->email->send()) {
            return true;
        }
            
        log_message('error', 'Email send failed: ' . $CI->email->print_debugger());
        return false;
    }
}
