<?php
defined('BASEPATH') OR exit('No direct script access allowed');

if (!function_exists('send_mail')) {
    /**
     * Send an email using CodeIgniter's email library.
     *
     * @param string $to Recipient email address
     * @param string $subject Email subject
     * @param string $message Email message (HTML allowed)
     * @param string $from Sender email address (optional)
     * @param string $from_name Sender name (optional)
     * @param array $attachments Array of file paths to attach (optional)
     * @return bool True on success, false on failure
     */
    function send_mail($to, $subject, $message, $from = '', $from_name = 'Agri', $attachments = [])
    {
        $CI =& get_instance();
        $CI->load->library('email');

        // Set email config if needed
        // $config['mailtype'] = 'html';
        // $CI->email->initialize($config);

        $CI->email->from($from, $from_name);
        $CI->email->to($to);
        $CI->email->subject($subject);
        $CI->email->message($message);

        if (!empty($attachments) && is_array($attachments)) {
            foreach ($attachments as $file) {
                $CI->email->attach($file);
            }
        }

        $result = $CI->email->send();
        if (!$result) {
            echo $CI->email->print_debugger();
        }else{
            return $result;
        }
    }
}