<?php
defined('BASEPATH') OR exit('No direct script access allowed');

if (!function_exists('send_mail')) {
    /**
     * Send an email using your stagedwebsite.com SMTP credentials.
     *
     * @param string $to Recipient email address
     * @param string $subject Email subject
     * @param string $message HTML content
     * @param string $from Optional sender email
     * @param string $from_name Optional sender name
     * @param array $attachments Optional file attachments
     * @return bool True if sent, False otherwise
     */
    function send_mail($to, $subject, $message, $from = 'agri@stagedwebsite.com', $from_name = 'Agri Express', $attachments = [])
    {
        $CI =& get_instance();
        $CI->load->library('email');

        // ✅ Real SMTP configuration for stagedwebsite.com
        $config = [
            'protocol'  => 'smtp',
            'smtp_host' => 'ssl://mail.stagedwebsite.com', // Use ssl:// because port is 465
            'smtp_port' => 465,
            'smtp_user' => 'agri@stagedwebsite.com',
            'smtp_pass' => 'f4]$f7G#&vq)', // 🔐 Replace with your real password
            'mailtype'  => 'html',
            'charset'   => 'utf-8',
            'newline'   => "\r\n",
            'crlf'      => "\r\n",
        ];

        $CI->email->initialize($config);

        $CI->email->from($from, $from_name);
        $CI->email->to($to);
        $CI->email->subject($subject);
        $CI->email->message($message);
        $CI->email->set_header('Content-Type', 'text/html');

        if (!empty($attachments)) {
            foreach ($attachments as $file) {
                $CI->email->attach($file);
            }
        }

        if ($CI->email->send()) {
            return true;
        } else {
            log_message('error', 'Email send failed: ' . $CI->email->print_debugger());
            return false;
        }
    }
}
