<?php
defined('BASEPATH') OR exit('No direct script access allowed');

if (!function_exists('send_mail')) {

    function send_mail($to, $subject, $message, $from = 'agri@stagedwebsite.com', $from_name = 'Agri Express', $attachments = [])
    {
        $CI =& get_instance();
        $CI->load->library('email');

        $config = [
            'protocol'     => 'smtp',
            'smtp_host'    => 'ssl://mail.stagedwebsite.com',
            'smtp_port'    => 465,
            'smtp_user'    => 'agri@stagedwebsite.com',
            'smtp_pass'    => 'gxpRUKcZmq&3', // 🔁 Replace with actual password
            'mailtype'     => 'html',
            'charset'      => 'utf-8',
            'newline'      => "\r\n",
            'crlf'         => "\r\n",
            'smtp_timeout' => 30,
        ];

        $CI->load->library('email', $config); // ✅ Pass $config here!
        $CI->email->initialize($config);      // ✅ Optional but safe
        $CI->email->from('agri@stagedwebsite.com', 'Agri');
        $CI->email->to($to);
        $CI->email->subject($subject);
        $CI->email->message($message);

        if ($CI->email->send()) {
            echo "Email sent successfully.";
        } else {
            echo "Email sending failed.<br>";
            return $CI->email->print_debugger(['headers']);
        }
    }
}
