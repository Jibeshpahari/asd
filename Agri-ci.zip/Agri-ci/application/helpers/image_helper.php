<?php

defined('BASEPATH') or exit('No direct script access allowed');

if (!function_exists('resizeImage')) {
    function resizeImage($sourcePath, $destinationPath, $width, $height)
    {
        $ci = &get_instance();
        $ci->load->library('image_lib');

        $config = [
            'image_library'  => 'gd2',
            'source_image'   => $sourcePath,
            'new_image'      => $destinationPath,
            'maintain_ratio' => TRUE,
            'width'          => $width,
            'height'         => $height,
        ];

        $ci->image_lib->initialize($config);

        if (!$ci->image_lib->resize()) {
            log_message('error', $ci->image_lib->display_errors());
            return FALSE;
        }

        $ci->image_lib->clear();
        return TRUE;
    }
}

if (!function_exists('uploadImage')) {
    function uploadImage($fieldName, $uploadPath, $allowedTypes = 'gif|jpg|png')
    {
        $ci = &get_instance();
        $ci->load->library('upload');

        $config['upload_path'] = $uploadPath;
        $config['allowed_types'] = $allowedTypes;
        $config['max_size'] = 10240; // 10MB
        $config['encrypt_name'] = TRUE;

        $ci->upload->initialize($config);

        if (!$ci->upload->do_upload($fieldName)) {
            log_message('error', $ci->upload->display_errors());
            return FALSE;
        }

        return $ci->upload->data();
    }
}
