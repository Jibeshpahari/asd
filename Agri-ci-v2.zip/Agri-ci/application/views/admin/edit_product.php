<?php
  $title['page'] = 'products';
  $this->load->view('includes/admin-header.php', $title);
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <!-- Horizontal Form -->
            <div class="card card-outline card-info">
              <div class="card-header">
                <h3 class="card-title text-capitalize text-indigo text-lg text-bold" >Edit Products</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form class="form-horizontal" method="POST" action="action/edit_product_Act.php" enctype="multipart/form-data" onsubmit="return checkProduct()">
                <!-- <input type="hidden" value="" name="page"> -->
                <div class="card-body">
                <?php
                if (isset($error)) {
                  echo '<div class="alert alert-danger">' . $error . '</div>';
                }
                ?>
                  <input type="hidden" name="id" value="<?= $product['id'] ?>">
                  <input type="hidden" name="old_img" value="<?= $product['featured_img'] ?>">
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label">Category <span class="text-danger">*</span> </label>
                    <div class="col-sm-10">
                        <select class="form-control" name="category" id="category" required>
                        <option value=""> -- Choose Category -- </option>
                          <?php
                            foreach ($categories as $category) {
                            ?>
                            <option value="<?= $category['id']; ?>" <?= set_select('category', $category['id'], $category['id'] == $product['category']); ?>>
                              <?= $category['name']; ?>
                            </option>
                          <?php
                            }
                            
                          ?>
                        </select>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label">Sub Category <span class="text-danger">*</span> </label>
                    <div class="col-sm-10">
                        <select class="form-control" name="sub_category" id="sub_category" required>
                          <option value=""> -- Choose Sub Category -- </option>
                          <?php
                            foreach ($sub_categories as $sub_category) {
                            ?>
                            <option value="<?= $sub_category['id']; ?>" <?= set_select('sub_category', $sub_category['id'], $sub_category['id'] == $product['sub_category']); ?>>
                              <?= $sub_category['name'].$sub_category['id']; ?>
                            </option>
                          <?php
                            }
                          ?>
                        </select>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label"> Name <span class="text-danger">*</span> </label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="name" value="<?= $product['name'] ?>" name="name" placeholder="Name" required>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label"> Description </label>
                    <div class="col-sm-10">
                      <textarea class="form-control" rows="4" name="description" placeholder="Description"><?= $product['description'] ?></textarea>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label"> Price <span class="text-danger">*</span></label>
                    <div class="col-sm-10">
                      <input type="number" class="form-control" id="Price" value="<?= $product['price'] ?>" name="Price" step="0.01" placeholder="Price" onkeypress="return isNumberKey(event)" required>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="featured_img" class="col-sm-2 col-form-label">Featured Image <span class="text-danger">*</span></label>
                    <div class="col-sm-10 ">
                      <div class="mb-1">
                        <img src="<?= base_url('uploads/md/'.$product['featured_img']); ?>" alt="" width="100px" height="100px" class="img-thumbnail  d-block">
                      </div>
                      <input type="file" class="form-control-file" name="mainImg" id="featured_img" accept="image/*" >
                      <p class="text-capitalize text-sm text-info my-1">( Image should be > 10MB and Minimum 1000x1000 pixels square width )</p>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="availability" class="col-sm-2 col-form-label"> Availability </label>
                    <div class="col-sm-10">
                      <select class="form-control" name="availability" id="availability" >
                          <option value="In Stock" <?php echo $product['stock'] == 'In Stock'? 'selected':'';?>> In Stock </option>
                          <option value="Out Of Stock" <?php echo $product['stock'] == 'Out Of Stock'? 'selected':'';?>> Out Of Stock </option>
                        </select>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label">Gallery Image </label>
                    <div class="col-sm-10 ">
                      <div class="mb-1">
                        <?php
                            if(!empty($gallery)){       // Get all the sub image related to the product.
                                foreach($gallery as $row){
                        ?>
                            <div class="d-inline-block img-box">
                                <img src="<?= base_url('uploads/md/'.$row['img']); ?>" alt="<?php echo $row['id']; ?>" width="100px" height="100px" class="img-thumbnail">
                                <button type="button" class="img-close-btn" data-bs-dismiss="alert" aria-label="Close" id="closeBtn">
                                    <i class="fa fa-times fs-2 m-0" aria-hidden="true"></i>
                                </button>
                            </div>
                        <?php
                            }
                          }
                        ?>
                      </div>
                      <input type="file" class="image form-control-file" name="gallery[]" accept="image/*" multiple>
                      <p class="text-capitalize text-sm text-info my-1">***You can select multiple images from here for product gallery***</p>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label"></label>
                    <div class="col-sm-10 ">
                      <div class="row">
                        <div class="col-sm-4">
                            <div class="form-group">
                                <div class="custom-control custom-checkbox">
                                    <input class="custom-control-input" type="checkbox" id="spacial" value="special" name="special" <?= set_checkbox('special', 'special', $product['special'] == 1); ?>>
                                    <label for="spacial" class="custom-control-label font-weight-normal">Add To Special Product</label>
                                </div>
                            </div>
                        </div> 
                        <div class="col-sm-8">
                          <div class="form-group">
                                <div class="custom-control custom-checkbox">
                                    <input class="custom-control-input" type="checkbox" id="featured" value="featured" name="featured" <?= set_checkbox('featured', 'featured', $product['featured'] == 1); ?>>
                                    <label for="featured" class="custom-control-label font-weight-normal">Add To Featured Product</label>
                                </div>
                            </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <?php
                  ?>
                <!-- /.card-body -->
                <div class="card-footer text-center">
                  <button type="submit" class="btn btn-success">Update</button>
                  <button type="reset" class="btn btn-warning ml-5">Reset</button>
                </div>
                </div>
                 </form>
            </div>
            <!-- /.card -->
             
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->


<?php
  $this->load->view('includes/admin-footer.php');
?>