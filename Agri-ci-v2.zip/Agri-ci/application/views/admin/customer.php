<?php
  $title['page'] = 'customer';
  $this->load->view('includes/admin-header.php', $title);
?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper p-2">
    <div class="pl-3">
        <p class="h4 font-weight-bold text-info"><u>Customer</u></p>
    </div>
    <div class="card card-outline card-info">
        <div class="d-flex justify-content-center g-5 p-2">
          <a href="<?= base_url('admin/customer') ?>"><button class="btn btn-success py-0 px-2 mr-1">ALL</button></a>
          <a href="<?= base_url('admin/customer?search=A') ?>"><button class="btn btn-success py-0 px-2 mr-1">A</button></a>
          <a href="<?= base_url('admin/customer?search=B') ?>"><button class="btn btn-success py-0 px-2 mr-1">B</button></a>
          <a href="<?= base_url('admin/customer?search=C') ?>"><button class="btn btn-success py-0 px-2 mr-1">C</button></a>
          <a href="<?= base_url('admin/customer?search=D') ?>"><button class="btn btn-success py-0 px-2 mr-1">D</button></a>
          <a href="<?= base_url('admin/customer?search=E') ?>"><button class="btn btn-success py-0 px-2 mr-1">E</button></a>
          <a href="<?= base_url('admin/customer?search=F') ?>"><button class="btn btn-success py-0 px-2 mr-1">F</button></a>
          <a href="<?= base_url('admin/customer?search=G') ?>"><button class="btn btn-success py-0 px-2 mr-1">G</button></a>
          <a href="<?= base_url('admin/customer?search=H') ?>"><button class="btn btn-success py-0 px-2 mr-1">H</button></a>
          <a href="<?= base_url('admin/customer?search=I') ?>"><button class="btn btn-success py-0 px-2 mr-1">I</button></a>
          <a href="<?= base_url('admin/customer?search=J') ?>"><button class="btn btn-success py-0 px-2 mr-1">J</button></a>
          <a href="<?= base_url('admin/customer?search=K') ?>"><button class="btn btn-success py-0 px-2 mr-1">K</button></a>
          <a href="<?= base_url('admin/customer?search=L') ?>"><button class="btn btn-success py-0 px-2 mr-1">L</button></a>
          <a href="<?= base_url('admin/customer?search=M') ?>"><button class="btn btn-success py-0 px-2 mr-1">M</button></a>
          <a href="<?= base_url('admin/customer?search=N') ?>"><button class="btn btn-success py-0 px-2 mr-1">N</button></a>
          <a href="<?= base_url('admin/customer?search=O') ?>"><button class="btn btn-success py-0 px-2 mr-1">O</button></a>
          <a href="<?= base_url('admin/customer?search=P') ?>"><button class="btn btn-success py-0 px-2 mr-1">P</button></a>
          <a href="<?= base_url('admin/customer?search=Q') ?>"><button class="btn btn-success py-0 px-2 mr-1">Q</button></a>
          <a href="<?= base_url('admin/customer?search=R') ?>"><button class="btn btn-success py-0 px-2 mr-1">R</button></a>
          <a href="<?= base_url('admin/customer?search=S') ?>"><button class="btn btn-success py-0 px-2 mr-1">S</button></a>
          <a href="<?= base_url('admin/customer?search=T') ?>"><button class="btn btn-success py-0 px-2 mr-1">T</button></a>
          <a href="<?= base_url('admin/customer?search=U') ?>"><button class="btn btn-success py-0 px-2 mr-1">U</button></a>
          <a href="<?= base_url('admin/customer?search=V') ?>"><button class="btn btn-success py-0 px-2 mr-1">V</button></a>
          <a href="<?= base_url('admin/customer?search=W') ?>"><button class="btn btn-success py-0 px-2 mr-1">W</button></a>
          <a href="<?= base_url('admin/customer?search=X') ?>"><button class="btn btn-success py-0 px-2 mr-1">X</button></a>
          <a href="<?= base_url('admin/customer?search=Y') ?>"><button class="btn btn-success py-0 px-2 mr-1">Y</button></a>
          <a href="<?= base_url('admin/customer?search=Z') ?>"><button class="btn btn-success py-0 px-2 mr-1">Z</button></a>
        </div>
        <hr>
    <div class="card card-outline card-info px-5 py-3">
        <form method="GET" action="<?= base_url('admin/customer') ?>">
            <div class="form-group px-5 d-flex">
              <input type="search" class="form-control" name="search" id=""  placeholder="Search...">
              <button type="submit" class="btn btn-success ml-3">Submit</button>
            </div>
        </form>
    </div>
    <?php 
        if(isset($error)){  echo '<div class="alert alert-danger">'.$error.'</div>'; }
        if($this->session->flashdata('message') !== null ){  
          echo '<div class="alert alert-warning mx-auto w-50 text-center py-2">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.
            $this->session->flashdata('message')
          .'</div>'; 
        }
    ?>
    
    <!-- Content Header (Page header) -->
    <div class="card-body p-0">
                <table class="table table-striped">
                  <thead>
                    <tr>
                      <th class="text-center">Name</th>
                      <th class="text-center">Mail</th>
                      <th class="text-center">Telephone</th>
                      <th class="text-center">Status</th>
                      <th class="text-center">No. of order</th>
                      <th class="text-center">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                      foreach($customers as $row){
                    ?>
                    <tr>
                        <td class="text-center"><?php echo $row['fname'].' '.$row['lname']; ?></td>
                      <td class="text-center"><?php echo $row['email']; ?></td>
                      <td class="text-center"><?php echo $row['phone']; ?></td>
                      <td class="text-center"><?php echo $row['status']; ?></td>
                      <td class="text-center"><?php echo $row['num_orders']; ?></td>
                      <td class="text-center">
                        <a href="<?= base_url('admin/customer/edit/'.$row['id']) ?>"><button class="btn btn-info py-1">EDIT</button></a> 
                        <a href="<?= base_url('admin/customer/order/'.$row['id']) ?>"><button class="btn btn-primary py-1">Order</button></a>
                        <a href="<?= base_url('admin/customer/delete/'.$row['id']) ?>"><button class="btn btn-danger py-1">DELETE</button></a>
                      </td>
                    </tr>
                    <?php
                      }
                    ?>
                  </tbody>
                </table>
              </div>
             
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->


<?php
  $this->load->view('includes/admin-footer.php');
?>