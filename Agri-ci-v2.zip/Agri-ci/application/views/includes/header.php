<!DOCTYPE html>

<html dir="ltr" lang="en">

<head>

    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="My Store" />

    <link href="<?php echo base_url(); ?>/assets/images/favicon.png" rel="icon" />
    <title>Agriculture</title>

    <link href="<?php echo base_url(); ?>/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen" />
    <link href="<?php echo base_url(); ?>/assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url(); ?>/assets/css/stylesheet.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>/assets/css/responsive.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>/assets/css/menu.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>/assets/jquery/owl-carousel/owl.carousel.css" type="text/css" rel="stylesheet" media="screen" />

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/jquery/jquery-2.1.1.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>/assets/jquery/owl-carousel/owl.carousel.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>/assets/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>/assets/js/jquery.extra.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>/assets/js/common.js" type="text/javascript"></script>


</head>
<body class="common-home">
<div class="infoBox bg-dark text-center mx-auto">
  <svg width='18' height='18' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg' id="right">
	  <g>
		  <path d='M-2-2h24v24H-2z' fill='none'/>
		  <path d='M10 0C4.48 0 0 4.48 0 10s4.48 10 10 10 10-4.48 10-10S15.52 0 10 0zM8 15l-5-5 1.41-1.41L8 12.17l7.59-7.59L17 6l-9 9z' fill='#26BC4E'/>
	  </g>
  </svg>
  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" id="wrong" class="d-none">
    <path fill="#f60e0e" d="M12 0c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm4.597 17.954l-4.591-4.55-4.555 4.596-1.405-1.405 4.547-4.592-4.593-4.552 1.405-1.405 4.588 4.543 4.545-4.589 1.416 1.403-4.546 4.587 4.592 4.548-1.403 1.416z"/>
  </svg>
 
  <p>  </p>
</div>
<a class="house-heaven" href="#">&nbsp;</a>
<nav id="top">
  <div class="container">
	<div id="top-links">
      <ul class="list-inline">
        <li><a href="tel:0906430244"><i class="fa fa-phone"></i></a>&nbsp; <span>(090)6430244</span></li>
      </ul>
    </div>
    
    <div id="top-links2">
      <ul class="list-inline">
        <li><a href="login.php"><i class="fa fa-user"></i> <span>My Account</span></a></li>
        <li><a href="#" id="wishlist-total" title="Wish List (0)"><i class="fa fa-heart"></i> <span>Wishlist (0)</span></a></li>
        <li><a href="cart.php" title="Checkout"><i class="fa fa-shopping-bag"></i> <span>Checkout</span></a></li>
      </ul>
    </div>
  </div>
</nav>
  <header class="header">
    <div class="container">
      <div class="row">
        <div class="col-md-3 col-sm-4">
          <div id="logo"><a href="index.html"><img src="<?php echo base_url(); ?>/assets/images/logo.png" title="Agriculture" alt="Agriculture"
                class="img-responsive" /></a></div>
        </div>
        <div class="col-md-9 col-sm-8">
          <div class="header-right">
            <div class="input-group" id="search">
              <input type="text" class="form-control input-lg" placeholder="Search" value="" name="search"
                vk_1e187="subscribed">
              <span class="input-group-btn">
                <button class="btn btn-default btn-lg" type="button"><i
                    class="fa fa-search"></i></button>
              </span>
            </div>
            <div class="btn-group btn-block" id="cart">
              <button class="btn btn-viewcart dropdown-toggle" data-loading-text="Loading..."
                data-toggle="dropdown" type="button" aria-expanded="false"><span class="lg">My
                  Cart</span><span id="cart-total"><i class="fa fa-shopping-basket"></i> (1)
                  items</span></button>
              <ul class="dropdown-menu pull-right">
                <li>
                  <table class="table table-striped">
                    <tbody>
                      <tr>
                        <td class="text-center"> <a href="#">
                          <img class="img-thumbnail" title="iPhone" alt="iPhone" src="<?php echo base_url(); ?>/assets/images/iphone_1-47x47.jpg"></a>
                        </td>
                        <td class="text-left"><a href="#">iPhone</a>
                        </td>
                        <td class="text-right">x 1</td>
                        <td class="text-right">$123.20</td>
                        <td class="text-center"><button class="btn btn-danger btn-xs"
                            title="Remove"  type="button"><i class="fa fa-times"></i></button></td>
                      </tr>
                    </tbody>
                  </table>
                </li>
                <li>
                  <div>
                    <table class="table table-bordered">
                      <tbody>
                        <tr>
                          <td class="text-right"><strong>Sub-Total</strong></td>
                          <td class="text-right">$101.00</td>
                        </tr>
                        <tr>
                          <td class="text-right"><strong>Eco Tax (-2.00)</strong></td>
                          <td class="text-right">$2.00</td>
                        </tr>
                        <tr>
                          <td class="text-right"><strong>VAT (20%)</strong></td>
                          <td class="text-right">$20.20</td>
                        </tr>
                        <tr>
                          <td class="text-right"><strong>Total</strong></td>
                          <td class="text-right">$123.20</td>
                        </tr>
                      </tbody>
                    </table>
                    <p class="text-right"><a href="#"><strong><i class="fa fa-shopping-cart"></i>
                          View Cart</strong></a>&nbsp;&nbsp;&nbsp;<a href="#"><strong><i
                            class="fa fa-share"></i> Checkout</strong></a></p>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </header>


  <div class="navMenu-main">
    <div id="menu" class="gn-icon-menu"><span></span></div>
  </div>
  <div class="top-menu">
    <div class="container">
      <div id="slidingMenu">
        <nav id="navMenu">
          <ul>
            <li><a class="active" href="index.html">Home</a></li>
            <li><a href="#">Animal Dosing</a></li>
            <li><a href="#">Cattle</a></li>
            <li><a href="#">Sheep</a></li>
            <li><a href="#">Horses</a></li>
            <li><a href="#">Fencing</a></li>
            <li><a href="#">Hardware</a></li>
            <li><a href="#">Clothing & Footwear</a></li>
            <li><a href="#">Pets</a></li>
          </ul>
        </nav>
      </div>
    </div>
  </div>