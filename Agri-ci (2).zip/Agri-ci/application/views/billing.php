<?php
    include_once('includes/header.php');
    if(!isset($_SESSION['user'])) {
        echo '<script> 
            window.location.href = "login.php";
        </script>';
    }
?>
<div class="banner-in">
	<div class="container">
    	<h1>Billing Address</h1>
        <ul class="newbreadcrumb">
            <li><a href="index.php">Home</a></li>
      </ul>
    </div>
</div>
<div id="main-container">
    <div class="container">
        <form action="order_act.php" method="post">

            <div class="row">
                <?php
                    $query = getAddressByUserId($_SESSION['user']['id']);
                    while($row = $query->fetch_assoc()) {
                ?>
                <div class=" col-lg-3">
    
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title"><?php echo $row['fname'].' '.$row['lname']; ?></h5>
                        </div>
                        <div class="card-body">
                            <p class="card-text">
                                <?php
                                    echo $row['address1'] . '<br>';
                                    echo $row['city'] . ' - ';
                                    echo $row['postcode'] . '<br>';
                                    echo $row['email'] . '<br>';
                                    echo $row['phone'] . '<br>';
                                ?>
                            </p>
                        </div>
                    </div> 
                    <div >
                        <div class="form-group">
                            <input type="radio" name="billingAddress" id="<?php echo $row['id']; ?>" value="<?php echo $row['id']; ?>" required> 
                            <label for="<?php  echo $row['id']; ?>">Select</label>
                        </div>
                    </div>
    
                </div> 

                <?php
                    }
                ?>

                <div class="col-lg-3 btn-col " style="display: flex; justify-content: center; align-items: center;">
                    <a href="add_address.php"> <button class="btn btn160 btn-success" type="button" id="add_address">
                        ADD NEW <strong>+</strong>
                    </button></a>
                </div>

            </div>   
            
            <div class="pull-right">
                <button class="btn btn160 btn-lg btn-primary" type="submit" id="">Next</button>
            </div>
            
        </form>


    </div>
</div>

<?php
    include_once('includes/footer.php');
?>