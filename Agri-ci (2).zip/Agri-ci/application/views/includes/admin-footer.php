

<!-- REQUIRED SCRIPTS -->
<!-- AJAX -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<!-- jQuery -->
<script src="<?php echo base_url(); ?>/assets/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="<?php echo base_url(); ?>/assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- overlayScrollbars -->
<script src="<?php echo base_url(); ?>/assets/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url(); ?>/assets/dist/js/adminlte.js"></script>

<!-- PAGE PLUGINS -->
<!-- jQuery Mapael -->
<script src="<?php echo base_url(); ?>/assets/plugins/jquery-mousewheel/jquery.mousewheel.js"></script>
<script src="<?php echo base_url(); ?>/assets/plugins/raphael/raphael.min.js"></script>
<script src="<?php echo base_url(); ?>/assets/plugins/jquery-mapael/jquery.mapael.min.js"></script>
<script src="<?php echo base_url(); ?>/assets/plugins/jquery-mapael/usa_states.min.js"></script>
<!-- ChartJS -->
<script src="<?php echo base_url(); ?>/assets/plugins/chart.js/Chart.min.js"></script>
<!-- Summernote -->
<script src="<?php echo base_url(); ?>/assets/plugins/summernote/summernote-bs4.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url(); ?>/assets/dist/js/demo.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<!-- <script src="dist/js/pages/dashboard2.js"></script> -->


<script>
  $(document).ready(function() {
    setTimeout(function() {
      category = $('#category').val();
      sub_category = $('#sub_category').val();
      if (category && sub_category === null) {
        getSubcategoryByCategoryId(category);
      }
    }, 100);
    $('#category').click(function() {
        getSubcategoryByCategoryId($(this).val());
    });
    $('#category').change(function() {
      var category_id = $(this).val();
      if (category_id) {
        getSubcategoryByCategoryId(category_id);
      } else {
        $('#sub_category').empty();
        $('#sub_category').append('<option value=""> -- Choose Category First -- </option>');
      }
    });
  });

  function getSubcategoryByCategoryId(category_id) {
    $.ajax({
      url: '<?php echo base_url('AdminController/getSubCategoryByCategoryId'); ?>',
      type: 'POST',
      dataType: 'json',
      data: {category_id: category_id},
      success: function(data) {
        console.log(data);
        $('#sub_category').empty();
        $('#sub_category').append('<option value=""> -- Choose Sub Category -- </option>');
        $.each(data, function(key, value) {
          var selectedSubCategory = "<?php echo set_value('sub_category'); ?>";
          var selected = (selectedSubCategory == value.id) ? ' selected="selected"' : '';
          $('#sub_category').append('<option value="' + value.id + '"' + selected + '>' + value.name + '</option>');
        });
      },
      error: function(xhr, status, error) {
        console.error('Error fetching subcategories:', error);
        $('#sub_category').empty();
        $('#sub_category').append('<option value=""> -- Choose -- </option>');
      }
    });
  }

  function isNumberKey(evt) {
    var charCode = (evt.which) ? evt.which : evt.keyCode
    if (charCode > 31 && (charCode != 46 &&(charCode < 48 || charCode > 57))){
      return false;
    }
    return true;
  }


  // var _URL = window.URL || window.webkitURL;

  // $("#featured_img").change(function(e) {
  //     var file, img;
  //     $("#alertBox").addClass("d-none");
  //     // alert(this.files[0].size);
  //     if ((file = this.files[0])) {
  //         img = new Image();
  //         img.onload = function() {
  //           if(this.width < 800 ) {
  //             $("#alertBox").text("Image Width should be Minimum 800 pixels. ");
  //             $("#alertBox").removeClass("d-none");
  //             $("#alertBox").focus();
  //             $("#featured_img").val("");
  //             // || this.size > 10000000
  //           }
  //         };
  //         img.onerror = function() {
  //           $("#alertBox").text("Given file is not an Image.");
  //           $("#alertBox").removeClass("d-none");
  //         };
  //         img.src = _URL.createObjectURL(file);
  //     }
  // });

  // function bytesToMB(bytes) {
  //   return bytes / (1024 * 1024);
  // }

  let close = document.querySelectorAll(".img-close-btn");
  const arr = [];
  close.forEach(function(btn) {
    btn.addEventListener("click", function() {
      this.parentElement.remove();
      img = this.parentElement.querySelector("img").getAttribute("data-image");
      let trashInput = document.getElementById("trash");
      let currentVal = trashInput.value ? JSON.parse(trashInput.value) : [];
      currentVal.push(img);
      trashInput.value = JSON.stringify(currentVal);
    });
  });

  $(document).ready(function() {
    $('#showpass').on('click',function(){
      $('#password').attr('type',function(index, attr){
        $('#password').focus();
        return attr == 'password' ? 'text' : 'password';
      });
    });
  });
</script>

</body>
</html>
