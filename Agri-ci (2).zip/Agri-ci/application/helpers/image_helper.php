<?php

defined('BASEPATH') or exit('No direct script access allowed');

if (!function_exists('resizeImage')) {
    function resizeImage($sourcePath, $destinationPath, $width, $height)
    {
        
        $ci =& get_instance();  // Get the CodeIgniter instance
        $ci->load->library('image_lib');

        // If destination file exists, generate a unique filename
        if (file_exists($destinationPath)) {
            $pathInfo = pathinfo($destinationPath);
            $baseName = $pathInfo['filename'];
            $extension = isset($pathInfo['extension']) ? '.' . $pathInfo['extension'] : '';
            $dir = $pathInfo['dirname'];
            $i = 1;
            do {
            $destinationPath = $dir . DIRECTORY_SEPARATOR . $baseName . '_' . $i . $extension;
            $i++;
            } while (file_exists($destinationPath));
        }

        $config['image_library'] = 'gd2';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['source_image'] = $sourcePath;
        $config['new_image'] = $destinationPath;
        $config['maintain_ratio'] = TRUE;
        $config['width'] = $width;
        $config['height'] = $height;

        $ci->image_lib->initialize($config);

        if (!$ci->image_lib->resize()) {
            log_message('error', $ci->image_lib->display_errors());
            return FALSE;
        }

        $ci->image_lib->clear();
        return $destinationPath;
    }
}

if (!function_exists('uploadImage')) {
    function uploadImage($fieldName, $uploadPath, $allowedTypes = 'gif|jpg|png')
    {
        $ci =& get_instance();
        $ci->load->library('upload');

        $config['upload_path'] = $uploadPath;
        $config['allowed_types'] = $allowedTypes;
        $config['max_size'] = 10240; // 10MB
        $config['encrypt_name'] = TRUE;

        $ci->upload->initialize($config);

        if (!$ci->upload->do_upload($fieldName)) {
            log_message('error', $ci->upload->display_errors());
            return FALSE;
        }

        return $ci->upload->data();
    }
}