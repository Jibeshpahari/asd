<?php

defined('BASEPATH') or exit('No direct script access allowed');

class UserController extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('UserModel');
        $this->load->model('AdminModel');
        $this->load->library('cart');
    }

    // --------------------- ||  FUNCTION FOR INDEX PAGE  || ---------------------
    // Show the index page
    public function index()
    {
        $category = $this->UserModel->getCategory();
        $data['category'] = $category;
        $special = $this->UserModel->getSpecialProduct();
        $data['special'] = $special;
        $featured = $this->UserModel->getFeaturedProduct();
        $data['featured'] = $featured;
        $this->load->view('index', $data);
    }

    // --------------------- ||  FUNCTION FOR PRODUCT PAGE  || ---------------------
    // Show the product page
    public function product($id)
    {
        $product = $this->AdminModel->getProductById($id);
        $data['product'] =  $product;
        $gallery = $this->UserModel->getProductGallery($id);
        $data['gallery'] = $gallery;
        $subProduct = $this->UserModel->getSimilarByProductId($id, $product['sub_category']);
        $data['subProduct'] = $subProduct;
        $category = $this->AdminModel->getCategoryById($product['category']);
        $data['category'] = $category;
        $subCategory = $this->AdminModel->getSubCategoryById($product['sub_category']);
        $data['subCategory'] = $subCategory;
        // echo "<pre>"; print_r($data);
        $this->load->view('product', $data);
    }

    // --------------------- ||  FUNCTION FOR CATEGORY PAGE  || ---------------------
    // Show the category page
    public function category($id)
    {
        $product = $this->UserModel->getProductByCategory($id);
        $data['products'] = $product;
        $this->load->view('category', $data);
    }

    // Show the Sub Category page
    public function subCategory($id)
    {
        $product = $this->UserModel->getProductBySubCategory($id);
        $data['products'] = $product;
        $this->load->view('category', $data);
    }

    // Sort the product
    public function productSort()
    {
        $products = $this->UserModel->getProductSegment();
        $result['products'] = $products;

        $segment = $this->input->post('segment');
        $id = $this->input->post('id');

        if ($segment == 'category') {
            $count = $this->UserModel->getProductByCategory($id);
            $count = count($count);
        } elseif ($segment == 'sub_category') {
            $count = $this->UserModel->getProductBySubCategory($id);
            $count = count($count);
        }

        $result['showing'] = $count;
        $this->load->view('getProduct', $result);
    }

    // --------------------- ||  FUNCTION FOR SEARCH PAGE  || ---------------------
    // Show the search page
    public function search()
    {
        $search = $this->input->get('search');
        $product = $this->UserModel->getProductBySearch($search);
        $data['products'] = $product;
        if (empty($product)) {
            $data['message'] = "No products found for your search.";
        }
        $this->load->view('search', $data);
    }

    // --------------------- ||  FUNCTION FOR CART PAGE  || ---------------------
    // Show
    public function show()
    {
        $cartItems = $this->cart->contents();
        echo "<pre>";
        print_r($cartItems);
        echo '<br>';
        echo $this->cart->total();
    }
    // add product to the cart using Ajax
    public function addToCart()
    {
        $productId = $this->input->post('product_id');
        $quantity = $this->input->post('quantity');
        $product = $this->AdminModel->getProductById($productId);
        if ($product) {
            $data = array(
                'id'      => $productId,
                'qty'     => $quantity,
                'price'   => $product['price'],
                'name'    => $product['name'],
                'image'   => $product['featured_img']
            );
            $this->cart->insert($data);
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Product not found']);
        }
    }

    // Get the cart items with details
    public function getCartItems()
    {
        $cartItems = $this->cart->contents();
        $data['items'] = $cartItems;
        $data['count'] = count($cartItems);
        $data['sub_total'] = $this->cart->total();
        $data['tax'] =  $this->cart->total_items() * 2; // Assuming a fixed tax of 2 per item
        $data['vat'] =   $data['sub_total'] * 0.2; // Assuming a VAT of 20%
        $data['total'] = $data['sub_total'] + $data['tax'] + $data['vat'];
        return $data;
    }

    // Update the cart page using Ajax
    public function getCart()
    {
        $data = $this->getCartItems();
        $this->load->view('getCart',  $data);
    }

    // Calculate the cart billing details
    public function calculateCart()
    {
        $data = $this->getCartItems();

        // Initialize discount (can be set dynamically in the future)
        $discount = isset($data['discount']) ? $data['discount'] : 0;

        // Calculate total after discount
        $totalAfterDiscount = $data['sub_total'] + $data['tax'] + $data['vat'] - $discount;

        $response = [
            'sub_total' => $data['sub_total'],
            'tax'       => $data['tax'],
            'vat'       => $data['vat'],
            'discount'  => $discount,
            'total'     => $totalAfterDiscount
        ];
    }

    // Show the cart page
    public function cart()
    {
        $data = $this->getCartItems();
        $this->load->view('cart', $data);
    }

    // Update list of the items
    public function getItemList()
    {
        $data = $this->getCartItems();
        $this->load->view('getCartList', $data);
    }

    // Delete item from cart
    public function removeItem()
    {
        $rowid = $this->input->post('id');
        if ($rowid) {
            $this->cart->remove($rowid);
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Invalid cart item']);
        }
    }
}
